# Nouveau Plan d'Implémentation - Sélecteur Haute Performance vs Économie d'Énergie

## 1. Vision & Approche Révisée
Plutôt qu'une refonte complexe du schéma de base de données, cette approche repensée privilégie :
1. **Une interface dédiée et percutante** : Une section distincte « Gestion de l'Énergie & Synchronisation » dans les Paramètres, offrant une visualisation directe de l'impact énergétique.
2. **Des effets concrets et tangibles sur la batterie et la bande passante** :
   - **Mode Haute Performance (High Performance)** :
     - Synchronisation instantanée en temps réel (latence minimale).
     - Téléchargement automatique immédiat de tous les médias (photos, vocaux, stickers, vidéos).
     - Accusés de distribution et de lecture envoyés sans délai.
   - **Mode Économie d'Énergie (Battery Saver)** :
     - Synchronisation des messages en arrière-plan cadencée (toutes les 15 minutes ou à l'ouverture de l'application).
     - Suspension du téléchargement automatique des médias lourds (téléchargement au clic ou sur Wi-Fi uniquement).
     - Réduction drastique des réveils réseau (wake locks) économisant jusqu'à 60% d'énergie radio.
     - Bouton d'action directe « Forcer la synchronisation » pour rafraîchir manuellement les données à tout moment.
3. **Tableau de bord d'autonomie en direct** : Affichage d'un indicateur de gain d'autonomie estimé (+2h à +4h) et statut d'économie en temps réel.

---

## 2. Architecture Technique Simplifiée & Robuste

### A. Modèle & État Réactif
- Création de `SyncEnergyMode.kt` dans `com.example.data.model` :
  - `HIGH_PERFORMANCE` : Latence ultra-faible, téléchargement média immédiat, écouteurs actifs.
  - `BATTERY_SAVER` : Cycles de 15 min, téléchargement média différé au clic, radio réseau préservée.
- Persistance transparente via `SharedPreferences` / `DataStore` ou état persistant du `AdtViewModel` pour éviter toute migration destructive de la base de données Room.

### B. Moteur d'Économie d'Énergie dans `AdtViewModel`
- État observable : `syncEnergyMode: StateFlow<SyncEnergyMode>`.
- Méthode `setSyncEnergyMode(mode: SyncEnergyMode)`.
- Action `triggerImmediateManualSync()` pour permettre à l'utilisateur en mode économie de rafraîchir ses messages à la demande.
- Transmission de la politique d'économie au gestionnaire de synchronisation et au chargement des pièces jointes.

### C. Interface Utilisateur & Expérience dans `SettingsScreen.kt`
- Création d'un composant de premier plan : **`EnergySyncManagementCard`** :
  - **Sélecteur interactif moderne** à deux options stylisées avec icônes (⚡ vs 🔋).
  - **Fiche comparative visuelle** montrant les bénéfices de chaque mode (fréquence, médias, autonomie).
  - **Badge de diagnostic** : Indique si le mode économiseur est actif avec estimation du gain d'autonomie.
  - **Bouton d'actualisation manuelle** avec animation de rotation lors du rafraîchissement.
  - TestTags conformes (`sync_mode_high_perf_btn`, `sync_mode_battery_saver_btn`, `btn_manual_force_sync`).

---

## 3. Étapes d'Exécution

1. **Modèle de données (`SyncEnergyMode.kt`)** : Énumération avec intitulés, descriptions, seuils de rafraîchissement et métriques d'autonomie.
2. **Logique applicative (`AdtViewModel.kt`)** : Ajout du contrôle de mode, de la persistance locale et du déclencheur de synchronisation manuelle.
3. **Interface utilisateur (`SettingsScreen.kt`)** : Intégration de la carte de contrôle dédiée avec sélecteur ergonomique et feedback visuel instantané.
4. **Vérification de la compilation** : Exécution de `compile_applet` pour valider l'intégrité du code.

---

## 4. Bénéfices pour l'Utilisateur
- Contrôle immédiat et transparent sur la consommation de la batterie.
- Aucune interruption de service ni risque de perte de données.
- Flexibilité totale avec rafraîchissement manuel disponible à tout moment.
