package com.example.ui.screens.settings

import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppUsageStatistics
import com.example.data.model.DailyUsageStat
import com.example.data.model.DataUsageCategory
import com.example.data.model.MediaNetworkUsageDetail
import com.example.data.model.UsagePeriod
import com.example.ui.theme.AdtAccentGreen
import com.example.ui.theme.AdtPrimary
import com.example.ui.theme.AdtSecondary
import com.example.viewmodel.AdtViewModel
import com.example.viewmodel.AppScreen

private val StatScreenTimeColor = Color(0xFF34B7F1)
private val StatMessagesColor = Color(0xFF00A884)
private val StatDataColor = Color(0xFFFF9800)
private val StatCallsColor = Color(0xFF9C27B0)

/**
 * Écran complet de statistiques d'utilisation : temps d'écran, messages échangés et consommation de données.
 * Intègre des graphiques Canvas natifs réactifs (histogrammes, courbes interactives et diagrammes de flux)
 * reproduisant fidèlement le style et la fluidité des graphiques Recharts / D3.js.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppUsageStatisticsScreen(viewModel: AdtViewModel) {
    val stats by viewModel.appUsageStats.collectAsState()
    val selectedPeriod by viewModel.selectedUsagePeriod.collectAsState()
    val isLoading by viewModel.isUsageStatsLoading.collectAsState()

    var activeMetricTab by remember { mutableStateOf(0) } // 0: Temps d'écran, 1: Messages, 2: Données
    var hoveredDayIndex by remember { mutableStateOf<Int?>(null) }

    BackHandler {
        viewModel.navigateTo(AppScreen.SETTINGS)
    }

    LaunchedEffect(Unit) {
        viewModel.refreshUsageStatistics()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Statistiques d'utilisation",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                        Text(
                            text = "Temps d'écran, messages & données consommées",
                            fontSize = 11.5.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = { viewModel.navigateTo(AppScreen.SETTINGS) },
                        modifier = Modifier.testTag("btn_back_usage_stats")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Retour aux paramètres"
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = { viewModel.refreshUsageStatistics() },
                        modifier = Modifier.testTag("btn_refresh_usage_stats")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Actualiser les statistiques",
                            tint = AdtPrimary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .testTag("usage_statistics_list"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Sélecteur de période (7 jours, 30 jours, Global)
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    UsagePeriod.values().forEach { period ->
                        val isSelected = selectedPeriod == period
                        val chipTag = when (period) {
                            UsagePeriod.DAY_7 -> "chip_period_7d"
                            UsagePeriod.DAY_30 -> "chip_period_30d"
                            UsagePeriod.ALL_TIME -> "chip_period_all"
                        }
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = if (isSelected) AdtPrimary else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                            border = BorderStroke(
                                width = 1.dp,
                                color = if (isSelected) AdtPrimary else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .clickable { viewModel.setUsagePeriod(period) }
                                .testTag(chipTag)
                        ) {
                            Box(
                                modifier = Modifier.padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = period.label,
                                    fontSize = 12.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }
            }

            // Cartes KPI de résumé rapide (3 métriques clés)
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // KPI 1: Temps d'écran
                    SummaryKpiCard(
                        title = "Temps passé",
                        value = stats.formattedTotalScreenTime,
                        subtitle = "Moy. ${stats.formattedAverageDailyScreenTime}/j",
                        icon = Icons.Default.Schedule,
                        iconTint = StatScreenTimeColor,
                        isSelected = activeMetricTab == 0,
                        onClick = { activeMetricTab = 0 },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("kpi_card_screen_time")
                    )

                    // KPI 2: Messages
                    SummaryKpiCard(
                        title = "Messages",
                        value = "${stats.totalMessages}",
                        subtitle = "${stats.totalMessagesSent} env. • ${stats.totalMessagesReceived} reç.",
                        icon = Icons.Default.Chat,
                        iconTint = StatMessagesColor,
                        isSelected = activeMetricTab == 1,
                        onClick = { activeMetricTab = 1 },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("kpi_card_messages")
                    )

                    // KPI 3: Données
                    SummaryKpiCard(
                        title = "Données",
                        value = stats.formattedTotalData,
                        subtitle = "${stats.formattedDataSent} ↑ • ${stats.formattedDataReceived} ↓",
                        icon = Icons.Default.DataUsage,
                        iconTint = StatDataColor,
                        isSelected = activeMetricTab == 2,
                        onClick = { activeMetricTab = 2 },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("kpi_card_data")
                    )
                }
            }

            // Grand Graphique Interactif (Style Recharts / D3.js avec barres dynamiques ou courbe spline)
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("interactive_chart_card"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = when (activeMetricTab) {
                                        0 -> "Évolution du temps passé sur ADT Pro"
                                        1 -> "Volume quotidien des messages échangés"
                                        else -> "Trafic réseau quotidien (Envois + Réceptions)"
                                    },
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                                Text(
                                    text = "Touchez une barre pour inspecter le détail journalier",
                                    fontSize = 11.5.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = when (activeMetricTab) {
                                    0 -> StatScreenTimeColor.copy(alpha = 0.15f)
                                    1 -> StatMessagesColor.copy(alpha = 0.15f)
                                    else -> StatDataColor.copy(alpha = 0.15f)
                                }
                            ) {
                                Text(
                                    text = when (activeMetricTab) {
                                        0 -> "Minutes"
                                        1 -> "Messages"
                                        else -> "Données"
                                    },
                                    fontSize = 10.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = when (activeMetricTab) {
                                        0 -> StatScreenTimeColor
                                        1 -> StatMessagesColor
                                        else -> StatDataColor
                                    },
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                        }

                        // Composant Graphique Canvas Recharts/D3-style
                        InteractiveUsageBarChart(
                            dailyStats = stats.dailyStats,
                            metricTab = activeMetricTab,
                            hoveredIndex = hoveredDayIndex,
                            onSelectDay = { hoveredDayIndex = it },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(190.dp)
                        )

                        // Info-bulle / Tooltip interactif quand un jour est sélectionné
                        val selectedDay = hoveredDayIndex?.let { idx -> stats.dailyStats.getOrNull(idx) }
                        AnimatedVisibility(
                            visible = selectedDay != null,
                            enter = fadeIn() + expandVertically(),
                            exit = fadeOut() + shrinkVertically()
                        ) {
                            if (selectedDay != null) {
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = MaterialTheme.colorScheme.surface,
                                    border = BorderStroke(1.dp, AdtPrimary.copy(alpha = 0.3f)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 14.dp, vertical = 10.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text(
                                                text = "${selectedDay.dayLabel} (${selectedDay.fullDateLabel})",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 13.sp,
                                                color = AdtPrimary
                                            )
                                            Text(
                                                text = "Temps d'écran : ${selectedDay.formattedScreenTime}",
                                                fontSize = 12.sp,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                        }
                                        Column(horizontalAlignment = Alignment.End) {
                                            Text(
                                                text = "${selectedDay.totalMessages} msgs (${selectedDay.messagesSent} env. / ${selectedDay.messagesReceived} reç.)",
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                            Text(
                                                text = "Données : ${selectedDay.formattedData}",
                                                fontSize = 11.5.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Répartition des Données par Catégorie (Donut / Barre de progression segmentée D3-style)
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("data_breakdown_card"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(Icons.Default.PieChart, contentDescription = null, tint = StatDataColor)
                                Text(
                                    text = "Répartition de la bande passante",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                            }
                            Text(
                                text = stats.formattedTotalData,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = AdtPrimary
                            )
                        }

                        // Jauge segmentée multicolore proportionnelle
                        SegmentedDataUsageBar(
                            categories = stats.dataCategories,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(14.dp)
                                .clip(RoundedCornerShape(7.dp))
                        )

                        // Liste des catégories avec pourcentage et volume
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            stats.dataCategories.forEach { cat ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(10.dp)
                                                .background(Color(cat.colorHex), CircleShape)
                                        )
                                        Text(
                                            text = cat.category,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Medium
                                        )
                                    }
                                    Row(
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = String.format(java.util.Locale.US, "%.1f%%", cat.percentage),
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Text(
                                            text = cat.formattedBytes,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Section 'Utilisation Réseau' Détaillée par Type de Média (Messages, Photos, Vidéos, Appels)
            item {
                NetworkUsageDetailsCard(
                    mediaDetails = stats.mediaNetworkDetails,
                    totalDataSent = stats.formattedDataSent,
                    totalDataReceived = stats.formattedDataReceived,
                    totalDataSaved = stats.formattedDataSaved,
                    onManageDataThrottles = { viewModel.navigateTo(AppScreen.SETTINGS) }
                )
            }

            // Faits marquants et Insights d'utilisation (Heure de pointe, Discussion favorite, Appels)
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "Aperçu de vos habitudes",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = AdtPrimary
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            InsightMiniCard(
                                icon = Icons.Default.AccessTime,
                                title = "Pic d'activité",
                                value = "${stats.peakActivityHour}h00 - ${stats.peakActivityHour + 1}h00",
                                subtitle = "Heure la plus connectée",
                                modifier = Modifier.weight(1f)
                            )

                            InsightMiniCard(
                                icon = Icons.Default.Forum,
                                title = "Discussion phare",
                                value = stats.mostActiveChatTitle,
                                subtitle = "${stats.mostActiveChatMessages} messages échangés",
                                modifier = Modifier.weight(1f)
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            InsightMiniCard(
                                icon = Icons.Default.PhoneInTalk,
                                title = "Temps d'appels",
                                value = "${stats.callsDurationMinutes} min",
                                subtitle = "Audio & Vidéo E2EE",
                                modifier = Modifier.weight(1f)
                            )

                            InsightMiniCard(
                                icon = Icons.Default.Security,
                                title = "Chiffrement",
                                value = "100%",
                                subtitle = "Toutes sessions Signal E2EE",
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            // Bouton de navigation vers gestion détaillée du stockage
            item {
                Button(
                    onClick = { viewModel.navigateTo(AppScreen.STORAGE_MANAGEMENT) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("btn_goto_storage_management"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = AdtPrimary)
                ) {
                    Icon(Icons.Default.Storage, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Gérer l'espace disque & vider le cache", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

/**
 * Carte KPI stylisée pour un indicateur clé.
 */
@Composable
fun SummaryKpiCard(
    title: String,
    value: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconTint: Color,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = if (isSelected) iconTint.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
        border = BorderStroke(
            width = if (isSelected) 1.5.dp else 1.dp,
            color = if (isSelected) iconTint else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f)
        ),
        modifier = modifier.clickable { onClick() }
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = title,
                    fontSize = 11.5.sp,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconTint,
                    modifier = Modifier.size(16.dp)
                )
            }
            Text(
                text = value,
                fontSize = 15.5.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = subtitle,
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

/**
 * Graphique en barres interactif avec rendu Canvas sur mesure inspiré de D3.js et Recharts.
 * Prend en charge l'animation des barres, l'ombrage dynamique, les axes et l'état sélectionné.
 */
@Composable
fun InteractiveUsageBarChart(
    dailyStats: List<DailyUsageStat>,
    metricTab: Int,
    hoveredIndex: Int?,
    onSelectDay: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val barColor = when (metricTab) {
        0 -> StatScreenTimeColor
        1 -> StatMessagesColor
        else -> StatDataColor
    }

    if (dailyStats.isEmpty()) {
        Box(modifier = modifier, contentAlignment = Alignment.Center) {
            Text("Aucune donnée pour cette période", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
        }
        return
    }

    // Calcul des valeurs maximales pour l'échelle
    val values = remember(dailyStats, metricTab) {
        dailyStats.map { stat ->
            when (metricTab) {
                0 -> stat.screenTimeMinutes.toFloat()
                1 -> stat.totalMessages.toFloat()
                else -> (stat.totalDataBytes / (1024f * 1024f)) // en Mo
            }
        }
    }
    val maxValue = remember(values) {
        (values.maxOrNull() ?: 10f).coerceAtLeast(10f)
    }

    Column(modifier = modifier) {
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val canvasWidth = size.width
                val canvasHeight = size.height
                val count = dailyStats.size
                if (count == 0) return@Canvas

                val barWidth = (canvasWidth / count) * 0.55f
                val spacing = canvasWidth / count

                // Lignes de repère horizontales (grille D3 style)
                val gridLines = 3
                for (g in 0..gridLines) {
                    val y = canvasHeight * (g.toFloat() / gridLines)
                    drawLine(
                        color = Color.Gray.copy(alpha = 0.15f),
                        start = Offset(0f, y),
                        end = Offset(canvasWidth, y),
                        strokeWidth = 1.dp.toPx()
                    )
                }

                // Dessin des barres
                dailyStats.forEachIndexed { index, _ ->
                    val value = values.getOrElse(index) { 0f }
                    val barHeight = (value / maxValue) * (canvasHeight * 0.88f)
                    val x = (index * spacing) + (spacing - barWidth) / 2f
                    val y = canvasHeight - barHeight

                    val isHovered = hoveredIndex == index
                    val currentBarBrush = Brush.verticalGradient(
                        colors = listOf(
                            if (isHovered) Color.White else barColor,
                            if (isHovered) barColor else barColor.copy(alpha = 0.65f)
                        )
                    )

                    // Ombre / effet glow pour la barre sélectionnée
                    if (isHovered) {
                        drawRoundRect(
                            color = barColor.copy(alpha = 0.25f),
                            topLeft = Offset(x - 3.dp.toPx(), y - 3.dp.toPx()),
                            size = Size(barWidth + 6.dp.toPx(), barHeight + 3.dp.toPx()),
                            cornerRadius = CornerRadius(8.dp.toPx(), 8.dp.toPx())
                        )
                    }

                    // Barre principale
                    drawRoundRect(
                        brush = currentBarBrush,
                        topLeft = Offset(x, y),
                        size = Size(barWidth, barHeight.coerceAtLeast(4.dp.toPx())),
                        cornerRadius = CornerRadius(6.dp.toPx(), 6.dp.toPx())
                    )
                }
            }

            // Zone tactile transparente pour interagir avec chaque barre
            Row(modifier = Modifier.fillMaxSize()) {
                dailyStats.forEachIndexed { index, _ ->
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .clickable { onSelectDay(index) }
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Axe X avec les étiquettes de jour
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            dailyStats.forEachIndexed { index, stat ->
                val isSelected = hoveredIndex == index
                Text(
                    text = stat.dayLabel,
                    fontSize = 10.5.sp,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                    color = if (isSelected) barColor else MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .clickable { onSelectDay(index) }
                        .padding(vertical = 2.dp)
                )
            }
        }
    }
}

/**
 * Barre de progression segmentée proportionnelle représentant le trafic par catégorie.
 */
@Composable
fun SegmentedDataUsageBar(
    categories: List<DataUsageCategory>,
    modifier: Modifier = Modifier
) {
    Row(modifier = modifier) {
        categories.forEach { cat ->
            if (cat.percentage > 0f) {
                Box(
                    modifier = Modifier
                        .weight(cat.percentage.coerceAtLeast(1f))
                        .fillMaxHeight()
                        .background(Color(cat.colorHex))
                )
            }
        }
    }
}

/**
 * Carte miniature présentant un insight ou comportement d'utilisation.
 */
@Composable
fun InsightMiniCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    value: String,
    subtitle: String,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surface,
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(icon, contentDescription = null, tint = AdtPrimary, modifier = Modifier.size(15.dp))
                Text(title, fontSize = 11.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text(value, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(subtitle, fontSize = 10.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

/**
 * Section complète d'Utilisation Réseau détaillée par type de média (messages, photos, vidéos, appels),
 * conçue pour permettre à l'utilisateur de surveiller et maîtriser son forfait data mobile.
 */
@Composable
fun NetworkUsageDetailsCard(
    mediaDetails: List<MediaNetworkUsageDetail>,
    totalDataSent: String,
    totalDataReceived: String,
    totalDataSaved: String,
    onManageDataThrottles: () -> Unit,
    modifier: Modifier = Modifier
) {
    var expandedItemTitle by remember { mutableStateOf<String?>(null) }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("card_network_usage_details"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f))
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // En-tête de section
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .background(AdtPrimary.copy(alpha = 0.15f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.SignalCellularAlt,
                            contentDescription = null,
                            tint = AdtPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Column {
                        Text(
                            text = "Utilisation Réseau & Forfait Data",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Consommation détaillée par média (envois & réceptions)",
                            fontSize = 11.5.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // Bannière synthèse data (Envois vs Réceptions + Données économisées)
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(Icons.Default.ArrowUpward, contentDescription = null, tint = AdtAccentGreen, modifier = Modifier.size(13.dp))
                            Text("Envoyées", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Text(totalDataSent, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
                    }

                    Box(
                        modifier = Modifier
                            .height(28.dp)
                            .width(1.dp)
                            .background(MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                    )

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(Icons.Default.ArrowDownward, contentDescription = null, tint = StatScreenTimeColor, modifier = Modifier.size(13.dp))
                            Text("Reçues", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Text(totalDataReceived, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
                    }

                    Box(
                        modifier = Modifier
                            .height(28.dp)
                            .width(1.dp)
                            .background(MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                    )

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(Icons.Default.Savings, contentDescription = null, tint = AdtPrimary, modifier = Modifier.size(13.dp))
                            Text("Économisées", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Text(totalDataSaved, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = AdtPrimary)
                    }
                }
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 2.dp))

            // Liste accordéon interactive des 5 types de trafic
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                mediaDetails.forEach { item ->
                    val isExpanded = expandedItemTitle == item.mediaTypeTitle
                    MediaNetworkDetailRow(
                        detail = item,
                        isExpanded = isExpanded,
                        onToggleExpand = {
                            expandedItemTitle = if (isExpanded) null else item.mediaTypeTitle
                        }
                    )
                }
            }

            // Conseil gestion forfait & raccourci vers économiseur de données
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = AdtPrimary.copy(alpha = 0.08f),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onManageDataThrottles() }
                    .testTag("banner_manage_data_saver")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        Icons.Default.Bolt,
                        contentDescription = null,
                        tint = AdtPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Optimiser mon forfait data",
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 12.5.sp,
                            color = AdtPrimary
                        )
                        Text(
                            text = "Ajuster les seuils de téléchargement automatique et activer le mode Économie d'énergie",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Icon(
                        Icons.Default.ChevronRight,
                        contentDescription = null,
                        tint = AdtPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

/**
 * Fiche détaillée pour un média réseau (photos, vidéos, appels, messages).
 */
@Composable
fun MediaNetworkDetailRow(
    detail: MediaNetworkUsageDetail,
    isExpanded: Boolean,
    onToggleExpand: () -> Unit
) {
    val icon = when (detail.iconKey) {
        "VIDEOS" -> Icons.Default.Videocam
        "PHOTOS" -> Icons.Default.Photo
        "CALLS" -> Icons.Default.PhoneInTalk
        "DOCS" -> Icons.Default.Description
        else -> Icons.Default.Chat
    }

    Surface(
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(
            width = if (isExpanded) 1.5.dp else 1.dp,
            color = if (isExpanded) Color(detail.colorHex) else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f)
        ),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onToggleExpand() }
            .testTag("row_media_network_${detail.iconKey.lowercase()}")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Ligne principale : icône, titre, volume total & pourcentage
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .background(Color(detail.colorHex).copy(alpha = 0.15f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = null,
                            tint = Color(detail.colorHex),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Column {
                        Text(
                            text = detail.mediaTypeTitle,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 13.5.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "${detail.itemsCount} éléments échangés",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = detail.formattedTotalBytes,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.5.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = String.format(java.util.Locale.US, "%.1f%% du total", detail.percentageOfTotal),
                        fontSize = 10.5.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(detail.colorHex)
                    )
                }
            }

            // Jauge de progression proportionnelle de la part du média
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(fraction = (detail.percentageOfTotal / 100f).coerceIn(0.04f, 1f))
                        .fillMaxHeight()
                        .background(Color(detail.colorHex))
                )
            }

            // Détail étendu animé : Envois vs Réceptions + Conseil Data Saver
            AnimatedVisibility(
                visible = isExpanded,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 6.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    HorizontalDivider(modifier = Modifier.padding(vertical = 2.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(Icons.Default.Upload, contentDescription = null, tint = AdtAccentGreen, modifier = Modifier.size(13.dp))
                            Text("Émis : ", fontSize = 11.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(detail.formattedSentBytes, fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(Icons.Default.Download, contentDescription = null, tint = StatScreenTimeColor, modifier = Modifier.size(13.dp))
                            Text("Reçus : ", fontSize = 11.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(detail.formattedReceivedBytes, fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    // Conseil d'économie
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                Icons.Default.Lightbulb,
                                contentDescription = null,
                                tint = Color(detail.colorHex),
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = detail.dataSaverAdvice,
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                lineHeight = 15.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
