package com.example.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CountryData
import com.example.data.model.CountryItem
import com.example.ui.theme.AdtPrimary

/**
 * Reusable international phone number input with separate country dial code selector (WhatsApp style).
 * Allows user to pick country from a searchable modal, type/edit dial code separately,
 * and type the phone number separately with instant auto-formatting and detection.
 */
@Composable
fun PhoneWithDialCodeInput(
    selectedCountry: CountryItem,
    enteredDialCode: String,
    phoneNumber: String,
    onCountrySelected: (CountryItem) -> Unit,
    onDialCodeChanged: (String) -> Unit,
    onPhoneNumberChanged: (String) -> Unit,
    modifier: Modifier = Modifier,
    label: String = "Numéro de téléphone",
    placeholder: String = selectedCountry.exampleNumber,
    isError: Boolean = false,
    errorMessage: String? = null,
    onDone: (() -> Unit)? = null
) {
    var showCountryPicker by remember { mutableStateOf(false) }

    Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(6.dp)) {
        // Country Selector Tile
        OutlinedCard(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { showCountryPicker = true }
                .testTag("btn_select_country_tile"),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.outlinedCardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 11.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(selectedCountry.flagEmoji, fontSize = 22.sp)
                    Text(
                        text = selectedCountry.name,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = selectedCountry.dialCode,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = AdtPrimary
                    )
                    Icon(
                        Icons.Default.ArrowDropDown,
                        contentDescription = "Changer pays",
                        tint = AdtPrimary,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
        }

        // Dual Input Row: Indicatif à part (+Code) & Numéro de téléphone à part
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.Top
        ) {
            // Separate Dial Code Input
            OutlinedTextField(
                value = enteredDialCode.removePrefix("+"),
                onValueChange = { input ->
                    val digits = input.filter { it.isDigit() }.take(4)
                    onDialCodeChanged(digits)
                    if (digits.isNotEmpty()) {
                        val match = CountryData.findByDialCode("+$digits")
                        if (match != null) {
                            onCountrySelected(match)
                        }
                    }
                },
                label = { Text("Indicatif", fontSize = 12.sp) },
                prefix = {
                    Text(
                        "+",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = AdtPrimary
                    )
                },
                singleLine = true,
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Number,
                    imeAction = ImeAction.Next
                ),
                textStyle = LocalTextStyle.current.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .width(112.dp)
                    .testTag("input_separate_dial_code"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = AdtPrimary,
                    focusedLabelColor = AdtPrimary
                )
            )

            // Separate Phone Number Input
            OutlinedTextField(
                value = phoneNumber,
                onValueChange = { input ->
                    // Auto-detect country only if user pastes full number with international prefix (+221..., 00221..., etc.)
                    val detected = CountryData.detectCountryAndNumber(input)
                    if (detected != null) {
                        val (c, remaining) = detected
                        onCountrySelected(c)
                        onDialCodeChanged(c.dialCode.removePrefix("+"))
                        onPhoneNumberChanged(remaining)
                    } else {
                        val dial = enteredDialCode.trim().removePrefix("+")
                        val countryDial = selectedCountry.dialCode
                        val clean = if (input.startsWith(countryDial)) {
                            input.removePrefix(countryDial).trim()
                        } else if (dial.isNotEmpty() && input.startsWith("+$dial")) {
                            input.removePrefix("+$dial").trim()
                        } else if (dial.isNotEmpty() && input.startsWith(dial)) {
                            input.removePrefix(dial).trim()
                        } else if (input.startsWith(countryDial.removePrefix("+"))) {
                            input.removePrefix(countryDial.removePrefix("+")).trim()
                        } else {
                            input.filter { it.isDigit() || it == ' ' }
                        }
                        onPhoneNumberChanged(clean)
                    }
                },
                label = { Text(label, fontSize = 12.sp) },
                placeholder = { Text(placeholder, fontSize = 13.sp) },
                trailingIcon = {
                    if (phoneNumber.isNotBlank()) {
                        IconButton(onClick = { onPhoneNumberChanged("") }) {
                            Icon(Icons.Default.Clear, contentDescription = "Effacer", modifier = Modifier.size(18.dp))
                        }
                    }
                },
                singleLine = true,
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Phone,
                    imeAction = if (onDone != null) ImeAction.Done else ImeAction.Next
                ),
                keyboardActions = KeyboardActions(
                    onDone = { onDone?.invoke() }
                ),
                textStyle = LocalTextStyle.current.copy(
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Medium
                ),
                isError = isError,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .weight(1f)
                    .testTag("input_separate_phone_number"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = AdtPrimary,
                    focusedLabelColor = AdtPrimary
                )
            )
        }

        // Error message if any
        if (isError && !errorMessage.isNullOrBlank()) {
            Text(
                text = errorMessage,
                color = MaterialTheme.colorScheme.error,
                fontSize = 11.sp,
                modifier = Modifier.padding(start = 4.dp)
            )
        }

        // Full formatted preview confirmation pill
        if (phoneNumber.isNotBlank()) {
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = AdtPrimary.copy(alpha = 0.08f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(selectedCountry.flagEmoji, fontSize = 14.sp)
                    val activeDial = enteredDialCode.trim().removePrefix("+").ifBlank { selectedCountry.dialCode.removePrefix("+") }
                    var cleanPreviewNumber = phoneNumber.trim()
                    if (cleanPreviewNumber.startsWith(activeDial)) {
                        cleanPreviewNumber = cleanPreviewNumber.removePrefix(activeDial).trim()
                    }
                    Text(
                        text = "Format international : +$activeDial $cleanPreviewNumber",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = AdtPrimary
                    )
                }
            }
        }
    }

    // Modal dialog to search and pick country
    if (showCountryPicker) {
        CountryPickerDialog(
            onDismiss = { showCountryPicker = false },
            onSelectCountry = { country ->
                onCountrySelected(country)
                onDialCodeChanged(country.dialCode.removePrefix("+"))
                showCountryPicker = false
            }
        )
    }
}

/**
 * Searchable modal dialog for picking country & dial code with region filtering.
 */
@Composable
fun CountryPickerDialog(
    onDismiss: () -> Unit,
    onSelectCountry: (CountryItem) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedRegion by remember { mutableStateOf("Tous") }

    val filteredCountries = remember(searchQuery, selectedRegion) {
        CountryData.supportedCountries.filter {
            CountryData.matchesSearch(it, searchQuery, selectedRegion)
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(Icons.Default.Public, contentDescription = null, tint = AdtPrimary)
                Column {
                    Text("Sélectionner l'indicatif pays", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text(
                        text = "${filteredCountries.size} pays disponibles",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Rechercher pays ou indicatif...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Default.Clear, contentDescription = "Effacer")
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("search_country_picker_input")
                )

                // Region filter chips
                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(CountryData.availableRegions) { region ->
                        val isSelected = region == selectedRegion
                        FilterChip(
                            selected = isSelected,
                            onClick = { selectedRegion = region },
                            label = { Text(region, fontSize = 12.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = AdtPrimary,
                                selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                            )
                        )
                    }
                }

                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(320.dp)
                ) {
                    items(filteredCountries, key = { it.name + it.dialCode }) { country ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onSelectCountry(country) }
                                .padding(vertical = 10.dp, horizontal = 4.dp)
                                .testTag("country_item_${country.dialCode.removePrefix("+")}"),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(country.flagEmoji, fontSize = 22.sp)
                                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Text(country.name, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                                        Surface(
                                            shape = RoundedCornerShape(4.dp),
                                            color = MaterialTheme.colorScheme.surfaceVariant
                                        ) {
                                            Text(
                                                text = country.region,
                                                fontSize = 9.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                            )
                                        }
                                    }
                                    Text(
                                        text = "Ex: ${country.exampleNumber}",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = AdtPrimary.copy(alpha = 0.12f)
                            ) {
                                Text(
                                    text = country.dialCode,
                                    color = AdtPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Fermer")
            }
        }
    )
}
