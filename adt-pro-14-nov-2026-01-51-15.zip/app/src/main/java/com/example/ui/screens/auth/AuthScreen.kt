package com.example.ui.screens.auth

import android.app.Activity
import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.auth.PhoneAuthState
import com.example.data.model.CountryData
import com.example.data.model.CountryItem
import com.example.ui.components.AdtAvatar
import com.example.ui.components.HomeColorPickerDialog
import com.example.ui.components.OperatorBadge
import com.example.ui.theme.*
import com.example.ui.util.AppLanguage
import com.example.ui.util.getStringsForLanguage
import com.example.viewmodel.AdtViewModel
import com.example.viewmodel.AppScreen

@Composable
fun AuthFlowScreen(viewModel: AdtViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsState()

    when (currentScreen) {
        AppScreen.AUTH_PHONE -> PhoneInputScreen(viewModel)
        AppScreen.AUTH_OTP -> OtpVerificationScreen(viewModel)
        AppScreen.AUTH_PROFILE -> ProfileSetupScreen(viewModel)
        else -> PhoneInputScreen(viewModel)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PhoneInputScreen(viewModel: AdtViewModel) {
    val context = LocalContext.current
    val activity = context as? Activity

    val isLoginMode by viewModel.isLoginMode.collectAsState()
    val selectedCountry by viewModel.selectedCountry.collectAsState()
    val enteredDialCode by viewModel.enteredDialCode.collectAsState()
    val enteredPhone by viewModel.enteredPhoneNumber.collectAsState()
    val selectedOperator by viewModel.selectedOperator.collectAsState()
    val authState by viewModel.phoneAuthState.collectAsState()
    val authError by viewModel.authErrorMessage.collectAsState()
    val isCredentialLoading by viewModel.isCredentialLoading.collectAsState()
    val credentialMessage by viewModel.credentialManagerMessage.collectAsState()
    val detectedCredential by viewModel.detectedCredential.collectAsState()
    val appSettings by viewModel.appSettings.collectAsState()

    val currentLang = remember(appSettings?.language) {
        AppLanguage.fromCode(appSettings?.language)
    }
    val strings = remember(appSettings?.language) {
        getStringsForLanguage(appSettings?.language)
    }

    val homePaletteColor by viewModel.homeColorTheme.collectAsState()
    val homePrimary = if (homePaletteColor == AdtPaletteColor.BLANCHE) Color(0xFF2E2E2E) else if (homePaletteColor == AdtPaletteColor.VERT) AdtPrimary else homePaletteColor.primary
    var showHomeColorPicker by remember { mutableStateOf(false) }

    var showCountryDialog by remember { mutableStateOf(false) }
    var showLanguageDialog by remember { mutableStateOf(false) }
    var countrySearchQuery by remember { mutableStateOf("") }

    val isLoading = authState is PhoneAuthState.SendingCode

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            Icons.Default.Security,
                            contentDescription = null,
                            tint = homePrimary,
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = if (isLoginMode) strings.authPhoneTitle else strings.authProfileTitle,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = { showHomeColorPicker = true },
                        modifier = Modifier.testTag("btn_auth_color_picker")
                    ) {
                        Box(
                            modifier = Modifier
                                .size(24.dp)
                                .clip(CircleShape)
                                .background(homePaletteColor.primary)
                                .border(
                                    1.dp,
                                    if (homePaletteColor == AdtPaletteColor.BLANCHE) Color.Gray else MaterialTheme.colorScheme.outline.copy(alpha = 0.4f),
                                    CircleShape
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Default.Palette,
                                contentDescription = "Changer la couleur d'accueil",
                                tint = if (homePaletteColor == AdtPaletteColor.BLANCHE) Color.Black else Color.White,
                                modifier = Modifier.size(13.dp)
                            )
                        }
                    }

                    FilledTonalButton(
                        onClick = { showLanguageDialog = true },
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.padding(end = 8.dp)
                    ) {
                        Text(currentLang.flag, fontSize = 16.sp)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(currentLang.displayName.take(8), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 20.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Auth Mode Toggle (Login vs Register)
            item {
                TabRow(
                    selectedTabIndex = if (isLoginMode) 0 else 1,
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    contentColor = homePrimary,
                    indicator = { tabPositions ->
                        TabRowDefaults.SecondaryIndicator(
                            Modifier.tabIndicatorOffset(tabPositions[if (isLoginMode) 0 else 1]),
                            color = homePrimary
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                ) {
                    Tab(
                        selected = isLoginMode,
                        onClick = { viewModel.toggleAuthMode(true) },
                        text = {
                            Text(
                                "Se Connecter",
                                fontWeight = if (isLoginMode) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 14.sp
                            )
                        },
                        modifier = Modifier.testTag("auth_tab_login")
                    )
                    Tab(
                        selected = !isLoginMode,
                        onClick = { viewModel.toggleAuthMode(false) },
                        text = {
                            Text(
                                "Créer un Compte",
                                fontWeight = if (!isLoginMode) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 14.sp
                            )
                        },
                        modifier = Modifier.testTag("auth_tab_signup")
                    )
                }
            }

            // Header Icon & Title
            item {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.padding(top = 4.dp)
                ) {
                    androidx.compose.foundation.Image(
                        painter = androidx.compose.ui.res.painterResource(id = com.example.R.drawable.img_app_logo_adt),
                        contentDescription = "Logo ADT Messenger",
                        modifier = Modifier
                            .size(76.dp)
                            .clip(RoundedCornerShape(18.dp))
                    )

                    Text(
                        text = if (isLoginMode) "Bon retour sur ADT Pro" else "Vérification par Numéro Mobile",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )

                    Text(
                        text = if (isLoginMode)
                            "Entrez votre numéro de téléphone mobile pour recevoir votre code de connexion sécurisé Firebase."
                        else
                            "ADT Pro utilise Firebase Phone Authentication pour valider votre numéro via un SMS gratuit sans mot de passe.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 8.dp)
                    )
                }
            }

            // Firebase Phone Auth Trust Badge
            item {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = AdtPrimary.copy(alpha = 0.08f)
                    ),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, AdtPrimary.copy(alpha = 0.25f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = AdtPrimary,
                            modifier = Modifier.size(28.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.VerifiedUser,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                        Column {
                            Text(
                                text = "Firebase Auth & Credential Manager",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = AdtPrimary
                            )
                            Text(
                                text = "SDK Firebase Phone • Gestionnaire d'identifiants Android • Sécurisé E2E",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            // Credential Manager Fast Selection / 1-Tap Sign-In Card
            item {
                OutlinedCard(
                    colors = CardDefaults.outlinedCardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                    ),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Key,
                                contentDescription = null,
                                tint = AdtPrimary,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = "Gestionnaire d'identifiants Android",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        Text(
                            text = "Accédez rapidement à votre compte grâce à vos identifiants téléphoniques enregistrés de façon sécurisée sur votre appareil.",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        FilledTonalButton(
                            onClick = {
                                viewModel.fetchCredentialManagerAccount(activity)
                            },
                            enabled = !isCredentialLoading,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(44.dp)
                                .testTag("btn_credential_manager"),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            if (isCredentialLoading) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(16.dp),
                                    strokeWidth = 2.dp,
                                    color = AdtPrimary
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Recherche d'identifiant...", fontSize = 12.sp)
                            } else {
                                Icon(
                                    imageVector = Icons.Default.Fingerprint,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp),
                                    tint = AdtPrimary
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Connexion avec Credential Manager",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }

                        if (credentialMessage != null) {
                            Surface(
                                color = AdtPrimary.copy(alpha = 0.1f),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = credentialMessage ?: "",
                                    fontSize = 11.sp,
                                    color = AdtPrimary,
                                    fontWeight = FontWeight.Medium,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Detected Credential 1-Tap Fast Sign-In Card
            if (detectedCredential != null) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = AdtPrimary.copy(alpha = 0.10f)
                        ),
                        border = BorderStroke(1.5.dp, AdtPrimary),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Surface(
                                    shape = CircleShape,
                                    color = AdtPrimary,
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Default.Key,
                                            contentDescription = null,
                                            tint = Color.White,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Identifiant enregistré trouvé",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = AdtPrimary
                                    )
                                    Text(
                                        text = "${detectedCredential?.phoneNumber}${if (!detectedCredential?.displayName.isNullOrBlank()) " • ${detectedCredential?.displayName}" else ""}",
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = { viewModel.loginWithDetectedCredential(activity) },
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(42.dp)
                                        .testTag("btn_1tap_credential_login"),
                                    shape = RoundedCornerShape(10.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = AdtPrimary)
                                ) {
                                    Icon(Icons.Default.FlashOn, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Connexion 1-Tap", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }

                                OutlinedButton(
                                    onClick = { viewModel.requestOtp(activity) },
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(42.dp)
                                        .testTag("btn_sms_from_credential"),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Icon(Icons.Default.Sms, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Code SMS", fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }

            // Country Selector Card (WhatsApp Style)
            item {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "Pays sélectionné :",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedCard(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showCountryDialog = true }
                            .testTag("select_country_card"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(selectedCountry.flagEmoji, fontSize = 24.sp)
                                Text(
                                    selectedCountry.name,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 15.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = selectedCountry.dialCode,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = AdtPrimary
                                )
                                Icon(
                                    Icons.Default.ArrowDropDown,
                                    contentDescription = "Choisir pays",
                                    tint = AdtPrimary,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }
                    }
                }
            }

            // WhatsApp Style Dual Input: Indicatif à part (+Code) & Numéro de téléphone à part
            item {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Numéro de téléphone :",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "Indicatif à part • Comme WhatsApp",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = AdtPrimary
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        // Separate Country Dial Code Field
                        OutlinedTextField(
                            value = enteredDialCode.removePrefix("+"),
                            onValueChange = { viewModel.onDialCodeChange(it) },
                            label = { Text("Indicatif", fontSize = 11.sp) },
                            prefix = {
                                Text(
                                    "+",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp,
                                    color = AdtPrimary
                                )
                            },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.Number,
                                imeAction = ImeAction.Next
                            ),
                            textStyle = LocalTextStyle.current.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .width(112.dp)
                                .testTag("dial_code_input_field"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = AdtPrimary,
                                focusedLabelColor = AdtPrimary
                            )
                        )

                        // Separate Phone Number Field
                        OutlinedTextField(
                            value = enteredPhone,
                            onValueChange = { viewModel.onPhoneNumberChange(it) },
                            label = { Text("Numéro", fontSize = 11.sp) },
                            placeholder = { Text(selectedCountry.exampleNumber, fontSize = 14.sp) },
                            trailingIcon = {
                                if (enteredPhone.isNotBlank()) {
                                    IconButton(onClick = { viewModel.enteredPhoneNumber.value = "" }) {
                                        Icon(Icons.Default.Clear, contentDescription = "Effacer", modifier = Modifier.size(18.dp))
                                    }
                                }
                            },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.Phone,
                                imeAction = ImeAction.Done
                            ),
                            keyboardActions = KeyboardActions(
                                onDone = {
                                    if (enteredPhone.length >= 6 && !isLoading) {
                                        viewModel.requestOtp(activity)
                                    }
                                }
                            ),
                            textStyle = LocalTextStyle.current.copy(
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Medium
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("phone_input_field"),
                            shape = RoundedCornerShape(12.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = AdtPrimary,
                                focusedLabelColor = AdtPrimary
                            )
                        )
                    }

                    // Number confirmation preview
                    if (enteredPhone.isNotBlank()) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = AdtPrimary.copy(alpha = 0.08f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = AdtPrimary, modifier = Modifier.size(14.dp))
                                val activeDial = enteredDialCode.trim().removePrefix("+").ifBlank { selectedCountry.dialCode.removePrefix("+") }
                                var cleanPreview = enteredPhone.trim()
                                if (cleanPreview.startsWith(activeDial)) {
                                    cleanPreview = cleanPreview.removePrefix(activeDial).trim()
                                }
                                Text(
                                    text = "Numéro complet : +$activeDial $cleanPreview",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = AdtPrimary
                                )
                            }
                        }
                    }
                }
            }

            // Operator Selector Chips
            item {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "Opérateur téléphonique :",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(selectedCountry.defaultOperators) { op ->
                            FilterChip(
                                selected = selectedOperator == op,
                                onClick = { viewModel.selectOperator(op) },
                                label = { Text(op, fontSize = 12.sp) },
                                leadingIcon = {
                                    if (selectedOperator == op) {
                                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                                    }
                                }
                            )
                        }
                    }
                }
            }

            // Auth Error Message Banner if any
            if (authError != null) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.ErrorOutline, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                            Text(
                                text = authError ?: "",
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }

            // Demo / Test Numbers Preset Helper
            item {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(Icons.Default.Speed, contentDescription = null, tint = AdtPrimary, modifier = Modifier.size(16.dp))
                        Text(
                            text = "Comptes de test / Numéros de démonstration :",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        item {
                            SuggestionChip(
                                onClick = {
                                    viewModel.applyPresetPhoneNumber("Mali", "66123456", "Orange", "Amadou", "Traoré")
                                },
                                label = { Text("🇲🇱 +223 66 12 34 56 (Mali - Orange)", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                            )
                        }
                        item {
                            SuggestionChip(
                                onClick = {
                                    viewModel.applyPresetPhoneNumber("Mali", "70001122", "Moov Africa", "Fatoumata", "Coulibaly")
                                },
                                label = { Text("🇲🇱 +223 70 00 11 22 (Mali - Moov)", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                            )
                        }
                        item {
                            SuggestionChip(
                                onClick = {
                                    viewModel.applyPresetPhoneNumber("RD Congo", "812345678", "Vodacom", "Kabongo", "Mukendi")
                                },
                                label = { Text("🇨🇩 +243 81 234 56 78 (RDC - Kinshasa)", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                            )
                        }
                        item {
                            SuggestionChip(
                                onClick = {
                                    viewModel.applyPresetPhoneNumber("Kenya", "712345678", "Safaricom", "David", "Kimani")
                                },
                                label = { Text("🇰🇪 +254 712 345 678 (Kenya - Nairobi)", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                            )
                        }
                        item {
                            SuggestionChip(
                                onClick = {
                                    viewModel.applyPresetPhoneNumber("Tanzanie", "712345678", "Vodacom", "Asha", "Mwangi")
                                },
                                label = { Text("🇹🇿 +255 712 345 678 (Tanzanie - Dar)", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                            )
                        }
                        item {
                            SuggestionChip(
                                onClick = {
                                    viewModel.applyPresetPhoneNumber("Sénégal", "770001122", "Orange", "Moussa", "Diop")
                                },
                                label = { Text("🇸🇳 +221 77 000 11 22 (Dakar)", fontSize = 11.sp) }
                            )
                        }
                        item {
                            SuggestionChip(
                                onClick = {
                                    viewModel.applyPresetPhoneNumber("Mauritanie", "45123456", "Mauritel", "Ahmed", "Ould")
                                },
                                label = { Text("🇲🇷 +222 45 12 34 56 (Nouakchott)", fontSize = 11.sp) }
                            )
                        }
                        item {
                            SuggestionChip(
                                onClick = {
                                    viewModel.applyPresetPhoneNumber("Côte d'Ivoire", "0788990011", "Moov Africa", "Amina", "Traoré")
                                },
                                label = { Text("🇨🇮 +225 07 88 99 00 11 (Abidjan)", fontSize = 11.sp) }
                            )
                        }
                        item {
                            SuggestionChip(
                                onClick = {
                                    viewModel.applyPresetPhoneNumber("Cameroun", "699123456", "Orange", "Samuel", "Eto")
                                },
                                label = { Text("🇨🇲 +237 699 12 34 56 (Douala)", fontSize = 11.sp) }
                            )
                        }
                        item {
                            SuggestionChip(
                                onClick = {
                                    viewModel.applyPresetPhoneNumber("France", "0612345678", "Orange", "Sophie", "Laurent")
                                },
                                label = { Text("🇫🇷 +33 06 12 34 56 78 (Paris)", fontSize = 11.sp) }
                            )
                        }
                        item {
                            SuggestionChip(
                                onClick = {
                                    viewModel.applyPresetPhoneNumber("États-Unis", "2025550123", "AT&T", "Michael", "Smith")
                                },
                                label = { Text("🇺🇸 +1 202 555 0123 (USA)", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                            )
                        }
                        item {
                            SuggestionChip(
                                onClick = {
                                    viewModel.applyPresetPhoneNumber("Canada", "4165550199", "Rogers", "Marc", "Tremblay")
                                },
                                label = { Text("🇨🇦 +1 416 555 0199 (Canada)", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                            )
                        }
                        item {
                            SuggestionChip(
                                onClick = {
                                    viewModel.applyPresetPhoneNumber("Belgique", "470123456", "Proximus", "Lucas", "Peeters")
                                },
                                label = { Text("🇧🇪 +32 470 12 34 56 (Bruxelles)", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                            )
                        }
                        item {
                            SuggestionChip(
                                onClick = {
                                    viewModel.applyPresetPhoneNumber("Suisse", "781234567", "Swisscom", "Thomas", "Meier")
                                },
                                label = { Text("🇨🇭 +41 78 123 45 67 (Genève)", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                            )
                        }
                        item {
                            SuggestionChip(
                                onClick = {
                                    viewModel.applyPresetPhoneNumber("Royaume-Uni", "7911123456", "EE", "Oliver", "Brown")
                                },
                                label = { Text("🇬🇧 +44 7911 123456 (Londres)", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                            )
                        }
                        item {
                            SuggestionChip(
                                onClick = {
                                    viewModel.applyPresetPhoneNumber("Allemagne", "15112345678", "Telekom", "Lukas", "Schmidt")
                                },
                                label = { Text("🇩🇪 +49 151 12345678 (Berlin)", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                            )
                        }
                        item {
                            SuggestionChip(
                                onClick = {
                                    viewModel.applyPresetPhoneNumber("Mexique", "5512345678", "Telcel", "Alejandro", "Garcia")
                                },
                                label = { Text("🇲🇽 +52 55 1234 5678 (Mexico)", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                            )
                        }
                        item {
                            SuggestionChip(
                                onClick = {
                                    viewModel.applyPresetPhoneNumber("Brésil", "11912345678", "Vivo", "Gabriel", "Silva")
                                },
                                label = { Text("🇧🇷 +55 11 91234 5678 (São Paulo)", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                            )
                        }
                        item {
                            SuggestionChip(
                                onClick = {
                                    viewModel.applyPresetPhoneNumber("Colombie", "3001234567", "Claro", "Mateo", "Rodriguez")
                                },
                                label = { Text("🇨🇴 +57 300 123 4567 (Bogota)", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                            )
                        }
                        item {
                            SuggestionChip(
                                onClick = {
                                    viewModel.applyPresetPhoneNumber("Australie", "412345678", "Telstra", "Jack", "Taylor")
                                },
                                label = { Text("🇦🇺 +61 412 345 678 (Sydney)", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                            )
                        }
                        item {
                            SuggestionChip(
                                onClick = {
                                    viewModel.applyPresetPhoneNumber("Indonésie", "81234567890", "Telkomsel", "Budi", "Santoso")
                                },
                                label = { Text("🇮🇩 +62 812 3456 7890 (Jakarta)", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                            )
                        }
                        item {
                            SuggestionChip(
                                onClick = {
                                    viewModel.applyPresetPhoneNumber("Kazakhstan", "7011234567", "Beeline", "Arman", "Bolat")
                                },
                                label = { Text("🇰🇿 +7 701 123 45 67 (Almaty)", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                            )
                        }
                        item {
                            SuggestionChip(
                                onClick = {
                                    viewModel.applyPresetPhoneNumber("Russie", "9123456789", "MTS", "Dmitry", "Ivanov")
                                },
                                label = { Text("🇷🇺 +7 912 345 67 89 (Moscou)", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                            )
                        }
                        item {
                            SuggestionChip(
                                onClick = {
                                    viewModel.applyPresetPhoneNumber("Chine", "13800138000", "China Mobile", "Wei", "Zhang")
                                },
                                label = { Text("🇨🇳 +86 138 0013 8000 (Pékin)", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                            )
                        }
                        item {
                            SuggestionChip(
                                onClick = {
                                    viewModel.applyPresetPhoneNumber("Japon", "9012345678", "NTT Docomo", "Kenji", "Sato")
                                },
                                label = { Text("🇯🇵 +81 90 1234 5678 (Tokyo)", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                            )
                        }
                        item {
                            SuggestionChip(
                                onClick = {
                                    viewModel.applyPresetPhoneNumber("Corée du Sud", "1012345678", "SK Telecom", "Min-jun", "Kim")
                                },
                                label = { Text("🇰🇷 +82 10 1234 5678 (Séoul)", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                            )
                        }
                        item {
                            SuggestionChip(
                                onClick = {
                                    viewModel.applyPresetPhoneNumber("Turquie", "5321234567", "Turkcell", "Emre", "Yilmaz")
                                },
                                label = { Text("🇹🇷 +90 532 123 45 67 (Istanbul)", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                            )
                        }
                        item {
                            SuggestionChip(
                                onClick = {
                                    viewModel.applyPresetPhoneNumber("Inde", "9812345678", "Jio", "Aarav", "Sharma")
                                },
                                label = { Text("🇮🇳 +91 98123 45678 (New Delhi)", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                            )
                        }
                        item {
                            SuggestionChip(
                                onClick = {
                                    viewModel.applyPresetPhoneNumber("Arabie Saoudite", "501234567", "STC", "Mohammed", "Al-Otaibi")
                                },
                                label = { Text("🇸🇦 +966 50 123 4567 (Riyad)", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                            )
                        }
                        item {
                            SuggestionChip(
                                onClick = {
                                    viewModel.applyPresetPhoneNumber("Émirats Arabes Unis", "501234567", "e& (Etisalat)", "Rashid", "Al-Maktoum")
                                },
                                label = { Text("🇦🇪 +971 50 123 4567 (Dubaï)", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                            )
                        }
                        item {
                            SuggestionChip(
                                onClick = {
                                    viewModel.applyPresetPhoneNumber("Maroc", "612345678", "Maroc Telecom", "Yassine", "Benali")
                                },
                                label = { Text("🇲🇦 +212 612 34 56 78 (Casablanca)", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                            )
                        }
                        item {
                            SuggestionChip(
                                onClick = {
                                    viewModel.applyPresetPhoneNumber("Éthiopie", "911234567", "Ethio Telecom", "Abebe", "Bikila")
                                },
                                label = { Text("🇪🇹 +251 91 123 4567 (Addis-Abeba)", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                            )
                        }
                        item {
                            SuggestionChip(
                                onClick = {
                                    viewModel.applyPresetPhoneNumber("Égypte", "1012345678", "Vodafone", "Ahmed", "Hassan")
                                },
                                label = { Text("🇪🇬 +20 10 1234 5678 (Le Caire)", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                            )
                        }
                        item {
                            SuggestionChip(
                                onClick = {
                                    viewModel.applyPresetPhoneNumber("Norvège", "91234567", "Telenor", "Lars", "Hansen")
                                },
                                label = { Text("🇳🇴 +47 912 34 567 (Oslo)", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                            )
                        }
                        item {
                            SuggestionChip(
                                onClick = {
                                    viewModel.applyPresetPhoneNumber("Suède", "701234567", "Telia", "Erik", "Andersson")
                                },
                                label = { Text("🇸🇪 +46 70 123 45 67 (Stockholm)", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                            )
                        }
                        item {
                            SuggestionChip(
                                onClick = {
                                    viewModel.applyPresetPhoneNumber("Suisse", "781234567", "Swisscom", "Marc", "Dubois")
                                },
                                label = { Text("🇨🇭 +41 78 123 45 67 (Genève)", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                            )
                        }
                        item {
                            SuggestionChip(
                                onClick = {
                                    viewModel.applyPresetPhoneNumber("Israël", "501234567", "Cellcom", "David", "Cohen")
                                },
                                label = { Text("🇮🇱 +972 50 123 4567 (Tel Aviv)", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                            )
                        }
                        item {
                            SuggestionChip(
                                onClick = {
                                    viewModel.applyPresetPhoneNumber("Pakistan", "3001234567", "Jazz", "Ali", "Khan")
                                },
                                label = { Text("🇵🇰 +92 300 1234567 (Islamabad)", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                            )
                        }
                        item {
                            SuggestionChip(
                                onClick = {
                                    viewModel.applyPresetPhoneNumber("Panama", "61234567", "+Móvil", "Carlos", "Morales")
                                },
                                label = { Text("🇵🇦 +507 6123 4567 (Panama)", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                            )
                        }
                    }
                }
            }

            // Submit Button
            item {
                Spacer(modifier = Modifier.height(6.dp))
                Button(
                    onClick = {
                        if (enteredPhone.isNotBlank() && !isLoading) {
                            viewModel.requestOtp(activity)
                        }
                    },
                    enabled = enteredPhone.length >= 6 && !isLoading,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("btn_request_code"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = AdtPrimary)
                ) {
                    if (isLoading) {
                        CircularProgressIndicator(
                            color = Color.White,
                            modifier = Modifier.size(22.dp),
                            strokeWidth = 2.5.dp
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text("Envoi du code SMS Firebase...", color = Color.White, fontSize = 14.sp)
                    } else {
                        Icon(Icons.Default.Sms, contentDescription = null, tint = Color.White)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            if (isLoginMode) "Recevoir mon code de connexion par SMS OTP" else "Recevoir le code de vérification par SMS OTP",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = Color.White
                        )
                    }
                }
            }
        }
    }

    // Language Picker Dialog
    if (showLanguageDialog) {
        AlertDialog(
            onDismissRequest = { showLanguageDialog = false },
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(Icons.Default.Language, contentDescription = null, tint = AdtPrimary)
                    Text(strings.selectLanguageTitle, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                }
            },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    AppLanguage.entries.forEach { lang ->
                        val isSelected = currentLang == lang
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (isSelected) AdtPrimary.copy(alpha = 0.15f) else Color.Transparent,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.updateLanguage(lang.code)
                                    showLanguageDialog = false
                                }
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text(lang.flag, fontSize = 24.sp)
                                    Column {
                                        Text(
                                            "${lang.displayName} (${lang.countryName})",
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                            fontSize = 14.sp,
                                            color = if (isSelected) AdtPrimary else MaterialTheme.colorScheme.onSurface
                                        )
                                        Text(
                                            lang.description,
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                                if (isSelected) {
                                    Icon(
                                        Icons.Default.CheckCircle,
                                        contentDescription = null,
                                        tint = AdtPrimary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showLanguageDialog = false }) {
                    Text("OK", fontWeight = FontWeight.Bold, color = AdtPrimary)
                }
            }
        )
    }

    // Country Picker Dialog
    if (showCountryDialog) {
        var selectedCountryRegion by remember { mutableStateOf("Tous") }
        val filteredCountries = remember(countrySearchQuery, selectedCountryRegion) {
            CountryData.supportedCountries.filter {
                CountryData.matchesSearch(it, countrySearchQuery, selectedCountryRegion)
            }
        }

        AlertDialog(
            onDismissRequest = {
                showCountryDialog = false
                countrySearchQuery = ""
            },
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(Icons.Default.Public, contentDescription = null, tint = AdtPrimary)
                    Column {
                        Text("Sélectionnez votre pays", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text(
                            text = "${filteredCountries.size} pays disponibles",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = countrySearchQuery,
                        onValueChange = { countrySearchQuery = it },
                        placeholder = { Text("Rechercher un pays ou indicatif...") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                        trailingIcon = {
                            if (countrySearchQuery.isNotEmpty()) {
                                IconButton(onClick = { countrySearchQuery = "" }) {
                                    Icon(Icons.Default.Clear, contentDescription = "Effacer")
                                }
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth().testTag("auth_country_search_input")
                    )

                    // Region filter chips
                    LazyRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(CountryData.availableRegions) { region ->
                            val isSelected = region == selectedCountryRegion
                            FilterChip(
                                selected = isSelected,
                                onClick = { selectedCountryRegion = region },
                                label = { Text(region, fontSize = 12.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = AdtPrimary,
                                    selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                                )
                            )
                        }
                    }

                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(320.dp)
                    ) {
                        items(filteredCountries, key = { it.name + it.dialCode }) { country ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        viewModel.selectCountry(country)
                                        showCountryDialog = false
                                        countrySearchQuery = ""
                                    }
                                    .padding(vertical = 10.dp, horizontal = 4.dp)
                                    .testTag("country_select_${country.dialCode.removePrefix("+")}"),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text(country.flagEmoji, fontSize = 22.sp)
                                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Text(country.name, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                                            Surface(
                                                shape = RoundedCornerShape(4.dp),
                                                color = MaterialTheme.colorScheme.surfaceVariant
                                            ) {
                                                Text(
                                                    text = country.region,
                                                    fontSize = 9.sp,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                                )
                                            }
                                        }
                                        Text(
                                            text = "Ex: ${country.exampleNumber}",
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = AdtPrimary.copy(alpha = 0.12f)
                                ) {
                                    Text(
                                        text = country.dialCode,
                                        color = AdtPrimary,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }
                            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    showCountryDialog = false
                    countrySearchQuery = ""
                }) {
                    Text("Fermer")
                }
            }
        )
    }

    if (showHomeColorPicker) {
        HomeColorPickerDialog(
            currentPaletteColor = homePaletteColor,
            onSelectColor = { selected ->
                viewModel.setHomeColorTheme(selected)
            },
            onDismiss = { showHomeColorPicker = false }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OtpVerificationScreen(viewModel: AdtViewModel) {
    val context = LocalContext.current
    val activity = context as? Activity

    val selectedCountry by viewModel.selectedCountry.collectAsState()
    val enteredDialCode by viewModel.enteredDialCode.collectAsState()
    val enteredPhone by viewModel.enteredPhoneNumber.collectAsState()
    val selectedOperator by viewModel.selectedOperator.collectAsState()
    val enteredOtp by viewModel.enteredOtpCode.collectAsState()
    val generatedOtp by viewModel.generatedOtpCode.collectAsState()
    val bannerMsg by viewModel.otpBannerMessage.collectAsState()
    val authState by viewModel.phoneAuthState.collectAsState()
    val authError by viewModel.authErrorMessage.collectAsState()
    val resendCountdown by viewModel.resendCountdownSeconds.collectAsState()
    val isLoginMode by viewModel.isLoginMode.collectAsState()

    val isVerifying = authState is PhoneAuthState.VerifyingCode

    BackHandler {
        viewModel.navigateTo(AppScreen.AUTH_PHONE)
    }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("Code de vérification SMS", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateTo(AppScreen.AUTH_PHONE) }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Retour")
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 24.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Incoming SMS Banner / Simulation Notification
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = AdtPrimary.copy(alpha = 0.08f)
                    ),
                    border = BorderStroke(1.dp, AdtPrimary.copy(alpha = 0.35f)),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("sms_notification_banner")
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OperatorBadge(selectedOperator)
                                Text(
                                    "SMS reçu • $selectedOperator",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = AdtPrimary.copy(alpha = 0.15f)
                            ) {
                                Text(
                                    "À l'instant",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = AdtPrimary,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Text(
                            text = "ADT Pro : Votre code de vérification SMS est $generatedOtp. Valable 10 minutes. Ne le partagez avec personne.",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            FilledTonalButton(
                                onClick = { viewModel.autoFillOtp() },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(38.dp)
                                    .testTag("btn_autofill_otp"),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.ContentPaste, contentDescription = null, modifier = Modifier.size(15.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Insérer $generatedOtp", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }

                            Button(
                                onClick = {
                                    viewModel.autoFillOtp()
                                    viewModel.verifyOtp(activity, generatedOtp)
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(38.dp)
                                    .testTag("btn_direct_validate_otp"),
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = AdtPrimary)
                            ) {
                                Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(15.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Valider", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                Surface(
                    shape = CircleShape,
                    color = AdtPrimary.copy(alpha = 0.12f),
                    modifier = Modifier.size(52.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            Icons.Default.Pin,
                            contentDescription = null,
                            tint = AdtPrimary,
                            modifier = Modifier.size(26.dp)
                        )
                    }
                }

                Text(
                    text = "Entrez le code de validation reçu",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )

                val displayDialCode = if (enteredDialCode.isNotBlank()) "+$enteredDialCode" else selectedCountry.dialCode
                Text(
                    text = "Code envoyé par SMS au $displayDialCode $enteredPhone via $selectedOperator",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )

                // 6-digit segmented visual PIN box with BasicTextField
                BasicTextField(
                    value = enteredOtp,
                    onValueChange = {
                        val digits = it.filter { ch -> ch.isDigit() }.take(6)
                        viewModel.enteredOtpCode.value = digits
                        if (digits.length == 6) {
                            viewModel.verifyOtp(activity, digits)
                        }
                    },
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.NumberPassword,
                        imeAction = ImeAction.Done
                    ),
                    keyboardActions = KeyboardActions(
                        onDone = {
                            if (enteredOtp.length == 6 && !isVerifying) {
                                viewModel.verifyOtp(activity)
                            }
                        }
                    ),
                    modifier = Modifier.testTag("otp_input_field"),
                    decorationBox = {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            for (index in 0 until 6) {
                                val digit = enteredOtp.getOrNull(index)?.toString() ?: ""
                                val isFocused = index == enteredOtp.length
                                val hasError = authError != null

                                val borderColor = when {
                                    hasError -> MaterialTheme.colorScheme.error
                                    isFocused -> AdtPrimary
                                    digit.isNotEmpty() -> AdtPrimary.copy(alpha = 0.6f)
                                    else -> MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
                                }
                                val borderWidth = if (isFocused || hasError) 2.dp else 1.dp
                                val containerColor = if (isFocused) AdtPrimary.copy(alpha = 0.06f) else MaterialTheme.colorScheme.surface

                                Box(
                                    modifier = Modifier
                                        .width(46.dp)
                                        .height(56.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(containerColor)
                                        .border(borderWidth, borderColor, RoundedCornerShape(12.dp))
                                        .testTag("otp_digit_box_$index"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (digit.isNotEmpty()) {
                                        Text(
                                            text = digit,
                                            fontSize = 24.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    } else if (isFocused) {
                                        Box(
                                            modifier = Modifier
                                                .width(2.dp)
                                                .height(22.dp)
                                                .background(AdtPrimary)
                                        )
                                    } else {
                                        Box(
                                            modifier = Modifier
                                                .size(6.dp)
                                                .clip(CircleShape)
                                                .background(MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))
                                        )
                                    }
                                }
                            }
                        }
                    }
                )

                // Auth Error Banner
                if (authError != null) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.ErrorOutline, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                            Text(
                                text = authError ?: "",
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }

                // Resend Timer / Action
                if (resendCountdown > 0) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(Icons.Default.Timer, contentDescription = null, tint = AdtPrimary, modifier = Modifier.size(16.dp))
                        Text(
                            text = "Renvoyer le code SMS dans ${resendCountdown}s",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                } else {
                    TextButton(
                        onClick = { viewModel.resendOtp(activity) },
                        modifier = Modifier.testTag("btn_resend_otp")
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null, tint = AdtPrimary, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Renvoyer un nouveau code par SMS ($selectedOperator)", color = AdtPrimary, fontWeight = FontWeight.Bold)
                    }
                }

                // Change phone number action
                TextButton(onClick = { viewModel.navigateTo(AppScreen.AUTH_PHONE) }) {
                    Text("Modifier le numéro de téléphone", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            Button(
                onClick = {
                    if (enteredOtp.length == 6 && !isVerifying) {
                        viewModel.verifyOtp(activity)
                    }
                },
                enabled = enteredOtp.length == 6 && !isVerifying,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("btn_verify_otp"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = AdtPrimary)
            ) {
                if (isVerifying) {
                    CircularProgressIndicator(
                        color = Color.White,
                        modifier = Modifier.size(22.dp),
                        strokeWidth = 2.5.dp
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text("Validation du code SMS...", color = Color.White, fontSize = 14.sp)
                } else {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color.White)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        if (isLoginMode) "Valider par SMS OTP et se connecter" else "Valider le code SMS OTP",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = Color.White
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileSetupScreen(viewModel: AdtViewModel) {
    val context = LocalContext.current
    val activity = context as? Activity

    val firstName by viewModel.profileFirstName.collectAsState()
    val lastName by viewModel.profileLastName.collectAsState()
    val category by viewModel.profileBusinessCategory.collectAsState()
    val bio by viewModel.profileBio.collectAsState()
    val selectedCountry by viewModel.selectedCountry.collectAsState()
    val enteredPhone by viewModel.enteredPhoneNumber.collectAsState()
    val selectedOperator by viewModel.selectedOperator.collectAsState()

    val categories = listOf(
        "Compte Professionnel ADT",
        "Entreprise & Télécom",
        "Commerce & Ventes",
        "Consultant & Services",
        "Étudiant & Particulier"
    )

    BackHandler {
        viewModel.navigateTo(AppScreen.AUTH_PHONE)
    }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("Finalisation du profil", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Text(
                    text = "Votre numéro a été vérifié avec succès par Firebase ! Veuillez renseigner votre identité pour créer votre espace ADT Pro.",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
            }

            item {
                Spacer(modifier = Modifier.height(4.dp))
                // Avatar preview
                Box(contentAlignment = Alignment.BottomEnd) {
                    AdtAvatar(
                        name = if (firstName.isNotBlank() || lastName.isNotBlank()) "$firstName $lastName" else "ADT",
                        sizeDp = 92
                    )
                    Surface(
                        shape = CircleShape,
                        color = AdtPrimary,
                        modifier = Modifier.size(30.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                Icons.Default.CameraAlt,
                                contentDescription = "Changer la photo",
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }

            item {
                // Prénom input
                OutlinedTextField(
                    value = firstName,
                    onValueChange = { viewModel.profileFirstName.value = it },
                    label = { Text("Prénom *") },
                    placeholder = { Text("Ex: Amadou") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_first_name"),
                    shape = RoundedCornerShape(12.dp)
                )
            }

            item {
                // Nom input
                OutlinedTextField(
                    value = lastName,
                    onValueChange = { viewModel.profileLastName.value = it },
                    label = { Text("Nom de famille *") },
                    placeholder = { Text("Ex: Diallo") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_last_name"),
                    shape = RoundedCornerShape(12.dp)
                )
            }

            item {
                // Business Category Selector
                Text(
                    text = "Catégorie professionnelle :",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp)
                )
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp)
                ) {
                    items(categories) { cat ->
                        FilterChip(
                            selected = category == cat,
                            onClick = { viewModel.profileBusinessCategory.value = cat },
                            label = { Text(cat, fontSize = 12.sp) }
                        )
                    }
                }
            }

            item {
                // Bio / Description
                OutlinedTextField(
                    value = bio,
                    onValueChange = { viewModel.profileBio.value = it },
                    label = { Text("Statut / Bio professionnelle") },
                    placeholder = { Text("Ex: Disponible sur ADT Pro") },
                    maxLines = 3,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_bio"),
                    shape = RoundedCornerShape(12.dp)
                )
            }

            item {
                Surface(
                    color = AdtPrimary.copy(alpha = 0.08f),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, AdtPrimary.copy(alpha = 0.2f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(Icons.Default.Verified, contentDescription = null, tint = AdtPrimary)
                        Column {
                            Text(
                                text = "Numéro vérifié par Firebase : ${selectedCountry.dialCode} $enteredPhone",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = AdtPrimary
                            )
                            Text(
                                text = "Opérateur : $selectedOperator • Réseau sécurisé ADT",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(8.dp))
                Button(
                    onClick = { viewModel.completeRegistration(activity) },
                    enabled = firstName.isNotBlank() && lastName.isNotBlank(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("btn_complete_profile"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = AdtPrimary)
                ) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color.White)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        "Créer mon profil professionnel",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = Color.White
                    )
                }
            }
        }
    }
}
