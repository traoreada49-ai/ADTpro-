package com.example.ui.screens.chat

import androidx.compose.animation.*
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AdtPrimary
import com.example.ui.theme.AdtSecondary

data class StickerData(
    val id: String,
    val emoji: String,
    val title: String,
    val category: String,
    val tags: List<String> = emptyList()
)

val DEFAULT_STICKERS = listOf(
    // BUSINESS & PRO
    StickerData("b1", "🤝", "Accord Validé", "BUSINESS", listOf("accord", "partenaire", "deal", "contrat", "ok")),
    StickerData("b2", "💼", "Pro & Affaires", "BUSINESS", listOf("business", "travail", "bureau", "pro")),
    StickerData("b3", "✍️", "Contrat Signé", "BUSINESS", listOf("signature", "contrat", "papier", "deal")),
    StickerData("b4", "💳", "Paiement Reçu", "BUSINESS", listOf("argent", "paiement", "facture", "banque")),
    StickerData("b5", "📊", "Rapport Prêt", "BUSINESS", listOf("statistiques", "rapport", "données", "chiffres")),
    StickerData("b6", "🚀", "Projet Lancé", "BUSINESS", listOf("fusée", "lancement", "vitesse", "succès")),
    StickerData("b7", "🎯", "Objectif Atteint", "BUSINESS", listOf("cible", "goal", "succès", "gagné")),
    StickerData("b8", "⏱️", "Urgent ADT", "BUSINESS", listOf("urgent", "rapide", "chronomètre", "vite")),
    StickerData("b9", "🏆", "Performance Top", "BUSINESS", listOf("champion", "trophée", "premier", "victoire")),
    StickerData("b10", "🏛️", "Direction ADT", "BUSINESS", listOf("direction", "bureau", "siège", "conseil")),
    StickerData("b11", "📈", "En Croissance", "BUSINESS", listOf("hausse", "profit", "croissance", "vente")),
    StickerData("b12", "👥", "Réunion Équipe", "BUSINESS", listOf("meeting", "équipe", "groupe", "call")),

    // TERANGA & AFRO
    StickerData("t1", "🦁", "Lion du Sénégal", "TERANGA", listOf("lion", "force", "gainde", "teranga", "dakar")),
    StickerData("t2", "🇸🇳", "Dakar Connect", "TERANGA", listOf("senegal", "dakar", "pays", "afrique")),
    StickerData("t3", "🇨🇮", "Abidjan Business", "TERANGA", listOf("ci", "cote d'ivoire", "abidjan", "business")),
    StickerData("t4", "🇲🇱", "Bamako Solutions", "TERANGA", listOf("mali", "bamako", "solutions")),
    StickerData("t5", "🇬🇳", "Conakry Hub", "TERANGA", listOf("guinee", "conakry", "hub")),
    StickerData("t6", "☕", "Pause Ataya", "TERANGA", listOf("thé", "ataya", "pause", "detente")),
    StickerData("t7", "✨", "Nio Far", "TERANGA", listOf("ensemble", "solidarite", "union", "teranga")),
    StickerData("t8", "🙏", "Jërëjëf", "TERANGA", listOf("merci", "gratitude", "remerciement")),
    StickerData("t9", "👑", "Patron / Boss", "TERANGA", listOf("roi", "boss", "directeur", "respect")),
    StickerData("t10", "🍲", "Thiéboudienne", "TERANGA", listOf("repas", "midi", "bon appétit", "manger")),
    StickerData("t11", "💚", "Teranga ADT", "TERANGA", listOf("coeur", "amour", "bienvenue", "teranga")),
    StickerData("t12", "🌍", "Afrique Émergente", "TERANGA", listOf("afrique", "monde", "continent", "futur")),

    // TECH & TELECOM
    StickerData("tc1", "🔐", "Chiffré E2E", "TECH", listOf("securite", "chiffre", "cadenas", "prive")),
    StickerData("tc2", "📡", "Réseau 5G Pro", "TECH", listOf("antenne", "telecom", "5g", "signal", "connexion")),
    StickerData("tc3", "⚡", "Fibre Optique", "TECH", listOf("rapide", "vitesse", "eclair", "fibre")),
    StickerData("tc4", "🛡️", "Sécurité Max", "TECH", listOf("bouclier", "protection", "antivirus", "safe")),
    StickerData("tc5", "🤖", "Assistant AI", "TECH", listOf("gemini", "ia", "robot", "smart")),
    StickerData("tc6", "💻", "Dev en Cours", "TECH", listOf("code", "ordinateur", "programmeur", "dev")),
    StickerData("tc7", "☁️", "Cloud Synchro", "TECH", listOf("nuage", "sauvegarde", "cloud", "sync")),
    StickerData("tc8", "🔑", "Clé Publique OK", "TECH", listOf("cle", "authentification", "pass")),
    StickerData("tc9", "📶", "Plein Réseau", "TECH", listOf("wifi", "barres", "signal", "connexion")),
    StickerData("tc10", "🛰️", "Liaison Satellite", "TECH", listOf("satellite", "espace", "liaison")),
    StickerData("tc11", "💾", "Sauvegardé", "TECH", listOf("disquette", "save", "fichier")),
    StickerData("tc12", "🔋", "Batterie 100%", "TECH", listOf("energie", "charge", "full", "pret")),

    // REACTIONS & FUN
    StickerData("r1", "🎉", "Félicitations !", "REACTIONS", listOf("fete", "bravo", "succes", "joie")),
    StickerData("r2", "🔥", "C'est du lourd !", "REACTIONS", listOf("feu", "flamme", "incroyable", "hot")),
    StickerData("r3", "👏", "Bravo l'équipe", "REACTIONS", listOf("applaudissements", "bravo", "merci")),
    StickerData("r4", "💡", "Idée Géniale", "REACTIONS", listOf("ampoule", "astuce", "trouve", "eureka")),
    StickerData("r5", "😎", "Géré avec classe", "REACTIONS", listOf("cool", "lunettes", "easy", "parfait")),
    StickerData("r6", "💯", "100% Validé", "REACTIONS", listOf("100", "top", "exact", "parfait")),
    StickerData("r7", "💪", "Force & Courage", "REACTIONS", listOf("muscle", "puissance", "energie", "combat")),
    StickerData("r8", "🥳", "Célébration", "REACTIONS", listOf("party", "joie", "fete", "danse")),
    StickerData("r9", "🙌", "Merci Infiniment", "REACTIONS", listOf("mains", "respect", "remerciement")),
    StickerData("r10", "⭐", "Excellence", "REACTIONS", listOf("etoile", "parfait", "brillant")),
    StickerData("r11", "🤩", "Impressionnant", "REACTIONS", listOf("yeux etoiles", "wahou", "super")),
    StickerData("r12", "☕", "Pause Café", "REACTIONS", listOf("cafe", "detente", "pause", "midi"))
)

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun CustomStickerPicker(
    onStickerSelected: (emoji: String, title: String) -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedCategory by remember { mutableStateOf("BUSINESS") }
    var searchQuery by remember { mutableStateOf("") }
    var recentStickers by remember {
        mutableStateOf(
            listOf(
                StickerData("b1", "🤝", "Accord Validé", "BUSINESS"),
                StickerData("tc1", "🔐", "Chiffré E2E", "TECH"),
                StickerData("t1", "🦁", "Lion du Sénégal", "TERANGA"),
                StickerData("r2", "🔥", "C'est du lourd !", "REACTIONS"),
                StickerData("b6", "🚀", "Projet Lancé", "BUSINESS"),
                StickerData("b4", "💳", "Paiement Reçu", "BUSINESS"),
                StickerData("r1", "🎉", "Félicitations !", "REACTIONS"),
                StickerData("t6", "☕", "Pause Ataya", "TERANGA")
            )
        )
    }

    // Custom Creator State
    var customEmojiInput by remember { mutableStateOf("🌟") }
    var customTitleInput by remember { mutableStateOf("Super Partenaire") }

    val categories = listOf(
        Triple("RECENTS", "🕒", "Récents"),
        Triple("BUSINESS", "💼", "Business"),
        Triple("TERANGA", "🦁", "Teranga"),
        Triple("TECH", "⚡", "Tech & Réseau"),
        Triple("REACTIONS", "🥳", "Réactions"),
        Triple("CUSTOM", "🎨", "Créer")
    )

    val filteredStickers = remember(selectedCategory, searchQuery, recentStickers) {
        if (searchQuery.isNotBlank()) {
            val query = searchQuery.trim().lowercase()
            DEFAULT_STICKERS.filter {
                it.title.lowercase().contains(query) ||
                it.emoji.contains(query) ||
                it.tags.any { tag -> tag.contains(query) }
            }
        } else {
            when (selectedCategory) {
                "RECENTS" -> recentStickers
                "CUSTOM" -> emptyList()
                else -> DEFAULT_STICKERS.filter { it.category == selectedCategory }
            }
        }
    }

    Surface(
        color = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
        shadowElevation = 8.dp,
        modifier = modifier
            .fillMaxWidth()
            .height(380.dp)
            .testTag("custom_sticker_picker_sheet")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            // Drag handle & Header
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .width(36.dp)
                        .height(4.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.3f))
                )
            }

            // Top Header: Title + Search toggle + Close Button
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = AdtPrimary.copy(alpha = 0.15f),
                        modifier = Modifier.size(32.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text("🏷️", fontSize = 16.sp)
                        }
                    }
                    Text(
                        text = "Autocollants & Stickers ADT",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                IconButton(
                    onClick = onClose,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        Icons.Default.Close,
                        contentDescription = "Fermer le sélecteur de stickers",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Rechercher un autocollant (ex: deal, 5G, lion...)", fontSize = 12.5.sp) },
                leadingIcon = {
                    Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp), tint = AdtPrimary)
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }, modifier = Modifier.size(24.dp)) {
                            Icon(Icons.Default.Close, contentDescription = "Effacer", modifier = Modifier.size(16.dp))
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = AdtPrimary,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f)
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("sticker_search_input")
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Category Tabs Row
            if (searchQuery.isBlank()) {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 6.dp)
                ) {
                    items(categories) { (catKey, catEmoji, catLabel) ->
                        val isSelected = selectedCategory == catKey
                        FilterChip(
                            selected = isSelected,
                            onClick = { selectedCategory = catKey },
                            label = {
                                Text(
                                    text = "$catEmoji $catLabel",
                                    fontSize = 12.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = AdtPrimary.copy(alpha = 0.18f),
                                selectedLabelColor = AdtPrimary
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = isSelected,
                                borderColor = if (isSelected) AdtPrimary else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f),
                                selectedBorderColor = AdtPrimary
                            ),
                            shape = RoundedCornerShape(20.dp),
                            modifier = Modifier.testTag("sticker_tab_$catKey")
                        )
                    }
                }
            } else {
                Text(
                    text = "Résultats de recherche (${filteredStickers.size})",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = AdtPrimary,
                    modifier = Modifier.padding(bottom = 4.dp)
                )
            }

            // Main Content: Grid or Custom Creator
            if (selectedCategory == "CUSTOM" && searchQuery.isBlank()) {
                // Custom Sticker Creator Panel
                CustomStickerCreatorView(
                    customEmoji = customEmojiInput,
                    customTitle = customTitleInput,
                    onEmojiChange = { customEmojiInput = it },
                    onTitleChange = { customTitleInput = it },
                    onSend = { emoji, title ->
                        // Add to recents
                        val newSticker = StickerData("custom_${System.currentTimeMillis()}", emoji, title, "CUSTOM")
                        recentStickers = listOf(newSticker) + recentStickers.filter { it.emoji != emoji }
                        onStickerSelected(emoji, title)
                    }
                )
            } else {
                // Sticker Grid
                if (filteredStickers.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text("🔍", fontSize = 36.sp)
                            Text(
                                if (searchQuery.isNotEmpty()) "Aucun autocollant ne correspond à « $searchQuery »" else "Aucun autocollant dans cette catégorie",
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                } else {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(4),
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .testTag("sticker_grid"),
                        contentPadding = PaddingValues(vertical = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(filteredStickers, key = { it.id }) { sticker ->
                            StickerCardItem(
                                sticker = sticker,
                                onClick = {
                                    // Update recents
                                    recentStickers = listOf(sticker) + recentStickers.filter { it.id != sticker.id }
                                    onStickerSelected(sticker.emoji, sticker.title)
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StickerCardItem(
    sticker: StickerData,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(84.dp)
            .clickable { onClick() }
            .testTag("sticker_card_${sticker.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f)
        ),
        border = CardDefaults.outlinedCardBorder(enabled = true)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(4.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = sticker.emoji,
                fontSize = 32.sp,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(3.dp))
            Text(
                text = sticker.title,
                fontSize = 9.5.sp,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
fun CustomStickerCreatorView(
    customEmoji: String,
    customTitle: String,
    onEmojiChange: (String) -> Unit,
    onTitleChange: (String) -> Unit,
    onSend: (emoji: String, title: String) -> Unit
) {
    val suggestedEmojis = listOf(
        "🌟", "🤝", "🚀", "🦁", "💼", "🔥", "💡", "⚡", "👑", "🎯",
        "🎉", "🏆", "☕", "🇸🇳", "🇨🇮", "🇲🇱", "🇬🇳", "🔐", "📶", "💚"
    )

    val suggestedTitles = listOf(
        "Validé par le boss",
        "On est ensemble !",
        "En route pour le sommet",
        "Rendez-vous urgent",
        "Bien reçu avec succès",
        "Excellente nouvelle !"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(vertical = 4.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Live Preview Card
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.horizontalGradient(
                        listOf(AdtPrimary.copy(alpha = 0.12f), AdtSecondary.copy(alpha = 0.12f))
                    ),
                    RoundedCornerShape(14.dp)
                )
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Preview Sticker
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surface,
                shadowElevation = 3.dp,
                modifier = Modifier.size(72.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(customEmoji.ifBlank { "⭐" }, fontSize = 34.sp)
                }
            }

            Column(modifier = Modifier.weight(1f)) {
                Text("Aperçu de votre autocollant :", fontSize = 11.sp, color = AdtPrimary, fontWeight = FontWeight.Bold)
                Text(
                    text = customTitle.ifBlank { "Votre message personnalisé" },
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Text("Appuyez sur Envoyer pour l'ajouter à la discussion", fontSize = 10.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        // Quick Emoji Selector Row
        Text("Choisir un emoji de base :", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(suggestedEmojis) { em ->
                Surface(
                    shape = CircleShape,
                    color = if (customEmoji == em) AdtPrimary.copy(alpha = 0.25f) else MaterialTheme.colorScheme.surfaceVariant,
                    border = if (customEmoji == em) CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(AdtPrimary, AdtSecondary))) else null,
                    modifier = Modifier
                        .size(38.dp)
                        .clickable { onEmojiChange(em) }
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(em, fontSize = 20.sp)
                    }
                }
            }
        }

        // Custom Title Input
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = customTitle,
                onValueChange = onTitleChange,
                placeholder = { Text("Texte de l'autocollant...", fontSize = 13.sp) },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(50.dp)
                    .testTag("custom_sticker_title_input")
            )

            Button(
                onClick = { onSend(customEmoji.ifBlank { "🌟" }, customTitle.ifBlank { "Autocollant ADT" }) },
                colors = ButtonDefaults.buttonColors(containerColor = AdtPrimary),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .height(50.dp)
                    .testTag("btn_send_custom_sticker")
            ) {
                Icon(Icons.AutoMirrored.Filled.Send, contentDescription = null, modifier = Modifier.size(18.dp), tint = Color.White)
                Spacer(modifier = Modifier.width(4.dp))
                Text("Envoyer", color = Color.White, fontWeight = FontWeight.Bold)
            }
        }

        // Quick Suggestion Chips
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(suggestedTitles) { title ->
                SuggestionChip(
                    onClick = { onTitleChange(title) },
                    label = { Text(title, fontSize = 11.5.sp) },
                    shape = RoundedCornerShape(16.dp)
                )
            }
        }
    }
}
