package com.example

import android.app.Application
import android.util.Log
import com.example.data.firebase.FirebaseAiQuickReplyService
import com.example.data.firebase.FirebaseInitHelper
import com.example.data.service.ChatBackupNotificationHelper
import com.example.data.service.ChatBackupScheduler

class AdtApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        initFirebase()
        initFirebaseAi()
        initBackupService()
    }

    private fun initFirebaseAi() {
        try {
            FirebaseAiQuickReplyService.init(this)
            Log.i("AdtApplication", "FirebaseAiQuickReplyService initialized")
        } catch (e: Exception) {
            Log.w("AdtApplication", "Could not pre-initialize FirebaseAiQuickReplyService: ${e.message}")
        }
    }

    private fun initBackupService() {
        try {
            ChatBackupNotificationHelper.createNotificationChannel(this)
            ChatBackupScheduler.scheduleFromSettings(this)
            Log.i("AdtApplication", "ChatBackupNotificationHelper and Scheduler initialized")
        } catch (e: Exception) {
            Log.w("AdtApplication", "Could not initialize backup scheduler: ${e.message}")
        }
    }

    private fun initFirebase() {
        try {
            FirebaseInitHelper.ensureInitialized(this)
            Log.i("AdtApplication", "FirebaseApp initialized successfully via FirebaseInitHelper")
        } catch (e: Exception) {
            Log.e("AdtApplication", "Failed to initialize FirebaseApp: ${e.message}", e)
        }
    }
}

