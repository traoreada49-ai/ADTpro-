package com.example.ui.screens.settings

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SyncEnergyMode
import com.example.ui.theme.AdtAccentGreen
import com.example.ui.theme.AdtPrimary
import com.example.viewmodel.AdtViewModel
import kotlin.math.roundToInt

/**
 * Composant complet 'Batterie & Gestion de l'Énergie' (Battery & Energy Management).
 * Intègre le basculement entre les modes 'Haute Performance' et 'Économie d'Énergie',
 * ainsi qu'un slider personnalisé pour calibrer l'intervalle de synchronisation en arrière-plan.
 */
@Composable
fun BatteryEnergyManagementCard(
    viewModel: AdtViewModel,
    modifier: Modifier = Modifier
) {
    val syncEnergyMode by viewModel.syncEnergyMode.collectAsState()
    val syncIntervalMinutes by viewModel.syncIntervalMinutes.collectAsState()
    val isManualSyncing by viewModel.isManualSyncing.collectAsState()
    val lastManualSyncTimestamp by viewModel.lastManualSyncTimestamp.collectAsState()
    val autoBatterySaverOnLowBattery by viewModel.autoBatterySaverOnLowBattery.collectAsState()
    val deviceBatteryLevel by viewModel.deviceBatteryLevel.collectAsState()
    val isDeviceCharging by viewModel.isDeviceCharging.collectAsState()
    val firestoreSyncStatus by viewModel.firestoreSyncStatus.collectAsState()
    val nextPollingTimestamp by viewModel.nextPollingTimestamp.collectAsState()
    val isPollingActive by viewModel.isPollingActive.collectAsState()

    var sliderPosition by remember(syncIntervalMinutes) { mutableFloatStateOf(syncIntervalMinutes.toFloat()) }

    val isHighPerf = syncEnergyMode == SyncEnergyMode.HIGH_PERFORMANCE
    val isBatterySaver = syncEnergyMode == SyncEnergyMode.BATTERY_SAVER

    val batteryColor = when {
        isDeviceCharging -> AdtAccentGreen
        deviceBatteryLevel <= 20 -> MaterialTheme.colorScheme.error
        deviceBatteryLevel <= 40 -> Color(0xFFFFA000)
        else -> AdtPrimary
    }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)),
        modifier = modifier
            .fillMaxWidth()
            .testTag("battery_energy_management_card")
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // 1. En-tête : État de la Batterie et Connectivité
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = batteryColor.copy(alpha = 0.15f),
                        modifier = Modifier.size(38.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = when {
                                    isDeviceCharging -> Icons.Default.BatteryChargingFull
                                    deviceBatteryLevel <= 20 -> Icons.Default.BatteryAlert
                                    else -> Icons.Default.BatteryFull
                                },
                                contentDescription = "Batterie de l'appareil",
                                tint = batteryColor,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }

                    Column {
                        Text(
                            text = "Batterie & Gestion de l'Énergie",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.5.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = if (isDeviceCharging) {
                                "En charge • $deviceBatteryLevel% disponible"
                            } else if (deviceBatteryLevel <= 20) {
                                "Batterie faible ($deviceBatteryLevel%) • Économiseur conseillé"
                            } else {
                                "Niveau actuel : $deviceBatteryLevel% • Décharge normale"
                            },
                            fontSize = 11.5.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // Badge de statut de connexion Cloud
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = when (firestoreSyncStatus) {
                        is com.example.data.firebase.FirestoreSyncStatus.Connected -> AdtAccentGreen.copy(alpha = 0.15f)
                        is com.example.data.firebase.FirestoreSyncStatus.Syncing -> AdtPrimary.copy(alpha = 0.15f)
                        else -> MaterialTheme.colorScheme.surface
                    }
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .then(
                                    Modifier.background(
                                        when (firestoreSyncStatus) {
                                            is com.example.data.firebase.FirestoreSyncStatus.Connected -> AdtAccentGreen
                                            is com.example.data.firebase.FirestoreSyncStatus.Syncing -> AdtPrimary
                                            else -> Color.Gray
                                        }
                                    )
                                )
                        )
                        Text(
                            text = when (firestoreSyncStatus) {
                                is com.example.data.firebase.FirestoreSyncStatus.Connected -> "Cloud OK"
                                is com.example.data.firebase.FirestoreSyncStatus.Syncing -> "Synchro..."
                                else -> "Local"
                            },
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = when (firestoreSyncStatus) {
                                is com.example.data.firebase.FirestoreSyncStatus.Connected -> AdtAccentGreen
                                is com.example.data.firebase.FirestoreSyncStatus.Syncing -> AdtPrimary
                                else -> MaterialTheme.colorScheme.onSurfaceVariant
                            }
                        )
                    }
                }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))

            // 2. Sélecteur de Mode : Haute Performance vs Économie d'Énergie
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = "Mode de synchronisation",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "Arbitrez entre la latence minimale des messages et la préservation de votre autonomie.",
                    fontSize = 11.5.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(2.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Option 1 : Haute Performance
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        border = if (isHighPerf) BorderStroke(1.8.dp, AdtPrimary) else BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isHighPerf) AdtPrimary.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surface
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .clickable { viewModel.setSyncEnergyMode(SyncEnergyMode.HIGH_PERFORMANCE) }
                            .testTag("sync_mode_high_perf_btn")
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    Icons.Default.Bolt,
                                    contentDescription = null,
                                    tint = if (isHighPerf) AdtPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(22.dp)
                                )
                                if (isHighPerf) {
                                    Surface(
                                        shape = CircleShape,
                                        color = AdtPrimary,
                                        modifier = Modifier.size(18.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(12.dp))
                                        }
                                    }
                                }
                            }

                            Text(
                                text = "Haute Performance",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.5.sp,
                                color = if (isHighPerf) AdtPrimary else MaterialTheme.colorScheme.onSurface
                            )

                            Text(
                                text = "Temps réel (< 100 ms)\nMédias automatiques",
                                fontSize = 11.sp,
                                lineHeight = 14.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = if (isHighPerf) AdtPrimary.copy(alpha = 0.18f) else MaterialTheme.colorScheme.surfaceVariant
                            ) {
                                Text(
                                    text = "⚡ Latence Zéro",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isHighPerf) AdtPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }

                    // Option 2 : Économie d'Énergie
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        border = if (isBatterySaver) BorderStroke(1.8.dp, AdtAccentGreen) else BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isBatterySaver) AdtAccentGreen.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surface
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .clickable { viewModel.setSyncEnergyMode(SyncEnergyMode.BATTERY_SAVER) }
                            .testTag("sync_mode_battery_saver_btn")
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    Icons.Default.BatterySaver,
                                    contentDescription = null,
                                    tint = if (isBatterySaver) AdtAccentGreen else MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(22.dp)
                                )
                                if (isBatterySaver) {
                                    Surface(
                                        shape = CircleShape,
                                        color = AdtAccentGreen,
                                        modifier = Modifier.size(18.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(12.dp))
                                        }
                                    }
                                }
                            }

                            Text(
                                text = "Économie d'Énergie",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.5.sp,
                                color = if (isBatterySaver) AdtAccentGreen else MaterialTheme.colorScheme.onSurface
                            )

                            Text(
                                text = "Cadencé ($syncIntervalMinutes min)\nRadio en veille (-60%)",
                                fontSize = 11.sp,
                                lineHeight = 14.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = if (isBatterySaver) AdtAccentGreen.copy(alpha = 0.18f) else MaterialTheme.colorScheme.surfaceVariant
                            ) {
                                Text(
                                    text = "🔋 +3h Autonomie",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isBatterySaver) AdtAccentGreen else MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                }
            }

            // 3. Slider Personnalisé pour l'Intervalle de Synchronisation en Arrière-Plan
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surface)
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            Icons.Default.Schedule,
                            contentDescription = null,
                            tint = if (isBatterySaver) AdtAccentGreen else AdtPrimary,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = "Intervalle de synchronisation :",
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 12.5.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = if (isBatterySaver) AdtAccentGreen.copy(alpha = 0.15f) else AdtPrimary.copy(alpha = 0.15f)
                    ) {
                        Text(
                            text = "${sliderPosition.roundToInt()} min",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.5.sp,
                            color = if (isBatterySaver) AdtAccentGreen else AdtPrimary,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                        )
                    }
                }

                Text(
                    text = if (isBatterySaver) {
                        "En arrière-plan, ADT Pro se réveillera toutes les ${sliderPosition.roundToInt()} minutes pour relever vos nouveaux messages chiffrés."
                    } else {
                        "En Haute Performance, les messages sont instantanés en premier plan. Cet intervalle (${sliderPosition.roundToInt()} min) calibre le rafraîchissement d'arrière-plan."
                    },
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 14.5.sp
                )

                // Indicateur de statut de relève périodique programmée
                if (isBatterySaver && (isPollingActive || nextPollingTimestamp > 0L)) {
                    val remainingMs = nextPollingTimestamp - System.currentTimeMillis()
                    val remainingMinutes = (remainingMs / 60000L).coerceAtLeast(0L)
                    val nextSyncText = when {
                        remainingMinutes > 1L -> "Prochaine relève réseau : dans ~$remainingMinutes min"
                        remainingMinutes == 1L -> "Prochaine relève réseau : dans ~1 min"
                        else -> "Prochaine relève réseau : imminente (< 1 min)"
                    }
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = AdtAccentGreen.copy(alpha = 0.12f),
                        border = BorderStroke(0.5.dp, AdtAccentGreen.copy(alpha = 0.4f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                Icons.Default.Schedule,
                                contentDescription = null,
                                tint = AdtAccentGreen,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = nextSyncText,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium,
                                color = AdtAccentGreen
                            )
                        }
                    }
                }

                // Slider M3
                Slider(
                    value = sliderPosition,
                    onValueChange = { newValue ->
                        sliderPosition = newValue
                    },
                    onValueChangeFinished = {
                        viewModel.setSyncIntervalMinutes(sliderPosition.roundToInt())
                    },
                    valueRange = 5f..60f,
                    steps = 10, // 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60 min
                    colors = SliderDefaults.colors(
                        thumbColor = if (isBatterySaver) AdtAccentGreen else AdtPrimary,
                        activeTrackColor = if (isBatterySaver) AdtAccentGreen else AdtPrimary,
                        inactiveTrackColor = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("sync_interval_slider")
                )

                // Raccourcis d'intervalles prédéfinis
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    listOf(5 to "5 min", 15 to "15 min", 30 to "30 min", 60 to "1 h").forEach { (minVal, label) ->
                        val isSelected = sliderPosition.roundToInt() == minVal
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = if (isSelected) {
                                (if (isBatterySaver) AdtAccentGreen else AdtPrimary).copy(alpha = 0.2f)
                            } else {
                                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                            },
                            modifier = Modifier.clickable {
                                sliderPosition = minVal.toFloat()
                                viewModel.setSyncIntervalMinutes(minVal)
                            }
                        ) {
                            Text(
                                text = label,
                                fontSize = 10.5.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) {
                                    if (isBatterySaver) AdtAccentGreen else AdtPrimary
                                } else {
                                    MaterialTheme.colorScheme.onSurfaceVariant
                                },
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }
                }
            }

            // 4. Basculement automatique sous 20%
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { viewModel.toggleAutoBatterySaver(!autoBatterySaverOnLowBattery) },
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f).padding(end = 10.dp)) {
                    Text(
                        text = "Économiseur automatique sous 20%",
                        fontSize = 12.5.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Bascule automatiquement en mode Économie si l'appareil est sur batterie critique.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Switch(
                    checked = autoBatterySaverOnLowBattery,
                    onCheckedChange = { viewModel.toggleAutoBatterySaver(it) },
                    modifier = Modifier.testTag("switch_auto_battery_saver")
                )
            }

            // 5. Bouton de déclenchement manuel immédiat
            OutlinedButton(
                onClick = { viewModel.triggerImmediateManualSync() },
                enabled = !isManualSyncing,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("btn_manual_force_sync"),
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, if (isBatterySaver) AdtAccentGreen.copy(alpha = 0.6f) else AdtPrimary.copy(alpha = 0.6f))
            ) {
                if (isManualSyncing) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(16.dp),
                        strokeWidth = 2.dp,
                        color = if (isBatterySaver) AdtAccentGreen else AdtPrimary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Synchronisation forcée en cours...", fontSize = 12.sp)
                } else {
                    Icon(
                        Icons.Default.Sync,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp),
                        tint = if (isBatterySaver) AdtAccentGreen else AdtPrimary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isBatterySaver) "Actualiser maintenant les messages" else "Forcer la synchronisation cloud",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }
    }
}
