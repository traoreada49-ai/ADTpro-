package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.MessageEntity
import com.example.data.model.DocumentScanStatus
import com.example.data.model.DocumentType
import com.example.data.model.SecureDocument
import com.example.ui.theme.AdtPrimary

@Composable
fun DocumentBubbleContent(
    message: MessageEntity,
    onOpenDocument: (SecureDocument) -> Unit,
    onShowSecurityReport: (SecureDocument) -> Unit,
    modifier: Modifier = Modifier
) {
    val document = remember(message.mediaUrl, message.text) {
        SecureDocument.deserialize(message.mediaUrl) ?: SecureDocument(
            fileName = message.text.ifBlank { "Document_ADT.pdf" },
            fileSizeBytes = 1_250_000L,
            storagePath = "chats/${message.chatId}/documents/${message.id}/${message.text}"
        )
    }

    val typeColor = when (document.fileType) {
        DocumentType.PDF -> Color(0xFFD32F2F) // Red for PDF
        DocumentType.DOCX -> Color(0xFF1976D2) // Blue for Word
        DocumentType.XLSX -> Color(0xFF2E7D32) // Green for Excel
        DocumentType.PPTX -> Color(0xFFE65100) // Orange for PowerPoint
        DocumentType.TXT -> Color(0xFF5E35B1) // Purple for Text
        DocumentType.OTHER -> Color(0xFF455A64) // Slate
    }

    val typeIcon: ImageVector = when (document.fileType) {
        DocumentType.PDF -> Icons.Default.PictureAsPdf
        DocumentType.DOCX -> Icons.Default.Description
        DocumentType.XLSX -> Icons.Default.TableChart
        DocumentType.PPTX -> Icons.Default.Slideshow
        DocumentType.TXT -> Icons.Default.Article
        DocumentType.OTHER -> Icons.Default.InsertDriveFile
    }

    val isSafe = document.scanStatus == DocumentScanStatus.SAFE

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)
        ),
        border = BorderStroke(
            1.dp,
            if (isSafe) Color(0xFF2E7D32).copy(alpha = 0.35f) else MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
        ),
        modifier = modifier
            .fillMaxWidth()
            .clickable { onOpenDocument(document) }
            .testTag("document_bubble_${message.id}")
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Header Row: Icon + File info
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // File Type Icon Box
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = typeColor,
                    modifier = Modifier.size(46.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = typeIcon,
                            contentDescription = document.fileType.displayName,
                            tint = Color.White,
                            modifier = Modifier.size(26.dp)
                        )
                    }
                }

                // File Details
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = document.fileName,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(3.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = typeColor.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = document.fileType.extension.uppercase(),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = typeColor,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                            )
                        }
                        Text(
                            text = document.formattedSize,
                            fontSize = 11.5.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        if (document.pageCount > 1) {
                            Text(
                                text = "• ${document.pageCount} ${if (document.fileType == DocumentType.XLSX) "feuilles" else "pages"}",
                                fontSize = 11.5.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            // Optional message caption
            if (document.caption.isNotBlank() && document.caption != document.fileName) {
                Text(
                    text = document.caption,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            // Server-Side Security Scan Badge
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = if (isSafe) Color(0xFF2E7D32).copy(alpha = 0.12f) else Color(0xFFD32F2F).copy(alpha = 0.12f),
                border = BorderStroke(
                    1.dp,
                    if (isSafe) Color(0xFF2E7D32).copy(alpha = 0.4f) else Color(0xFFD32F2F).copy(alpha = 0.4f)
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onShowSecurityReport(document) }
                    .testTag("btn_security_scan_badge")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = if (isSafe) Icons.Default.VerifiedUser else Icons.Default.Warning,
                        contentDescription = "Statut de sécurité",
                        tint = if (isSafe) Color(0xFF2E7D32) else Color(0xFFD32F2F),
                        modifier = Modifier.size(16.dp)
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isSafe) "Sécurisé • Analyse Cloud Réussie" else "Analyse en cours...",
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isSafe) Color(0xFF2E7D32) else Color(0xFFD32F2F)
                        )
                        Text(
                            text = "Firebase Storage • SHA-256 vérifié (0 menace)",
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = "Détails sécurité",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            // Action Row: Open / View / Security Details
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = { onOpenDocument(document) },
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(34.dp)
                        .testTag("btn_preview_document")
                ) {
                    Icon(Icons.Default.Visibility, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Aperçu", fontSize = 11.5.sp)
                }

                Button(
                    onClick = { onShowSecurityReport(document) },
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = AdtPrimary),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    modifier = Modifier
                        .weight(1.2f)
                        .height(34.dp)
                        .testTag("btn_document_security_report")
                ) {
                    Icon(Icons.Default.Shield, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Rapport Sécurité", fontSize = 11.5.sp)
                }
            }
        }
    }
}
