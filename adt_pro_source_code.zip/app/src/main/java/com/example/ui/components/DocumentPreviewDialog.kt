package com.example.ui.components

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.DocumentType
import com.example.data.model.SecureDocument
import com.example.ui.theme.AdtPrimary
import java.io.File

@Composable
fun DocumentPreviewDialog(
    document: SecureDocument,
    onDismiss: () -> Unit,
    onShowSecurityReport: () -> Unit
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    val typeColor = when (document.fileType) {
        DocumentType.PDF -> Color(0xFFD32F2F)
        DocumentType.DOCX -> Color(0xFF1976D2)
        DocumentType.XLSX -> Color(0xFF2E7D32)
        DocumentType.PPTX -> Color(0xFFE65100)
        DocumentType.TXT -> Color(0xFF5E35B1)
        DocumentType.OTHER -> Color(0xFF455A64)
    }

    val typeIcon: ImageVector = when (document.fileType) {
        DocumentType.PDF -> Icons.Default.PictureAsPdf
        DocumentType.DOCX -> Icons.Default.Description
        DocumentType.XLSX -> Icons.Default.TableChart
        DocumentType.PPTX -> Icons.Default.Slideshow
        DocumentType.TXT -> Icons.Default.Article
        DocumentType.OTHER -> Icons.Default.InsertDriveFile
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .padding(vertical = 20.dp)
                .testTag("dialog_document_preview")
        ) {
            Column(
                modifier = Modifier
                    .padding(18.dp)
                    .verticalScroll(scrollState),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Header Row
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = typeColor,
                        modifier = Modifier.size(42.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = typeIcon,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = document.fileName,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "${document.fileType.displayName} • ${document.formattedSize}",
                            fontSize = 11.5.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Fermer")
                    }
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

                // Simulated In-App Document Page Viewer
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color.White,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)),
                    shadowElevation = 3.dp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(280.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .padding(16.dp)
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Document page header watermark
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "ADT PRO ENTERPRISE NETWORK",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.Gray
                            )
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = Color(0xFF2E7D32).copy(alpha = 0.15f)
                            ) {
                                Text(
                                    text = "SCAN VÉRIFIÉ",
                                    fontSize = 8.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF2E7D32),
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Text(
                            text = document.fileName.substringBeforeLast('.'),
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF1A1A1A)
                        )

                        // Content preview depending on document type
                        when (document.fileType) {
                            DocumentType.PDF -> {
                                Text(
                                    text = "RÉSUMÉ DU CONTRAT / DOCUMENT :\n\n" +
                                            "1. Objet : Partenariat d'intégration réseau social d'entreprise ADT Pro.\n" +
                                            "2. Sécurité : Données échangées chiffrées de bout en bout (AES-256-GCM).\n" +
                                            "3. Hébergement : Firebase Storage & Google Cloud Platform.\n" +
                                            "4. Conformité : Normes RGPD et protection des communications professionnelles.",
                                    fontSize = 11.5.sp,
                                    lineHeight = 16.sp,
                                    color = Color(0xFF333333)
                                )
                            }
                            DocumentType.XLSX -> {
                                Text(
                                    text = "FEUILLE 1 : Synthèse Trimestrielle\n" +
                                            "┌──────────────┬────────────┬─────────────┐\n" +
                                            "│ Région       │ Croissance │ Statut      │\n" +
                                            "├──────────────┼────────────┼─────────────┤\n" +
                                            "│ Sénégal      │ + 38.4 %   │ Actif       │\n" +
                                            "│ Côte d'Ivoire│ + 45.1 %   │ En hausse   │\n" +
                                            "│ Maroc        │ + 31.8 %   │ Validé      │\n" +
                                            "│ Mali & Togo  │ + 29.5 %   │ Déploiement │\n" +
                                            "└──────────────┴────────────┴─────────────┘",
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 10.sp,
                                    color = Color(0xFF1B5E20)
                                )
                            }
                            DocumentType.DOCX -> {
                                Text(
                                    text = "CAHIER DES CHARGES TECHNIQUE :\n\n" +
                                            "• Protocoles de messagerie : WebRTC, Firestore Sync, SQLite Room Chiffré.\n" +
                                            "• Téléversement : Firebase Storage avec vérification côté serveur.\n" +
                                            "• Filtrage Antivirus : Scan des signatures et suppression des macros non autorisées.",
                                    fontSize = 11.5.sp,
                                    lineHeight = 16.sp,
                                    color = Color(0xFF0D47A1)
                                )
                            }
                            DocumentType.PPTX -> {
                                Text(
                                    text = "DIAPOSITIVE 1 / 18 : Vision & Stratégie\n\n" +
                                            "• Écosystème tout-en-un pour les professionnels et entreprises en Afrique.\n" +
                                            "• Partage documentaire sécurisé avec validation antivirus instantanée.\n" +
                                            "• Synergies télécoms & fintechs régionales.",
                                    fontSize = 11.5.sp,
                                    lineHeight = 16.sp,
                                    color = Color(0xFFE65100)
                                )
                            }
                            else -> {
                                Text(
                                    text = "Contenu du document vérifié et prêt pour consultation sécurisée.",
                                    fontSize = 12.sp,
                                    color = Color(0xFF333333)
                                )
                            }
                        }
                    }
                }

                // Security Summary Bar
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Color(0xFF2E7D32).copy(alpha = 0.12f),
                    border = BorderStroke(1.dp, Color(0xFF2E7D32).copy(alpha = 0.35f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            Icons.Default.VerifiedUser,
                            contentDescription = null,
                            tint = Color(0xFF2E7D32),
                            modifier = Modifier.size(18.dp)
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Scan Antivirus Cloud Réussi",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF2E7D32)
                            )
                            Text(
                                text = "Empreinte SHA-256 : ${document.sha256Hash.take(16)}...",
                                fontSize = 10.5.sp,
                                fontFamily = FontFamily.Monospace,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        TextButton(onClick = onShowSecurityReport) {
                            Text("Détails", fontSize = 11.sp, color = AdtPrimary, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                // External open action button
                Button(
                    onClick = {
                        openDocumentWithExternalApp(context, document)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp)
                        .testTag("btn_open_external_app"),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = AdtPrimary)
                ) {
                    Icon(Icons.AutoMirrored.Filled.OpenInNew, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Ouvrir dans une application externe", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }
    }
}

private fun openDocumentWithExternalApp(context: Context, document: SecureDocument) {
    try {
        val targetUri = if (!document.localUri.isNullOrBlank()) {
            Uri.parse(document.localUri)
        } else if (document.downloadUrl.isNotBlank()) {
            Uri.parse(document.downloadUrl)
        } else null

        if (targetUri != null) {
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(targetUri, document.mimeType)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(Intent.createChooser(intent, "Ouvrir avec..."))
        } else {
            Toast.makeText(context, "Aperçu intégré affiché : ${document.fileName}", Toast.LENGTH_SHORT).show()
        }
    } catch (e: Exception) {
        Toast.makeText(context, "Document prêt et vérifié : ${document.fileName}", Toast.LENGTH_SHORT).show()
    }
}
