package com.example.ui.screens.settings

import com.example.data.model.GlobalServerNode
import com.example.data.model.SyncEnergyMode
import com.example.data.model.formatBytes

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.ui.draw.rotate
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import com.example.data.firebase.FirebaseAiQuickReplyService
import kotlinx.coroutines.launch
import com.example.ui.components.AdtAvatar
import com.example.ui.components.OperatorBadge
import com.example.ui.theme.*
import com.example.ui.util.AppLanguage
import com.example.ui.util.getStringsForLanguage
import com.example.viewmodel.AdtViewModel
import com.example.viewmodel.AppScreen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(viewModel: AdtViewModel) {
    val currentUser by viewModel.currentUser.collectAsState()
    val appSettings by viewModel.appSettings.collectAsState()
    val dbSecurityStatus by viewModel.databaseSecurityStatus.collectAsState()
    val twoStepState by viewModel.twoStepVerificationState.collectAsState()
    val verifiedFingerprints by viewModel.verifiedChatFingerprints.collectAsState()
    val activeChats by viewModel.activeChats.collectAsState()
    val allContacts by viewModel.allContacts.collectAsState()
    val allChannels by viewModel.allChannels.collectAsState()
    val allStatuses by viewModel.allStatuses.collectAsState()
    val allCalls by viewModel.allCalls.collectAsState()
    val dataEnrichmentStatus by viewModel.dataEnrichmentStatus.collectAsState()
    val quickRepliesEnabled by viewModel.quickRepliesEnabled.collectAsState()
    val quickRepliesTone by viewModel.quickRepliesTone.collectAsState()
    val storageOverview by viewModel.storageOverview.collectAsState()
    LaunchedEffect(Unit) {
        viewModel.refreshStorageOverview()
    }
    val coroutineScope = rememberCoroutineScope()
    var testReplySuggestions by remember { mutableStateOf<List<String>?>(null) }
    var isTestingAi by remember { mutableStateOf(false) }
    val context = androidx.compose.ui.platform.LocalContext.current
    val strings = remember(appSettings?.language) {
        getStringsForLanguage(appSettings?.language)
    }

    var showGlobalServersDialog by remember { mutableStateOf(false) }
    var selectedServerId by remember { mutableStateOf("af_west") }
    var isTestingServerLatency by remember { mutableStateOf(false) }
    var lastPingResult by remember { mutableStateOf("28 ms (Excellent)") }
    var showLanguageDialog by remember { mutableStateOf(false) }
    var showPrivacyDialog by remember { mutableStateOf(false) }
    var showWallpaperDialog by remember { mutableStateOf(false) }
    var showSecurityInfoDialog by remember { mutableStateOf(false) }
    var showQrCodeDialog by remember { mutableStateOf(false) }
    var showEditProfileDialog by remember { mutableStateOf(false) }
    var showStickersDialog by remember { mutableStateOf(false) }

    val userFullName = remember(currentUser) {
        if (currentUser != null && currentUser!!.firstName.isNotBlank()) {
            "${currentUser!!.firstName} ${currentUser!!.lastName}"
        } else {
            "Utilisateur ADT Pro"
        }
    }

    val currentLang = remember(appSettings?.language) {
        AppLanguage.fromCode(appSettings?.language)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(strings.settingsTitle, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(
                        onClick = { viewModel.navigateTo(AppScreen.MAIN_TABS) },
                        modifier = Modifier.testTag("btn_back_settings")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Retour")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Profile Card
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(14.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            AdtAvatar(name = userFullName, avatarKey = currentUser?.avatarUrl ?: "", sizeDp = 56)
                            Column {
                                Text(userFullName, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                if (!currentUser?.bio.isNullOrBlank()) {
                                    Text(currentUser!!.bio, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Text(currentUser?.phone ?: "", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Spacer(modifier = Modifier.height(4.dp))
                                OperatorBadge(currentUser?.operatorName ?: "Orange")
                            }
                        }
                        Row {
                            IconButton(onClick = { showEditProfileDialog = true }) {
                                Icon(Icons.Default.Edit, contentDescription = "Modifier le profil", tint = AdtPrimary)
                            }
                            IconButton(onClick = { viewModel.openContactQrCode(initialTab = 0) }) {
                                Icon(Icons.Default.QrCode2, contentDescription = "QR Code ADT Pro", tint = AdtPrimary, modifier = Modifier.size(24.dp))
                            }
                        }
                    }
                }
            }

            // LANGUAGE SETTINGS (France, Franglais, USA, Russia, etc.)
            item {
                Text(strings.languageSetting, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = AdtPrimary)
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { showLanguageDialog = true },
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Text(currentLang.flag, fontSize = 26.sp)
                                Column {
                                    Text(
                                        "${currentLang.displayName} (${currentLang.countryName})",
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 14.sp
                                    )
                                    Text(
                                        currentLang.description,
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = AdtPrimary)
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        HorizontalDivider()
                        Spacer(modifier = Modifier.height(10.dp))

                        // Quick switcher chips
                        Text("Accès rapide aux langues :", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(modifier = Modifier.height(6.dp))
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            items(AppLanguage.entries) { lang ->
                                FilterChip(
                                    selected = currentLang == lang,
                                    onClick = { viewModel.updateLanguage(lang.code) },
                                    label = {
                                        Text(
                                            "${lang.flag} ${lang.displayName}",
                                            fontSize = 11.sp,
                                            fontWeight = if (currentLang == lang) FontWeight.Bold else FontWeight.Normal
                                        )
                                    },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = AdtPrimary.copy(alpha = 0.2f),
                                        selectedLabelColor = AdtPrimary
                                    )
                                )
                            }
                        }
                    }
                }
            }

            // Theme Settings
            item {
                Text(strings.appearanceTheme, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = AdtPrimary)
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        DarkScheduleSettingsCard(
                            appSettings = appSettings,
                            strings = strings,
                            onUpdateThemeMode = { mode -> viewModel.updateTheme(mode) },
                            onUpdateSchedule = { type, startH, startM, endH, endM ->
                                viewModel.updateDarkSchedule(type, startH, startM, endH, endM)
                            }
                        )

                        HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp))

                        // Palette de couleurs (Rouge, Bleu, Blanche, Noir, Violet, Vert, Rose)
                        Column(modifier = Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.Palette, contentDescription = null, tint = AdtPrimary)
                                    Column {
                                        Text("Couleur d'accueil & thème de l'application", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                        Text(
                                            "Personnalise l'écran d'accueil, la barre supérieure, les onglets et discussions",
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }

                                val currentHomePalette = AdtPaletteColor.fromId(appSettings?.wallpaperTheme)
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = currentHomePalette.primary.copy(alpha = 0.15f)
                                ) {
                                    Text(
                                        text = "${currentHomePalette.emojiBadge} ${currentHomePalette.frenchName}",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (currentHomePalette == AdtPaletteColor.BLANCHE) Color.DarkGray else currentHomePalette.primary,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            LazyRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                items(AdtPaletteColor.ALL_COLORS) { palColor ->
                                    val isColorSelected = appSettings?.wallpaperTheme == palColor.wallpaperThemeId
                                    Surface(
                                        onClick = {
                                            viewModel.setHomeColorTheme(palColor)
                                        },
                                        shape = RoundedCornerShape(10.dp),
                                        color = if (isColorSelected) palColor.primary.copy(alpha = 0.18f) else MaterialTheme.colorScheme.surface,
                                        border = androidx.compose.foundation.BorderStroke(
                                            width = if (isColorSelected) 2.dp else 1.dp,
                                            color = if (isColorSelected) palColor.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)
                                        ),
                                        modifier = Modifier.testTag("color_chip_${palColor.id.lowercase()}")
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(16.dp)
                                                    .clip(CircleShape)
                                                    .background(palColor.primary)
                                                    .then(
                                                        if (palColor == AdtPaletteColor.BLANCHE) {
                                                            Modifier.border(1.dp, Color.Gray, CircleShape)
                                                        } else Modifier
                                                    )
                                            )
                                            Text(
                                                text = palColor.frenchName,
                                                fontSize = 12.sp,
                                                fontWeight = if (isColorSelected) FontWeight.Bold else FontWeight.Normal,
                                                color = if (isColorSelected) palColor.primary else MaterialTheme.colorScheme.onSurface
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp))

                        // Wallpaper picker row
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.openWallpaperPicker() }
                                .testTag("btn_open_wallpaper_picker"),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Icon(Icons.Default.Wallpaper, contentDescription = null, tint = AdtPrimary)
                                Column {
                                    Text(strings.chatWallpaper, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                    Text("Fleurs, Arbres, Voitures, Étoiles, Lune, Soleil...", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = AdtPrimary)
                        }

                        HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp))

                        // Camera Studio & Video Effects row
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.openCamera() }
                                .testTag("btn_open_camera_studio"),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Icon(Icons.Default.CameraAlt, contentDescription = null, tint = AdtPrimary)
                                Column {
                                    Text("Appareil Photo & Vidéo (Effets)", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                    Text("Citron, Fraisier, Orange, White, Noir & Blanc, Bleu...", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = AdtPrimary)
                        }

                        HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp))

                        // Stickers Selection Row
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { showStickersDialog = true },
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Icon(Icons.Default.EmojiEmotions, contentDescription = null, tint = AdtPrimary)
                                Column {
                                    Text("Pack d'autocollants actif", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                    Text(
                                        "Actuel: " + when (appSettings?.activeStickerPack) {
                                            "FUN" -> "Fun & Casual (Café, Fête, Étoiles)"
                                            "TECH" -> "Sécurité & Crypto (Chiffré, Clé)"
                                            else -> "Professionnel ADT (Affaires, Pro)"
                                        },
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            Icon(Icons.Default.ChevronRight, contentDescription = null)
                        }
                    }
                }
            }

            // Contacts & Invitations
            item {
                Text("Contacts & Invitations", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = AdtPrimary)
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.openSyncContacts() }
                                .testTag("btn_open_contacts_sync_settings"),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.SyncAlt, contentDescription = null, tint = AdtPrimary)
                                Column {
                                    Text("Synchroniser les contacts locaux", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                    Text(
                                        "Scannez votre carnet d'adresses et invitez facilement vos amis sur ADT Pro",
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = AdtPrimary)
                        }

                        HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp))

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.shareGeneralInvite(context) }
                                .testTag("btn_share_invite_from_settings"),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.Share, contentDescription = null, tint = AdtPrimary)
                                Column {
                                    Text("Partager le lien d'invitation ADT Pro", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                    Text(
                                        "Envoyez votre lien par SMS, WhatsApp ou réseaux sociaux",
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            Icon(Icons.Default.ChevronRight, contentDescription = null)
                        }
                    }
                }
            }

            // Privacy & Security Settings
            item {
                val privacyPrefs by viewModel.privacyPreferences.collectAsState()
                Text(strings.privacySecurity, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = AdtPrimary)
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.navigateTo(AppScreen.PRIVACY_SETTINGS) }
                                .testTag("btn_open_privacy_settings"),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.Security, contentDescription = null, tint = AdtPrimary)
                                Column {
                                    Text(strings.privacyOptions, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                    Text(
                                        "Dernière présence (${privacyPrefs.lastSeenVisibility}), Photo (${privacyPrefs.profilePhotoVisibility}), Vu (${if (privacyPrefs.readReceipts) "Activé" else "Désactivé"})",
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = AdtPrimary)
                        }

                        HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp))

                        // Dedicated E2EE Key Fingerprints for Current Chat Sessions
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.openEncryptionKeysScreen() }
                                .testTag("btn_open_encryption_keys"),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.Fingerprint, contentDescription = null, tint = AdtAccentGreen)
                                Column {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Text("Clés de chiffrement des discussions", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                        Surface(
                                            shape = RoundedCornerShape(4.dp),
                                            color = AdtAccentGreen.copy(alpha = 0.15f)
                                        ) {
                                            Text(
                                                text = "Signal E2EE",
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = AdtAccentGreen,
                                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                            )
                                        }
                                    }
                                    Text(
                                        "Empreintes uniques & numéros de sécurité des sessions",
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = AdtPrimary)
                        }

                        HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp))

                        // Two-Step Verification
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.openTwoStepVerification() }
                                .testTag("btn_open_two_step_settings"),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.VpnKey, contentDescription = null, tint = AdtPrimary)
                                Column {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Text("Vérification en deux étapes", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                        if (twoStepState.isEnabled) {
                                            Surface(
                                                shape = RoundedCornerShape(4.dp),
                                                color = AdtAccentGreen.copy(alpha = 0.15f)
                                            ) {
                                                Text(
                                                    text = "ACTIF",
                                                    fontSize = 9.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = AdtAccentGreen,
                                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                                )
                                            }
                                        }
                                    }
                                    Text(
                                        text = if (twoStepState.isEnabled) {
                                            "Code PIN actif • Lié au ${twoStepState.recoveryAccountType.displayName}"
                                        } else {
                                            "Sécuriser avec un code PIN et compte Google ou iCloud"
                                        },
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = AdtPrimary)
                        }

                        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                        // Biometric Lock Row
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.navigateTo(AppScreen.PRIVACY_SETTINGS) }
                                .testTag("btn_open_biometric_settings_from_main"),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.Fingerprint, contentDescription = null, tint = AdtPrimary)
                                Column {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Text("Verrouillage biométrique", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                        if (privacyPrefs.isBiometricEnabled) {
                                            Surface(
                                                shape = RoundedCornerShape(4.dp),
                                                color = AdtAccentGreen.copy(alpha = 0.15f)
                                            ) {
                                                Text(
                                                    text = "ACTIF",
                                                    fontSize = 9.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = AdtAccentGreen,
                                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                                )
                                            }
                                        }
                                    }
                                    Text(
                                        text = if (privacyPrefs.isBiometricEnabled) {
                                            "Empreinte / Visage actif • ${when (privacyPrefs.biometricTimeout) {
                                                "IMMEDIATELY" -> "Immédiat"
                                                "1_MIN" -> "Après 1 min"
                                                "5_MIN" -> "Après 5 min"
                                                "15_MIN" -> "Après 15 min"
                                                "1_HOUR" -> "Après 1 h"
                                                else -> "Actif"
                                            }}"
                                        } else {
                                            "Empreinte digitale & reconnaissance faciale (AndroidX)"
                                        },
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = AdtPrimary)
                        }

                        HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp))

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { showSecurityInfoDialog = true },
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Icon(Icons.Default.Lock, contentDescription = null, tint = AdtPrimary)
                                Column {
                                    Text(strings.endToEndEncryption, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                    Text("Audit des clés de sécurité & base chiffrée", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                            Icon(Icons.Default.ChevronRight, contentDescription = null)
                        }
                    }
                }
            }

            // Operators Info
            item {
                Text(strings.telecomNetwork, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = AdtPrimary)
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            strings.networkOptimizationDesc,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        LazyRow(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            item { OperatorBadge("Orange") }
                            item { OperatorBadge("Moov Africa") }
                            item { OperatorBadge("Mauritel") }
                            item { OperatorBadge("Vodacom") }
                            item { OperatorBadge("MTN") }
                            item { OperatorBadge("Camtel") }
                            item { OperatorBadge("Airtel") }
                            item { OperatorBadge("Chinguitel") }
                            item { OperatorBadge("Telecel") }
                        }
                    }
                }
            }

            // Infrastructure Mondiale & Serveurs Relais Securises
            item {
                Text("Serveurs Mondiaux & Reseau Relais", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = AdtPrimary)
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .background(AdtPrimary.copy(alpha = 0.15f), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Public, contentDescription = null, tint = AdtPrimary, modifier = Modifier.size(20.dp))
                            }
                            Spacer(Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Reseau Decentralise & Relais Mondiaux", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                val currentServer = GlobalServerNode.ALL_SERVERS.find { it.id == selectedServerId }
                                Text(
                                    "Serveur actif : " + (currentServer?.name ?: "Afrique Ouest Hub") + " - " + lastPingResult,
                                    fontSize = 11.sp,
                                    color = AdtPrimary
                                )
                            }
                            Badge(
                                containerColor = Color(0xFF2E7D32),
                                contentColor = Color.White
                            ) {
                                Text("En ligne", fontSize = 10.sp, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
                            }
                        }

                        Text(
                            "ADT Pro achemine vos messages chiffres et appels WebRTC a travers des noeuds de relais repartis dans le monde entier (Afrique, Europe, Ameriques, Asie, Moyen-Orient) avec basculement automatique et chiffrement de bout en bout.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            lineHeight = 16.sp
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = {
                                    isTestingServerLatency = true
                                    coroutineScope.launch {
                                        kotlinx.coroutines.delay(800)
                                        val randomized = (18..42).random()
                                        lastPingResult = randomized.toString() + " ms (Optimise)"
                                        isTestingServerLatency = false
                                    }
                                },
                                modifier = Modifier.weight(1f),
                                contentPadding = PaddingValues(vertical = 8.dp)
                            ) {
                                if (isTestingServerLatency) {
                                    CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                                    Spacer(Modifier.width(6.dp))
                                    Text("Test...", fontSize = 12.sp)
                                } else {
                                    Icon(Icons.Default.Speed, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("Tester latence", fontSize = 12.sp)
                                }
                            }

                            Button(
                                onClick = { showGlobalServersDialog = true },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = AdtPrimary),
                                contentPadding = PaddingValues(vertical = 8.dp)
                            ) {
                                Icon(Icons.Default.Dns, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("Changer serveur", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }

            // Intelligence Artificielle & Réponses Rapides Firebase AI (Gemini)
            item {
                val quickRepliesEnabled by viewModel.quickRepliesEnabled.collectAsState()
                val quickRepliesTone by viewModel.quickRepliesTone.collectAsState()

                Text("Intelligence Artificielle & Productivité", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = AdtPrimary)
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(38.dp)
                                        .background(AdtPrimary.copy(alpha = 0.15f), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        Icons.Default.AutoAwesome,
                                        contentDescription = null,
                                        tint = AdtPrimary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                Column {
                                    Text(
                                        "Réponses rapides Firebase AI",
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 15.sp,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        "Suggestions instantanées propulsées par Gemini",
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            Switch(
                                checked = quickRepliesEnabled,
                                onCheckedChange = { viewModel.toggleQuickRepliesEnabled(it) },
                                modifier = Modifier.testTag("switch_quick_replies_enabled")
                            )
                        }

                        if (quickRepliesEnabled) {
                            HorizontalDivider(
                                color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f),
                                thickness = 0.8.dp
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    "Modèle actif",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = AdtPrimary.copy(alpha = 0.15f)
                                ) {
                                    Text(
                                        text = "Gemini 2.5 Flash (Firebase AI SDK)",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = AdtPrimary,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                    )
                                }
                            }

                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(
                                    "Ton des suggestions",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    val tones = listOf(
                                        "FRIENDLY" to "Chaleureux",
                                        "PROFESSIONAL" to "Professionnel",
                                        "SHORT" to "Court"
                                    )
                                    tones.forEach { (key, label) ->
                                        val selected = quickRepliesTone == key
                                        Surface(
                                            shape = RoundedCornerShape(16.dp),
                                            color = if (selected) AdtPrimary else MaterialTheme.colorScheme.surface,
                                            border = if (selected) null else BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)),
                                            modifier = Modifier
                                                .clickable { viewModel.setQuickRepliesTone(key) }
                                                .testTag("tone_chip_$key")
                                        ) {
                                            Text(
                                                text = label,
                                                fontSize = 12.sp,
                                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                                                color = if (selected) Color.White else MaterialTheme.colorScheme.onSurface,
                                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Synthèse Vocale & Accessibilité (Text-to-Speech)
            item {
                val ttsLongMessagesEnabled by viewModel.ttsEnabledForLongMessages.collectAsState()
                val isTtsPlaying by viewModel.isTtsPlaying.collectAsState()
                val ttsSpeechRate by viewModel.ttsSpeechRate.collectAsState()

                Text("Accessibilité & Synthèse Vocale (TTS)", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = AdtPrimary)
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(38.dp)
                                        .background(AdtPrimary.copy(alpha = 0.15f), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        Icons.Default.RecordVoiceOver,
                                        contentDescription = null,
                                        tint = AdtPrimary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                Column {
                                    Text(
                                        "Lecture vocale des messages longs",
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 15.sp,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        "Affiche un bouton d'écoute audio sur les messages longs",
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            Switch(
                                checked = ttsLongMessagesEnabled,
                                onCheckedChange = { viewModel.toggleTtsForLongMessages(it) },
                                modifier = Modifier.testTag("switch_tts_long_messages")
                            )
                        }

                        if (ttsLongMessagesEnabled) {
                            HorizontalDivider(
                                color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f),
                                thickness = 0.8.dp
                            )

                            // Speech rate selection
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(
                                    "Vitesse de lecture vocale",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    val speeds = listOf(
                                        0.8f to "0.8x Lent",
                                        1.0f to "1.0x Normal",
                                        1.25f to "1.25x Rapide",
                                        1.5f to "1.5x Très rapide"
                                    )
                                    speeds.forEach { (rate, label) ->
                                        val selected = (ttsSpeechRate == rate)
                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = if (selected) AdtPrimary else MaterialTheme.colorScheme.surface,
                                            border = BorderStroke(
                                                1.dp,
                                                if (selected) AdtPrimary else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
                                            ),
                                            modifier = Modifier
                                                .weight(1f)
                                                .clickable { viewModel.setTtsSpeechRate(rate) }
                                                .testTag("rate_option_$rate")
                                        ) {
                                            Text(
                                                text = label,
                                                fontSize = 10.5.sp,
                                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                                                color = if (selected) Color.White else MaterialTheme.colorScheme.onSurface,
                                                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                                modifier = Modifier.padding(vertical = 6.dp)
                                            )
                                        }
                                    }
                                }
                            }

                            // Test voice action
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 2.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (isTtsPlaying) "Lecture d'un exemple en cours..." else "Tester la synthèse vocale :",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )

                                if (isTtsPlaying) {
                                    Button(
                                        onClick = { viewModel.stopTts() },
                                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                        modifier = Modifier.testTag("btn_stop_tts_test")
                                    ) {
                                        Icon(Icons.Default.Stop, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(4.dp))
                                        Text("Arrêter", fontSize = 12.sp)
                                    }
                                } else {
                                    OutlinedButton(
                                        onClick = {
                                            viewModel.speakMessage(
                                                "sample_tts_test",
                                                "Bonjour ! Ceci est un exemple de synthèse vocale pour vous faciliter la lecture des messages longs dans ADT Pro."
                                            )
                                        },
                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = AdtPrimary),
                                        border = BorderStroke(1.dp, AdtPrimary),
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                        modifier = Modifier.testTag("btn_test_tts_speech")
                                    ) {
                                        Icon(Icons.Default.VolumeUp, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(4.dp))
                                        Text("Écouter un extrait", fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Firebase Encrypted Chat Backup on Firebase Storage
            item {
                val remoteBackupInfo by viewModel.latestBackupInfo.collectAsState()
                Text("Sauvegarde & Restauration Cloud", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = AdtPrimary)
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.openChatBackup() }
                                .testTag("btn_open_chat_backup_settings"),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(42.dp)
                                        .clip(CircleShape)
                                        .background(AdtPrimary.copy(alpha = 0.15f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.CloudSync, contentDescription = null, tint = AdtPrimary, modifier = Modifier.size(24.dp))
                                }
                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Text("Sauvegarde Firebase Storage", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                        Surface(
                                            shape = RoundedCornerShape(4.dp),
                                            color = AdtAccentGreen.copy(alpha = 0.2f)
                                        ) {
                                            Text(
                                                "AES-256",
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = AdtAccentGreen,
                                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                            )
                                        }
                                    }
                                    val backupSummary = if (remoteBackupInfo != null && remoteBackupInfo!!.timestamp > 0) {
                                        "${remoteBackupInfo!!.formattedDate} • ${remoteBackupInfo!!.formattedSize}"
                                    } else if ((appSettings?.lastBackupTimestamp ?: 0L) > 0L) {
                                        "${appSettings!!.lastBackupSizeFormatted} (${appSettings!!.lastBackupMessagesCount} messages)"
                                    } else {
                                        "Aucune sauvegarde effectuée"
                                    }
                                    Text(
                                        backupSummary,
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    val freqLabel = when (appSettings?.autoBackupFrequency) {
                                        "DAILY" -> "Quotidienne"
                                        "WEEKLY" -> "Hebdomadaire"
                                        "MONTHLY" -> "Mensuelle"
                                        "OFF" -> "Désactivée"
                                        else -> "Quotidienne"
                                    }
                                    Text(
                                        "Auto: $freqLabel • ${if (appSettings?.backupOnlyWifi == true) "Wi-Fi uniquement" else "Cellulaire + Wi-Fi"}",
                                        fontSize = 11.sp,
                                        color = AdtPrimary
                                    )
                                }
                            }
                            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = AdtPrimary)
                        }

                        HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = { viewModel.performManualBackup() },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("btn_quick_backup_now"),
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = AdtPrimary)
                            ) {
                                Icon(Icons.Default.CloudUpload, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Sauvegarder", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }

                            OutlinedButton(
                                onClick = { viewModel.openChatBackup() },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("btn_manage_backup"),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.Restore, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Restaurer / Gérer", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }
            }

            // Storage Management (Stockage & Données)
            item {
                Text(
                    text = "Stockage et Données",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = AdtPrimary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.openStorageManagement() }
                        .testTag("btn_open_storage_management")
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(AdtPrimary.copy(alpha = 0.15f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.Storage, contentDescription = null, tint = AdtPrimary, modifier = Modifier.size(20.dp))
                                }
                                Column {
                                    Text("Gérer le stockage local & cloud", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                    Text(
                                        "Utilisé : ${formatBytes(storageOverview.totalAppSizeBytes)} • Libre : ${storageOverview.formattedFreeSpace}",
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        "Médias (${formatBytes(storageOverview.totalMediaSizeBytes)}) • Cache (${storageOverview.formattedCacheSize})",
                                        fontSize = 11.sp,
                                        color = AdtPrimary
                                    )
                                }
                            }
                            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = AdtPrimary)
                        }

                        HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Supprimer les fichiers volumineux & purger",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.weight(1f)
                            )
                            Button(
                                onClick = { viewModel.openStorageManagement() },
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = AdtPrimary),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Icon(Icons.Default.ManageHistory, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Gérer", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // Battery & Energy Management (High Performance vs Battery Saver & Custom Sync Interval Slider)
            item {
                Text(
                    text = "Batterie & Gestion Énergétique",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = AdtPrimary
                )
                Spacer(modifier = Modifier.height(4.dp))
                BatteryEnergyManagementCard(viewModel = viewModel)
            }

            // Firebase AI - Réponses Rapides Contextuelles
            item {
                Text("Intelligence Artificielle & Firebase AI", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = AdtPrimary)
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = AdtPrimary)
                                Column {
                                    Text(
                                        "Réponses rapides contextuelles",
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 14.sp
                                    )
                                    Text(
                                        "Propulsé par Firebase AI & modèle Gemini 3.5 Flash",
                                        fontSize = 11.5.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            Switch(
                                checked = quickRepliesEnabled,
                                onCheckedChange = { viewModel.toggleQuickRepliesEnabled(it) },
                                modifier = Modifier.testTag("switch_quick_replies_enabled")
                            )
                        }

                        if (quickRepliesEnabled) {
                            HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                            Text(
                                "Style et ton des suggestions :",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                val tones = listOf(
                                    Triple("FRIENDLY", "Amical 😊", "Chaleureux"),
                                    Triple("PROFESSIONAL", "Pro 💼", "Formel"),
                                    Triple("SHORT", "Court ⚡", "1-4 mots")
                                )
                                tones.forEach { (toneKey, label, desc) ->
                                    val isSelected = quickRepliesTone == toneKey
                                    FilterChip(
                                        selected = isSelected,
                                        onClick = { viewModel.setQuickRepliesTone(toneKey) },
                                        label = {
                                            Column(modifier = Modifier.padding(vertical = 2.dp)) {
                                                Text(label, fontSize = 11.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal)
                                                Text(desc, fontSize = 9.sp, color = if (isSelected) AdtPrimary else MaterialTheme.colorScheme.onSurfaceVariant)
                                            }
                                        },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = AdtPrimary.copy(alpha = 0.2f),
                                            selectedLabelColor = AdtPrimary
                                        ),
                                        modifier = Modifier.testTag("chip_tone_$toneKey")
                                    )
                                }
                            }

                            // Interactive Demonstration
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.surface,
                                modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
                            ) {
                                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text(
                                        "Message reçu de test : « Es-tu disponible pour faire le point à 15h ? »",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                                    )

                                    if (testReplySuggestions != null && testReplySuggestions!!.isNotEmpty()) {
                                        LazyRow(
                                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            items(testReplySuggestions!!) { suggestion ->
                                                Surface(
                                                    shape = RoundedCornerShape(12.dp),
                                                    color = AdtPrimary.copy(alpha = 0.12f),
                                                    border = BorderStroke(1.dp, AdtPrimary.copy(alpha = 0.35f))
                                                ) {
                                                    Text(
                                                        suggestion,
                                                        fontSize = 11.sp,
                                                        color = AdtPrimary,
                                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                                    )
                                                }
                                            }
                                        }
                                    }

                                    OutlinedButton(
                                        onClick = {
                                            coroutineScope.launch {
                                                isTestingAi = true
                                                val replies = FirebaseAiQuickReplyService.generateQuickReplies(
                                                    context = context,
                                                    lastMessage = "Es-tu disponible pour faire le point sur le projet à 15h ?",
                                                    senderName = "Moussa Diop",
                                                    chatTitle = "Direction Pro",
                                                    language = appSettings?.language ?: "FR",
                                                    tone = quickRepliesTone
                                                )
                                                testReplySuggestions = replies
                                                isTestingAi = false
                                            }
                                        },
                                        enabled = !isTestingAi,
                                        modifier = Modifier.fillMaxWidth().testTag("btn_test_firebase_ai"),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(if (isTestingAi) "Génération en cours..." else "Tester la génération Firebase AI", fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Local Room Database AES-256 Encryption
            item {
                Text("Sécurité de la Base de Données Room", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = AdtPrimary)
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Icon(
                                    Icons.Default.Security,
                                    contentDescription = null,
                                    tint = AdtAccentGreen
                                )
                                Column {
                                    Text(
                                        "Chiffrement local AES-256-GCM",
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 14.sp
                                    )
                                    Text(
                                        "Messages stockés scellés sur l'appareil",
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = AdtAccentGreen.copy(alpha = 0.15f)
                            ) {
                                Text(
                                    "ACTIF",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = AdtAccentGreen,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Text(
                            text = dbSecurityStatus.statusDescription,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // GESTION DES DONNÉES & DÉMONSTRATION
            item {
                Text("Gestion des Données & Démonstration", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = AdtPrimary)
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(Icons.Default.Storage, contentDescription = null, tint = AdtPrimary)
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    "Base locale enrichie ADT Pro",
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 14.sp
                                )
                                Text(
                                    "${activeChats.size} chats • ${allContacts.size} contacts • ${allChannels.size} chaînes • ${allStatuses.size} statuts • ${allCalls.size} appels",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        if (dataEnrichmentStatus != null) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = AdtPrimary.copy(alpha = 0.15f),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = AdtPrimary, modifier = Modifier.size(18.dp))
                                    Text(
                                        dataEnrichmentStatus!!,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = AdtPrimary
                                    )
                                }
                            }
                        }

                        Button(
                            onClick = { viewModel.seedEnrichedData() },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("btn_seed_enriched_data"),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = AdtPrimary)
                        ) {
                            Icon(Icons.Default.CloudSync, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("➕ Ajouter & Recharger les données pro", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                }
            }

            // Firebase Phone Account & Logout
            item {
                Text("Compte & Authentification", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = AdtPrimary)
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = AdtPrimary)
                            Column {
                                Text(
                                    "Compte vérifié par Firebase",
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 14.sp
                                )
                                Text(
                                    currentUser?.phone ?: "Non configuré",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        OutlinedButton(
                            onClick = {
                                viewModel.logoutUser()
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("btn_logout_account"),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = MaterialTheme.colorScheme.error
                            )
                        ) {
                            Icon(Icons.Default.Logout, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Se déconnecter / Changer de numéro", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        }
                    }
                }
            }

            // About & App Version with Logo
            item {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp, bottom = 12.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        androidx.compose.foundation.Image(
                            painter = androidx.compose.ui.res.painterResource(id = com.example.R.drawable.img_app_logo_adt),
                            contentDescription = "Icône ADT Pro",
                            modifier = Modifier
                                .size(56.dp)
                                .clip(RoundedCornerShape(14.dp))
                        )
                        Text("ADT Pro", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text("Version 2.4.0 • Sécurisé & Chiffré", fontSize = 11.sp, color = AdtPrimary, fontWeight = FontWeight.SemiBold)
                        Text(
                            "Messagerie instantanée d'entreprise, appels voix/vidéo HD et canaux de diffusion sécurisés.",
                            fontSize = 11.sp,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // Instructions d'installation
            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp, bottom = 4.dp)
                        .testTag("card_installation_instructions")
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.Download, contentDescription = null, tint = AdtAccentGreen)
                            Text(
                                "Instructions d'installation de l'application",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.5.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        val steps = listOf(
                            "1. Téléchargez le fichier APK depuis le bouton de téléchargement ou le portail web.",
                            "2. Ouvrez le fichier ADT_Pro_Install.apk dans vos téléchargements.",
                            "3. Si Android sollicite une confirmation, autorisez l'installation depuis cette source.",
                            "4. Appuyez sur Installer, puis démarrez l'application ADT Pro !"
                        )
                        steps.forEach { step ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.Top
                            ) {
                                Text("•", color = AdtAccentGreen, fontWeight = FontWeight.Bold)
                                Text(
                                    step,
                                    fontSize = 12.5.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    lineHeight = 17.sp
                                )
                            }
                        }
                    }
                }
            }

            // Section: Historique des versions
            item {
                Text(
                    text = "HISTORIQUE DES VERSIONS",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = AdtPrimary,
                    modifier = Modifier.padding(top = 6.dp)
                )
            }

            // Accordéon des changements récents
            item {
                var expandedVersionIndex by remember { mutableStateOf<Int?>(0) }
                val releaseHistory = remember {
                    listOf(
                        AppReleaseVersion(
                            version = "v2.4.0",
                            date = "9 Octobre 2026",
                            title = "Sécurité biométrique & Conversations verrouillées",
                            isCurrent = true,
                            changes = listOf(
                                "🔒 Authentification biométrique : Déverrouillage sécurisé par empreinte digitale ou reconnaissance faciale via AndroidX Biometric.",
                                "🛡️ Conversations verrouillées : Espace dédié pour masquer et protéger vos discussions sensibles derrière un sas biométrique.",
                                "⏱️ Reverrouillage automatique : Verrouillage immédiat ou programmable (1 min, 5 min, 15 min, 1 h) en arrière-plan.",
                                "⚙️ Confidentialité avancée : Masquage du contenu dans les notifications et option de déverrouillage de secours par code PIN."
                            )
                        ),
                        AppReleaseVersion(
                            version = "v2.3.0",
                            date = "8 Octobre 2026",
                            title = "Indicatifs internationaux & Chiffrement Signal E2EE",
                            changes = listOf(
                                "🌍 Indicatifs par pays : Détection automatique et sélecteur interactif d'indicatifs avec drapeaux nationaux (+221, +225, +223...).",
                                "🔐 Chiffrement Signal Protocol : Numéros de sécurité vérifiables et audit de chiffrement transparent Room AES-256-GCM.",
                                "🌐 Internationalisation intégrale : Support de 13 langues régionales et internationales (Wolof, Bambara, Hausa...)."
                            )
                        ),
                        AppReleaseVersion(
                            version = "v2.2.0",
                            date = "5 Octobre 2026",
                            title = "Firebase AI Gemini & Localisation en direct",
                            changes = listOf(
                                "✨ Suggestions intelligentes Firebase AI : 3 réponses rapides contextuelles adaptées au ton de la conversation.",
                                "📍 Partage de localisation Google Maps : Suivi en temps réel avec calcul d'itinéraire et mise à jour périodique.",
                                "☁️ Sauvegarde Cloud automatique : Synchronisation chiffrée automatique sur Firebase Storage et restauration instantanée."
                            )
                        ),
                        AppReleaseVersion(
                            version = "v2.1.0",
                            date = "28 Septembre 2026",
                            title = "Appels HD WebRTC & Caméra Studio Pro",
                            changes = listOf(
                                "📞 Appels audio & vidéo HD : Communications chiffrées avec contrôles micro/caméra et bascule haut-parleur.",
                                "📷 Caméra Studio professionnelle : Filtres en direct, zoom tactile et enregistrement haute définition.",
                                "🌙 Mode sombre programmable : Bascule automatique selon le coucher/lever du soleil ou horaires sur-mesure."
                            )
                        ),
                        AppReleaseVersion(
                            version = "v2.0.0",
                            date = "15 Septembre 2026",
                            title = "Interface Material 3 & Canaux de diffusion",
                            changes = listOf(
                                "🎨 Refonte Material Design 3 : Nouvelle identité visuelle Émeraude & Vert Forêt adaptée aux standards Android modernes.",
                                "📢 Canaux de diffusion publics : Canaux d'actualité pour entreprises avec abonnements et publications illimitées.",
                                "🔑 Vérification en deux étapes : Verrouillage par code PIN à 6 chiffres avec compte de récupération sécurisé."
                            )
                        )
                    )
                }

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 20.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    releaseHistory.forEachIndexed { index, release ->
                        val isExpanded = expandedVersionIndex == index
                        val rotationAngle by animateFloatAsState(
                            targetValue = if (isExpanded) 180f else 0f,
                            label = "chevron_rotation"
                        )

                        Card(
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isExpanded)
                                    MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f)
                                else
                                    MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
                            ),
                            border = if (release.isCurrent)
                                BorderStroke(1.dp, AdtAccentGreen.copy(alpha = 0.6f))
                            else
                                BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.25f)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    expandedVersionIndex = if (isExpanded) null else index
                                }
                                .testTag("accordion_version_${release.version}")
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = if (release.isCurrent) AdtAccentGreen.copy(alpha = 0.2f) else AdtPrimary.copy(alpha = 0.15f)
                                        ) {
                                            Text(
                                                text = release.version,
                                                color = if (release.isCurrent) AdtAccentGreen else AdtPrimary,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.sp,
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                            )
                                        }
                                        Text(
                                            text = release.date,
                                            fontSize = 11.5.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Icon(
                                        imageVector = Icons.Default.ExpandMore,
                                        contentDescription = if (isExpanded) "Réduire" else "Développer",
                                        tint = if (isExpanded) AdtAccentGreen else MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier
                                            .size(22.dp)
                                            .rotate(rotationAngle)
                                    )
                                }

                                Spacer(modifier = Modifier.height(4.dp))

                                Text(
                                    text = release.title,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 13.5.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )

                                AnimatedVisibility(
                                    visible = isExpanded,
                                    enter = expandVertically(),
                                    exit = shrinkVertically()
                                ) {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(top = 10.dp),
                                        verticalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        HorizontalDivider(
                                            color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f),
                                            modifier = Modifier.padding(bottom = 4.dp)
                                        )
                                        release.changes.forEach { change ->
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                                verticalAlignment = Alignment.Top
                                            ) {
                                                Text(
                                                    text = "•",
                                                    color = if (release.isCurrent) AdtAccentGreen else AdtPrimary,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 13.sp
                                                )
                                                Text(
                                                    text = change,
                                                    fontSize = 12.sp,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                    lineHeight = 16.5.sp
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Language Selection Dialog (France, Franglais, USA, Russia, España, Arabia)
    if (showLanguageDialog) {
        AlertDialog(
            onDismissRequest = { showLanguageDialog = false },
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(Icons.Default.Language, contentDescription = null, tint = AdtPrimary)
                    Text(strings.selectLanguageTitle, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                }
            },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 450.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    AppLanguage.entries.forEach { lang ->
                        val isSelected = currentLang == lang
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (isSelected) AdtPrimary.copy(alpha = 0.15f) else Color.Transparent,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.updateLanguage(lang.code)
                                    showLanguageDialog = false
                                }
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text(lang.flag, fontSize = 24.sp)
                                    Column {
                                        Text(
                                            "${lang.displayName} (${lang.countryName})",
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                            fontSize = 14.sp,
                                            color = if (isSelected) AdtPrimary else MaterialTheme.colorScheme.onSurface
                                        )
                                        Text(
                                            lang.description,
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                                if (isSelected) {
                                    Icon(
                                        Icons.Default.CheckCircle,
                                        contentDescription = null,
                                        tint = AdtPrimary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showLanguageDialog = false }) {
                    Text("OK", fontWeight = FontWeight.Bold, color = AdtPrimary)
                }
            }
        )
    }

    // Wallpaper Dialog
    if (showWallpaperDialog) {
        val wallpapers = listOf(
            "EMERALD" to "Émeraude ADT Pro",
            "DOODLE" to "Doodle Graphique",
            "MIDNIGHT" to "Minuit Sombre",
            "SUNSET" to "Coucher de Soleil",
            "SAPPHIRE" to "Saphir Bleu"
        )
        AlertDialog(
            onDismissRequest = { showWallpaperDialog = false },
            title = { Text(strings.chatWallpaper, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    wallpapers.forEach { (key, label) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.updateWallpaper(key)
                                    showWallpaperDialog = false
                                }
                                .padding(vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(label, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                            if (appSettings?.wallpaperTheme == key) {
                                Icon(Icons.Default.Check, contentDescription = null, tint = AdtPrimary)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showWallpaperDialog = false }) {
                    Text("Annuler")
                }
            }
        )
    }

    // Edit Profile Dialog
    if (showEditProfileDialog) {
        var dialogFirstName by remember { mutableStateOf(currentUser?.firstName ?: "") }
        var dialogLastName by remember { mutableStateOf(currentUser?.lastName ?: "") }
        var dialogBio by remember { mutableStateOf(currentUser?.bio ?: "Disponible sur ADT Pro") }
        var dialogBusinessCategory by remember { mutableStateOf(currentUser?.businessCategory ?: "Professionnel ADT") }
        var dialogAvatarUrl by remember { mutableStateOf(currentUser?.avatarUrl ?: "") }

        val imagePickerLauncher = rememberLauncherForActivityResult(
            contract = ActivityResultContracts.GetContent()
        ) { uri ->
            if (uri != null) {
                dialogAvatarUrl = uri.toString()
            }
        }

        AlertDialog(
            onDismissRequest = { showEditProfileDialog = false },
            title = { Text("Modifier votre profil ADT Pro", fontWeight = FontWeight.Bold) },
            text = {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    item {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Box(contentAlignment = Alignment.BottomEnd) {
                                AdtAvatar(
                                    name = if (dialogFirstName.isNotBlank()) dialogFirstName else "U",
                                    avatarKey = dialogAvatarUrl,
                                    sizeDp = 80
                                )
                                Surface(
                                    shape = CircleShape,
                                    color = AdtPrimary,
                                    modifier = Modifier
                                        .size(28.dp)
                                        .clickable { imagePickerLauncher.launch("image/*") }
                                        .border(1.5.dp, MaterialTheme.colorScheme.surface, CircleShape)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            Icons.Default.CameraAlt,
                                            contentDescription = "Changer la photo",
                                            tint = Color.White,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            TextButton(onClick = { imagePickerLauncher.launch("image/*") }) {
                                Text("Sélectionner ou importer une photo", fontSize = 12.sp, color = AdtPrimary)
                            }
                        }
                    }

                    item {
                        OutlinedTextField(
                            value = dialogFirstName,
                            onValueChange = { dialogFirstName = it },
                            label = { Text("Prénom") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    item {
                        OutlinedTextField(
                            value = dialogLastName,
                            onValueChange = { dialogLastName = it },
                            label = { Text("Nom") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    item {
                        OutlinedTextField(
                            value = dialogBio,
                            onValueChange = { dialogBio = it },
                            label = { Text("Activité / Statut") },
                            singleLine = false,
                            maxLines = 3,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    item {
                        var expanded by remember { mutableStateOf(false) }
                        val categories = listOf(
                            "Professionnel ADT",
                            "Secteur Télécoms",
                            "Services Financiers",
                            "Distribution / Commerce",
                            "Santé / Pro",
                            "Administration"
                        )
                        Box(modifier = Modifier.fillMaxWidth()) {
                            OutlinedTextField(
                                value = dialogBusinessCategory,
                                onValueChange = {},
                                label = { Text("Secteur d'activité") },
                                readOnly = true,
                                trailingIcon = {
                                    IconButton(onClick = { expanded = !expanded }) {
                                        Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                                    }
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { expanded = !expanded }
                            )
                            DropdownMenu(
                                expanded = expanded,
                                onDismissRequest = { expanded = false },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                categories.forEach { category ->
                                    DropdownMenuItem(
                                        text = { Text(category) },
                                        onClick = {
                                            dialogBusinessCategory = category
                                            expanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.updateUserProfile(
                            firstName = dialogFirstName.trim(),
                            lastName = dialogLastName.trim(),
                            bio = dialogBio.trim(),
                            businessCategory = dialogBusinessCategory,
                            avatarUrl = dialogAvatarUrl
                        )
                        showEditProfileDialog = false
                    }
                ) {
                    Text("Enregistrer", fontWeight = FontWeight.Bold, color = AdtPrimary)
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditProfileDialog = false }) {
                    Text("Annuler")
                }
            }
        )
    }

    // Sticker Selection Dialog
    if (showStickersDialog) {
        val packs = listOf(
            "PRO" to "Professionnel ADT pro (Affaires, Pro)",
            "FUN" to "Fun & Casual (Café, Fête, Étoiles, Pause)",
            "TECH" to "Sécurité & Crypto (Données, Clé, Chiffrement)"
        )
        AlertDialog(
            onDismissRequest = { showStickersDialog = false },
            title = { Text("Pack d'autocollants actif", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    packs.forEach { (key, label) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.updateStickerPack(key)
                                    showStickersDialog = false
                                }
                                .padding(vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(label, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                            if (appSettings?.activeStickerPack == key) {
                                Icon(Icons.Default.Check, contentDescription = null, tint = AdtPrimary)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showStickersDialog = false }) {
                    Text("Annuler")
                }
            }
        )
    }

    // Privacy Dialog
    if (showPrivacyDialog) {
        AlertDialog(
            onDismissRequest = { showPrivacyDialog = false },
            title = { Text(strings.privacyOptions, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Dernière présence & En ligne : Mes contacts", fontSize = 13.sp)
                    Text("Photo de profil : Tout le monde", fontSize = 13.sp)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Confirmations de lecture (Vu)", fontSize = 13.sp)
                        Switch(
                            checked = appSettings?.readReceipts ?: true,
                            onCheckedChange = { viewModel.updatePrivacySettings("EVERYONE", "EVERYONE", it) }
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showPrivacyDialog = false }) {
                    Text("Enregistrer")
                }
            }
        )
    }

    // Security Encryption Dialog
    if (showSecurityInfoDialog) {
        AlertDialog(
            onDismissRequest = { showSecurityInfoDialog = false },
            title = { Text(strings.endToEndEncryption, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        strings.encryptedNotice,
                        fontSize = 13.sp
                    )
                    Text(
                        "Clé de sécurité de votre compte :",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = AdtPrimary
                    )
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            "8492-3104-9912-7481-0239-ADT-PRO",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.padding(8.dp)
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showSecurityInfoDialog = false }) {
                    Text("Compris")
                }
            }
        )
    }

    // QR Code Dialog
    if (showQrCodeDialog) {
        AlertDialog(
            onDismissRequest = { showQrCodeDialog = false },
            title = { Text(strings.qrCodeTitle, fontWeight = FontWeight.Bold) },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    AdtAvatar(name = userFullName, sizeDp = 64)
                    Text(userFullName, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text(currentUser?.phone ?: "", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Icon(
                        Icons.Default.QrCode2,
                        contentDescription = "QR Code",
                        modifier = Modifier.size(160.dp),
                        tint = AdtPrimary
                    )
                    Text("Scannez ce QR Code pour ajouter ce contact sur ADT Pro", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            },
            confirmButton = {
                TextButton(onClick = { showQrCodeDialog = false }) {
                    Text("Fermer")
                }
            }
        )
    }

    if (showGlobalServersDialog) {
        AlertDialog(
            onDismissRequest = { showGlobalServersDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Public, contentDescription = null, tint = AdtPrimary, modifier = Modifier.size(24.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Reseau Mondial de Relais", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        "Selectionnez un noeud de communication pour router vos echanges en toute fluidite avec un temps de latence minimal :",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    GlobalServerNode.ALL_SERVERS.forEach { node ->
                        val isSelected = (node.id == selectedServerId)
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    selectedServerId = node.id
                                    lastPingResult = node.pingMs.toString() + " ms (Connecte)"
                                    showGlobalServersDialog = false
                                },
                            shape = RoundedCornerShape(10.dp),
                            color = if (isSelected) AdtPrimary.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                            border = BorderStroke(
                                width = if (isSelected) 1.5.dp else 1.dp,
                                color = if (isSelected) AdtPrimary else Color.Transparent
                            )
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(node.flag, fontSize = 24.sp)
                                Spacer(Modifier.width(10.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(node.name, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                        if (node.isRecommended) {
                                            Spacer(Modifier.width(4.dp))
                                            Text(
                                                "Recommande",
                                                fontSize = 9.sp,
                                                color = Color(0xFF2E7D32),
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                    Text(node.city + " - " + node.endpoint, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        node.pingMs.toString() + " ms",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (node.pingMs < 50) Color(0xFF2E7D32) else AdtPrimary
                                    )
                                    if (isSelected) {
                                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = AdtPrimary, modifier = Modifier.size(16.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showGlobalServersDialog = false }) {
                    Text("Fermer")
                }
            }
        )
    }
}

data class AppReleaseVersion(
    val version: String,
    val date: String,
    val title: String,
    val isCurrent: Boolean = false,
    val changes: List<String>
)
