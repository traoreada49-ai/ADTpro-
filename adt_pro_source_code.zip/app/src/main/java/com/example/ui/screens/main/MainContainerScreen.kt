package com.example.ui.screens.main

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.CallMade
import androidx.compose.material.icons.automirrored.filled.CallReceived
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.live.*
import com.example.data.local.entity.CallLogEntity
import com.example.data.local.entity.ChannelEntity
import com.example.data.local.entity.ChatEntity
import com.example.data.local.entity.MessageEntity
import com.example.data.local.entity.StatusEntity
import com.example.ui.components.AdtAvatar
import com.example.ui.components.HomeColorPickerDialog
import com.example.ui.components.ShareLiveLocationDialog
import com.example.ui.screens.live.StartLiveBroadcastDialog
import com.example.ui.theme.*
import com.example.ui.util.AppLanguage
import com.example.ui.util.TranslationStrings
import com.example.ui.util.getStringsForLanguage
import com.example.viewmodel.ActiveCallState
import com.example.viewmodel.AdtViewModel
import com.example.viewmodel.AppScreen
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainContainerScreen(viewModel: AdtViewModel) {
    val activeChats by viewModel.activeChats.collectAsState()
    val lockedChatsCount by viewModel.lockedChatsCount.collectAsState()
    val allStatuses by viewModel.allStatuses.collectAsState()
    val allChannels by viewModel.allChannels.collectAsState()
    val allCalls by viewModel.allCalls.collectAsState()
    val appSettings by viewModel.appSettings.collectAsState()
    val matchingChatIdsFromMessages by viewModel.matchingChatIdsFromMessages.collectAsState()
    val matchingMessages by viewModel.matchingMessages.collectAsState()
    val showShareLocationDialog by viewModel.showShareLocationDialog.collectAsState()
    val allContacts by viewModel.allContacts.collectAsState()
    val activeCall by viewModel.activeCall.collectAsState()

    val strings = remember(appSettings?.language) {
        getStringsForLanguage(appSettings?.language)
    }
    val currentLang = remember(appSettings?.language) {
        AppLanguage.fromCode(appSettings?.language)
    }

    var selectedTabIndex by remember { mutableIntStateOf(0) }
    var showMenu by remember { mutableStateOf(false) }
    var showQuickLangDialog by remember { mutableStateOf(false) }
    var showHomeColorPicker by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var isSearchActive by remember { mutableStateOf(false) }
    var selectedFilterIndex by remember { mutableIntStateOf(0) }

    val homePaletteColor by viewModel.homeColorTheme.collectAsState()
    val homePrimary = if (homePaletteColor == AdtPaletteColor.BLANCHE) Color(0xFF2E2E2E) else if (homePaletteColor == AdtPaletteColor.VERT) AdtPrimary else homePaletteColor.primary
    val homeAccent = if (homePaletteColor == AdtPaletteColor.VERT) AdtAccentGreen else homePaletteColor.lightVariant

    val tabTitles = listOf(
        strings.tabDiscussions,
        strings.tabStatuses,
        strings.tabChannels,
        strings.tabCalls
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    if (isSearchActive) {
                        TextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = { Text(strings.searchPlaceholder, color = MaterialTheme.colorScheme.onSurfaceVariant) },
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.Transparent,
                                unfocusedContainerColor = Color.Transparent,
                                focusedIndicatorColor = Color.Transparent,
                                unfocusedIndicatorColor = Color.Transparent
                            ),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    } else {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            androidx.compose.foundation.Image(
                                painter = androidx.compose.ui.res.painterResource(id = com.example.R.drawable.img_app_logo_adt),
                                contentDescription = "Logo ADT",
                                modifier = Modifier
                                    .size(28.dp)
                                    .clip(RoundedCornerShape(7.dp))
                            )
                            Text(
                                strings.appTitle,
                                fontWeight = FontWeight.Bold,
                                fontSize = 20.sp,
                                color = homePrimary
                            )
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = homePrimary.copy(alpha = 0.15f)
                            ) {
                                Text(
                                    strings.appBadge,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = homePrimary,
                                    modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                },
                actions = {
                    // Home Screen Color Picker Quick Button
                    IconButton(
                        onClick = { showHomeColorPicker = true },
                        modifier = Modifier.testTag("btn_home_color_picker")
                    ) {
                        Box(
                            modifier = Modifier
                                .size(24.dp)
                                .clip(CircleShape)
                                .background(homePaletteColor.primary)
                                .border(
                                    1.dp,
                                    if (homePaletteColor == AdtPaletteColor.BLANCHE) Color.Gray else MaterialTheme.colorScheme.outline.copy(alpha = 0.4f),
                                    CircleShape
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Default.Palette,
                                contentDescription = "Changer la couleur d'accueil",
                                tint = if (homePaletteColor == AdtPaletteColor.BLANCHE) Color.Black else Color.White,
                                modifier = Modifier.size(13.dp)
                            )
                        }
                    }

                    // Camera QR Scanner Shortcut
                    IconButton(
                        onClick = { viewModel.openContactQrCode(initialTab = 1) },
                        modifier = Modifier.testTag("btn_top_qr_scanner")
                    ) {
                        Icon(
                            Icons.Default.QrCodeScanner,
                            contentDescription = "Scanner Code QR Contact",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    // Camera Studio Quick Action
                    IconButton(
                        onClick = { viewModel.openCamera() },
                        modifier = Modifier.testTag("btn_top_camera_studio")
                    ) {
                        Icon(
                            Icons.Default.CameraAlt,
                            contentDescription = "Appareil Photo & Vidéo",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    // Quick Search
                    IconButton(onClick = { isSearchActive = !isSearchActive }) {
                        Icon(
                            if (isSearchActive) Icons.Default.Close else Icons.Default.Search,
                            contentDescription = "Rechercher",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    // Language Quick Switcher button
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                        modifier = Modifier
                            .clickable { showQuickLangDialog = true }
                            .padding(end = 4.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(2.dp),
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
                        ) {
                            Text(currentLang.flag, fontSize = 16.sp)
                            Text(currentLang.code, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    // Theme Toggle (Sombre / Clair / Auto selon horaire)
                    IconButton(
                        onClick = {
                            viewModel.toggleThemeModeCycle()
                        },
                        modifier = Modifier.testTag("btn_theme_toggle")
                    ) {
                        val currentMode = appSettings?.themeMode ?: "DARK"
                        val (icon, desc) = when (currentMode) {
                            "DARK" -> Icons.Default.LightMode to "Mode sombre actif — Toucher pour mode clair"
                            "LIGHT" -> Icons.Default.Schedule to "Mode clair actif — Toucher pour mode auto programmation"
                            "AUTO_SCHEDULE" -> Icons.Default.DarkMode to "Mode auto actif (horaire) — Toucher pour mode sombre"
                            else -> Icons.Default.DarkMode to "Basculer thème"
                        }
                        Icon(
                            imageVector = icon,
                            contentDescription = desc,
                            tint = if (currentMode == "AUTO_SCHEDULE") AdtPrimary else MaterialTheme.colorScheme.onSurface
                        )
                    }

                    // Overflow Menu
                    Box {
                        IconButton(onClick = { showMenu = true }) {
                            Icon(Icons.Default.MoreVert, contentDescription = "Plus d'options")
                        }
                        DropdownMenu(
                            expanded = showMenu,
                            onDismissRequest = { showMenu = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text(strings.menuNewGroup) },
                                onClick = {
                                    showMenu = false
                                    viewModel.navigateTo(AppScreen.CREATE_GROUP)
                                },
                                leadingIcon = { Icon(Icons.Default.GroupAdd, contentDescription = null) }
                            )
                            DropdownMenuItem(
                                text = { Text(strings.menuNewChannel) },
                                onClick = {
                                    showMenu = false
                                    viewModel.navigateTo(AppScreen.CREATE_CHANNEL)
                                },
                                leadingIcon = { Icon(Icons.Default.Campaign, contentDescription = null) }
                            )
                            DropdownMenuItem(
                                text = { Text("Localisation en direct") },
                                onClick = {
                                    showMenu = false
                                    viewModel.openLiveLocationSharingScreen()
                                },
                                leadingIcon = { Icon(Icons.Default.ShareLocation, contentDescription = null, tint = AdtPrimary) }
                            )
                            DropdownMenuItem(
                                text = { Text("Appareil Photo & Vidéo") },
                                onClick = {
                                    showMenu = false
                                    viewModel.openCamera()
                                },
                                leadingIcon = { Icon(Icons.Default.PhotoCamera, contentDescription = null) }
                            )
                            DropdownMenuItem(
                                text = { Text("Fonds d'écran") },
                                onClick = {
                                    showMenu = false
                                    viewModel.openWallpaperPicker()
                                },
                                leadingIcon = { Icon(Icons.Default.Wallpaper, contentDescription = null) }
                            )
                            DropdownMenuItem(
                                text = {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Text("Couleur d'accueil")
                                        Surface(
                                            shape = RoundedCornerShape(4.dp),
                                            color = homePrimary.copy(alpha = 0.18f)
                                        ) {
                                            Text(
                                                text = "${homePaletteColor.emojiBadge} ${homePaletteColor.frenchName}",
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = homePrimary,
                                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                            )
                                        }
                                    }
                                },
                                onClick = {
                                    showMenu = false
                                    showHomeColorPicker = true
                                },
                                leadingIcon = { Icon(Icons.Default.Palette, contentDescription = null, tint = homePrimary) },
                                modifier = Modifier.testTag("menu_change_home_color")
                            )
                            DropdownMenuItem(
                                text = { Text(strings.menuLanguage) },
                                onClick = {
                                    showMenu = false
                                    showQuickLangDialog = true
                                },
                                leadingIcon = { Icon(Icons.Default.Language, contentDescription = null) }
                            )
                            DropdownMenuItem(
                                text = { Text("➕ Ajouter les données pro") },
                                onClick = {
                                    showMenu = false
                                    viewModel.seedEnrichedData()
                                },
                                leadingIcon = { Icon(Icons.Default.CloudSync, contentDescription = null, tint = AdtPrimary) }
                            )
                            DropdownMenuItem(
                                text = { Text("Code QR & Réseau Pro") },
                                onClick = {
                                    showMenu = false
                                    viewModel.openContactQrCode()
                                },
                                leadingIcon = { Icon(Icons.Default.QrCode2, contentDescription = null, tint = AdtPrimary) }
                            )
                            DropdownMenuItem(
                                text = { Text("Inviter des amis & Contacts") },
                                onClick = {
                                    showMenu = false
                                    viewModel.openSyncContacts()
                                },
                                leadingIcon = { Icon(Icons.Default.PersonAdd, contentDescription = null, tint = AdtPrimary) }
                            )
                            DropdownMenuItem(
                                text = { Text(strings.menuSettings) },
                                onClick = {
                                    showMenu = false
                                    viewModel.navigateTo(AppScreen.SETTINGS)
                                },
                                leadingIcon = { Icon(Icons.Default.Settings, contentDescription = null) }
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        floatingActionButton = {
            when (selectedTabIndex) {
                0 -> { // Chats / Discussions
                    Column(
                        horizontalAlignment = Alignment.End,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        SmallFloatingActionButton(
                            onClick = { viewModel.openContactQrCode(initialTab = 0) },
                            containerColor = MaterialTheme.colorScheme.surfaceVariant,
                            contentColor = homePrimary,
                            modifier = Modifier.testTag("fab_my_qr_code")
                        ) {
                            Icon(Icons.Default.QrCode2, contentDescription = "Mon QR Code")
                        }
                        SmallFloatingActionButton(
                            onClick = { viewModel.navigateTo(AppScreen.CREATE_GROUP) },
                            containerColor = MaterialTheme.colorScheme.surfaceVariant,
                            contentColor = homePrimary,
                            modifier = Modifier.testTag("fab_new_group")
                        ) {
                            Icon(Icons.Default.GroupAdd, contentDescription = "Nouveau groupe")
                        }
                        SmallFloatingActionButton(
                            onClick = { viewModel.navigateTo(AppScreen.CONTACTS_LIST) },
                            containerColor = MaterialTheme.colorScheme.surfaceVariant,
                            contentColor = homePrimary,
                            modifier = Modifier.testTag("fab_new_chat")
                        ) {
                            Icon(Icons.Default.Chat, contentDescription = "Nouvelle discussion")
                        }

                        // Bouton flottant principal : Ouvrir la caméra pour scanner des codes QR de contacts
                        ExtendedFloatingActionButton(
                            onClick = { viewModel.openContactQrCode(initialTab = 1) },
                            containerColor = homeAccent,
                            contentColor = Color.White,
                            icon = {
                                Icon(
                                    Icons.Default.QrCodeScanner,
                                    contentDescription = "Scanner Code QR Contact (Caméra)",
                                    modifier = Modifier.size(24.dp)
                                )
                            },
                            text = {
                                Text(
                                    text = "Scanner QR Ami",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.5.sp
                                )
                            },
                            modifier = Modifier.testTag("fab_scan_qr_contact")
                        )
                    }
                }
                1 -> { // Status
                    Column(
                        horizontalAlignment = Alignment.End,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        SmallFloatingActionButton(
                            onClick = { viewModel.navigateTo(AppScreen.CREATE_STATUS) },
                            containerColor = MaterialTheme.colorScheme.surfaceVariant,
                            contentColor = MaterialTheme.colorScheme.onSurfaceVariant
                        ) {
                            Icon(Icons.Default.Edit, contentDescription = "Écrire un statut")
                        }
                        FloatingActionButton(
                            onClick = { viewModel.openCamera(forStatus = true) },
                            containerColor = homePrimary,
                            contentColor = Color.White,
                            modifier = Modifier.testTag("fab_new_status")
                        ) {
                            Icon(Icons.Default.CameraAlt, contentDescription = "Photo/Vidéo statut")
                        }
                    }
                }
                2 -> { // Channels
                    FloatingActionButton(
                        onClick = { viewModel.navigateTo(AppScreen.CREATE_CHANNEL) },
                        containerColor = homePrimary,
                        contentColor = Color.White,
                        modifier = Modifier.testTag("fab_new_channel")
                    ) {
                        Icon(Icons.Default.Campaign, contentDescription = strings.createChannel)
                    }
                }
                3 -> { // Calls
                    Column(
                        horizontalAlignment = Alignment.End,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        SmallFloatingActionButton(
                            onClick = { viewModel.openContactQrCode(initialTab = 1) },
                            containerColor = MaterialTheme.colorScheme.surfaceVariant,
                            contentColor = homeAccent,
                            modifier = Modifier.testTag("fab_calls_scan_qr")
                        ) {
                            Icon(Icons.Default.QrCodeScanner, contentDescription = "Scanner QR Ami")
                        }
                        FloatingActionButton(
                            onClick = { viewModel.navigateTo(AppScreen.CONTACTS_LIST) },
                            containerColor = homePrimary,
                            contentColor = Color.White,
                            modifier = Modifier.testTag("fab_new_call")
                        ) {
                            Icon(Icons.Default.Call, contentDescription = strings.newCall)
                        }
                    }
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // Floating Mini Call Banner if a WebRTC call is ongoing or incoming
            if (activeCall != null) {
                FloatingMiniCallBanner(
                    activeCall = activeCall!!,
                    onRestore = { viewModel.restoreCall() },
                    onToggleMute = { viewModel.toggleCallMute() },
                    onEndCall = { viewModel.endCall() },
                    onAccept = { viewModel.acceptIncomingCall() }
                )
            }

            // Tab Row
            SecondaryTabRow(
                selectedTabIndex = selectedTabIndex,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = homePrimary,
                indicator = {
                    TabRowDefaults.SecondaryIndicator(
                        modifier = Modifier.tabIndicatorOffset(selectedTabIndex),
                        color = homePrimary
                    )
                }
            ) {
                tabTitles.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTabIndex == index,
                        onClick = { selectedTabIndex = index },
                        text = {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text(
                                    text = title,
                                    fontWeight = if (selectedTabIndex == index) FontWeight.Bold else FontWeight.Medium,
                                    fontSize = 13.sp,
                                    color = if (selectedTabIndex == index) homePrimary else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                if (index == 0) {
                                    val totalUnread = activeChats.sumOf { it.unreadCount }
                                    if (totalUnread > 0) {
                                        Surface(
                                            shape = CircleShape,
                                            color = homePrimary,
                                            modifier = Modifier.size(18.dp)
                                        ) {
                                            Box(contentAlignment = Alignment.Center) {
                                                Text("$totalUnread", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    )
                }
            }

            // Tab Content
            when (selectedTabIndex) {
                0 -> ChatsTabContent(
                    chats = activeChats.filter {
                        if (searchQuery.isNotBlank()) {
                            val cleanQuery = searchQuery.trim()
                            val cleanDigits = cleanQuery.filter { it.isDigit() || it == '+' }
                            it.title.contains(cleanQuery, ignoreCase = true) ||
                            it.lastMessage.contains(cleanQuery, ignoreCase = true) ||
                            it.creatorPhone.contains(cleanQuery) ||
                            (cleanDigits.length >= 2 && it.creatorPhone.filter { c -> c.isDigit() || c == '+' }.contains(cleanDigits)) ||
                            it.id in matchingChatIdsFromMessages
                        } else when (selectedFilterIndex) {
                            1 -> it.unreadCount > 0
                            2 -> it.isGroup
                            else -> true
                        }
                    },
                    searchQuery = searchQuery,
                    onSearchQueryChange = { query ->
                        searchQuery = query
                        viewModel.updateChatSearchQuery(query)
                    },
                    matchingMessages = matchingMessages,
                    selectedFilterIndex = selectedFilterIndex,
                    onSelectFilterIndex = { selectedFilterIndex = it },
                    strings = strings,
                    lockedChatsCount = lockedChatsCount,
                    onOpenLockedChats = { viewModel.openLockedChatsScreen() },
                    onLockChat = { chat -> viewModel.setChatLocked(chat.id, true) },
                    onChatClick = { chat ->
                        if (chat.isLocked && !viewModel.isLockedChatsSessionUnlocked.value) {
                            viewModel.openLockedChatsScreen()
                        } else {
                            viewModel.openChat(chat.id)
                        }
                    },
                    onOpenLiveLocationShare = { viewModel.openLiveLocationSharingScreen() }
                )
                1 -> StatusTabContent(
                    statuses = allStatuses,
                    strings = strings,
                    onStatusClick = { viewModel.openStatus(it) },
                    onCreateStatus = { viewModel.navigateTo(AppScreen.CREATE_STATUS) }
                )
                2 -> ChannelsTabContent(
                    channels = allChannels.filter {
                        if (searchQuery.isNotBlank()) it.name.contains(searchQuery, ignoreCase = true) || it.description.contains(searchQuery, ignoreCase = true)
                        else true
                    },
                    strings = strings,
                    onChannelClick = { viewModel.openChannel(it.id) },
                    onCreateChannel = { viewModel.navigateTo(AppScreen.CREATE_CHANNEL) }
                )
                3 -> CallsTabContent(
                    calls = allCalls,
                    strings = strings,
                    onStartCall = { name, phone, avatar, isVideo ->
                        viewModel.startCall(name, phone, avatar, isVideo)
                    },
                    onSimulateIncomingCall = { isVideo ->
                        viewModel.simulateIncomingCall(isVideo)
                    },
                    onSimulateMissedCall = { isVideo ->
                        viewModel.simulateMissedCallNotification(isVideo)
                    }
                )
            }
        }
    }

    // Quick Language Dialog
    if (showQuickLangDialog) {
        AlertDialog(
            onDismissRequest = { showQuickLangDialog = false },
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(Icons.Default.Language, contentDescription = null, tint = AdtPrimary)
                    Text(strings.selectLanguageTitle, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                }
            },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 450.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    AppLanguage.entries.forEach { lang ->
                        val isSelected = currentLang == lang
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (isSelected) AdtPrimary.copy(alpha = 0.15f) else Color.Transparent,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.updateLanguage(lang.code)
                                    showQuickLangDialog = false
                                }
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text(lang.flag, fontSize = 24.sp)
                                    Column {
                                        Text(
                                            "${lang.displayName} (${lang.countryName})",
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                            fontSize = 14.sp,
                                            color = if (isSelected) AdtPrimary else MaterialTheme.colorScheme.onSurface
                                        )
                                        Text(
                                            lang.description,
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                                if (isSelected) {
                                    Icon(
                                        Icons.Default.CheckCircle,
                                        contentDescription = null,
                                        tint = AdtPrimary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showQuickLangDialog = false }) {
                    Text("OK", fontWeight = FontWeight.Bold, color = AdtPrimary)
                }
            }
        )
    }

    // Share Live Location Dialog
    if (showShareLocationDialog) {
        ShareLiveLocationDialog(
            allContacts = allContacts,
            preselectedContactPhoneOrChatId = null,
            onDismiss = { viewModel.closeShareLocationDialog() },
            onConfirmShare = { contacts, duration, comment, location ->
                viewModel.shareLiveLocation(contacts, duration, comment, location)
            }
        )
    }

    // Home Screen Color Picker Dialog
    if (showHomeColorPicker) {
        HomeColorPickerDialog(
            currentPaletteColor = homePaletteColor,
            onSelectColor = { selected ->
                viewModel.setHomeColorTheme(selected)
            },
            onDismiss = { showHomeColorPicker = false }
        )
    }
}

@Composable
fun ChatsTabContent(
    chats: List<ChatEntity>,
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    matchingMessages: List<MessageEntity> = emptyList(),
    selectedFilterIndex: Int,
    onSelectFilterIndex: (Int) -> Unit,
    strings: TranslationStrings,
    lockedChatsCount: Int = 0,
    onOpenLockedChats: () -> Unit = {},
    onLockChat: (ChatEntity) -> Unit = {},
    onChatClick: (ChatEntity) -> Unit,
    onOpenLiveLocationShare: () -> Unit = {}
) {
    val filters = listOf(strings.filterAll, strings.filterUnread, strings.filterGroups)

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 80.dp)
    ) {
        // Prominent Main Search Bar
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchQueryChange,
                placeholder = {
                    Text(strings.searchPlaceholder, fontSize = 14.sp)
                },
                leadingIcon = {
                    Icon(Icons.Default.Search, contentDescription = "Rechercher", tint = AdtPrimary)
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { onSearchQueryChange("") }) {
                            Icon(Icons.Default.Clear, contentDescription = "Effacer")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(24.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = AdtPrimary,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f),
                    focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 6.dp)
                    .testTag("search_bar_chats")
            )
        }

        if (searchQuery.isNotBlank()) {
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 2.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${chats.size} discussion(s) trouvée(s)",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = AdtPrimary
                    )
                    Text(
                        text = "Effacer",
                        fontSize = 11.5.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier
                            .clickable { onSearchQueryChange("") }
                            .padding(4.dp)
                    )
                }
            }
        }

        // Filter Chips Row
        item {
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(filters.size) { idx ->
                    FilterChip(
                        selected = selectedFilterIndex == idx,
                        onClick = { onSelectFilterIndex(idx) },
                        label = { Text(filters[idx], fontSize = 12.sp) }
                    )
                }
            }
        }

        // Section: Discussions verrouillées (Protégées par Biométrie)
        item {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = AdtPrimary.copy(alpha = 0.08f),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 4.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .clickable { onOpenLockedChats() }
                    .testTag("row_locked_chats_entry")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = AdtPrimary.copy(alpha = 0.18f),
                            modifier = Modifier.size(38.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    Icons.Default.Lock,
                                    contentDescription = "Discussions verrouillées",
                                    tint = AdtPrimary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                        Column {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = "Discussions verrouillées",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                                if (lockedChatsCount > 0) {
                                    Surface(
                                        shape = CircleShape,
                                        color = AdtAccentGreen,
                                        modifier = Modifier.size(18.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Text(
                                                text = "$lockedChatsCount",
                                                color = Color.White,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }
                            }
                            Text(
                                text = "Touchez pour déverrouiller par empreinte ou visage",
                                fontSize = 11.5.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Icon(
                        Icons.Default.Fingerprint,
                        contentDescription = "Empreinte / Visage",
                        tint = AdtPrimary,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
        }

        if (chats.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(40.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        strings.noChatsFound,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 13.sp
                    )
                }
            }
        }

        items(chats) { chat ->
            val timeFormatted = remember(chat.lastTimestamp) {
                SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(chat.lastTimestamp))
            }
            val matchingMsg = remember(chat.id, matchingMessages, searchQuery) {
                if (searchQuery.isNotBlank() && !chat.title.contains(searchQuery, ignoreCase = true)) {
                    matchingMessages.find { it.chatId == chat.id }
                } else null
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onChatClick(chat) }
                    .padding(horizontal = 16.dp, vertical = 12.dp)
                    .testTag("chat_item_${chat.id}"),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    AdtAvatar(name = chat.title, sizeDp = 50, isOnline = !chat.isGroup)
                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = chat.title,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f, fill = false)
                            )
                            Text(
                                text = timeFormatted,
                                fontSize = 11.sp,
                                color = if (chat.unreadCount > 0) AdtPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = chat.lastMessage,
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )
                            if (chat.isPinned) {
                                Icon(Icons.Default.PushPin, contentDescription = "Épinglé", tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(14.dp))
                            }
                            if (chat.unreadCount > 0) {
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    shape = CircleShape,
                                    color = AdtPrimary,
                                    modifier = Modifier.size(20.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text(
                                            "${chat.unreadCount}",
                                            color = Color.White,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                        if (matchingMsg != null) {
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = AdtPrimary.copy(alpha = 0.12f),
                                modifier = Modifier.padding(top = 4.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Icon(
                                        Icons.Default.ChatBubbleOutline,
                                        contentDescription = null,
                                        tint = AdtPrimary,
                                        modifier = Modifier.size(11.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "Message : \"${matchingMsg.text}\"",
                                        fontSize = 11.5.sp,
                                        color = AdtPrimary,
                                        fontWeight = FontWeight.Medium,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }

                var showChatMenu by remember { mutableStateOf(false) }
                Box {
                    IconButton(
                        onClick = { showChatMenu = true },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            Icons.Default.MoreVert,
                            contentDescription = "Options de discussion",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    DropdownMenu(
                        expanded = showChatMenu,
                        onDismissRequest = { showChatMenu = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("Ouvrir la discussion") },
                            leadingIcon = { Icon(Icons.Default.Chat, contentDescription = null, tint = AdtPrimary) },
                            onClick = {
                                showChatMenu = false
                                onChatClick(chat)
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Verrouiller la discussion (Biométrie)") },
                            leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null, tint = AdtAccentGreen) },
                            onClick = {
                                showChatMenu = false
                                onLockChat(chat)
                            }
                        )
                    }
                }
            }
            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f), modifier = Modifier.padding(start = 76.dp))
        }
    }
}

@Composable
fun StatusTabContent(
    statuses: List<StatusEntity>,
    strings: TranslationStrings,
    onStatusClick: (StatusEntity) -> Unit,
    onCreateStatus: () -> Unit
) {
    val currentTime = remember { System.currentTimeMillis() }
    val twentyFourHoursAgo = remember(currentTime) { currentTime - (24L * 60L * 60L * 1000L) }
    val activeStatuses = remember(statuses) {
        statuses.filter { it.timestamp >= twentyFourHoursAgo }
    }
    val myStatus = activeStatuses.find { it.isSelf }
    val contactStatuses = activeStatuses.filter { !it.isSelf }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 80.dp)
    ) {
        // My Status Row
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        if (myStatus != null) {
                            onStatusClick(myStatus)
                        } else {
                            onCreateStatus()
                        }
                    }
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Box(contentAlignment = Alignment.BottomEnd) {
                    AdtAvatar(name = strings.myStatus, sizeDp = 52, hasStatusStory = myStatus != null)
                    Surface(
                        shape = CircleShape,
                        color = AdtPrimary,
                        modifier = Modifier.size(20.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                if (myStatus != null) Icons.Default.Visibility else Icons.Default.Add,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(13.dp)
                            )
                        }
                    }
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(strings.myStatus, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    if (myStatus != null) {
                        val hoursLeft = ((myStatus.timestamp + 24L * 3600L * 1000L - System.currentTimeMillis()) / (3600L * 1000L)).coerceAtLeast(0)
                        Text(
                            "Actif • Expire dans ${hoursLeft}h • ${myStatus.viewsCount} vues",
                            fontSize = 12.sp,
                            color = AdtPrimary,
                            fontWeight = FontWeight.Medium
                        )
                    } else {
                        Text(strings.tapToAddStatus, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                if (myStatus != null) {
                    IconButton(onClick = onCreateStatus) {
                        Icon(Icons.Default.AddCircleOutline, contentDescription = "Ajouter un autre statut", tint = AdtPrimary)
                    }
                }
            }
            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
        }

        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    strings.recentUpdates,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = AdtPrimary
                )
                Text(
                    "Éphémères (24h)",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        if (contactStatuses.isEmpty()) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 32.dp, bottom = 20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        Icons.Default.HourglassEmpty,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                        modifier = Modifier.size(36.dp)
                    )
                    Text(
                        "Aucune mise à jour récente",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        "Les statuts publiés par vos contacts disparaissent au bout de 24h",
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
                        fontSize = 12.sp
                    )
                }
            }
        } else {
            items(contactStatuses) { status ->
                val timeFormatted = remember(status.timestamp) {
                    SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(status.timestamp))
                }
                val hoursRemaining = remember(status.timestamp) {
                    val expire = status.timestamp + 24L * 3600L * 1000L
                    ((expire - System.currentTimeMillis()) / (3600L * 1000L)).coerceAtLeast(0)
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onStatusClick(status) }
                        .padding(horizontal = 16.dp, vertical = 10.dp)
                        .testTag("status_item_${status.id}"),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    AdtAvatar(name = status.authorName, sizeDp = 50, hasStatusStory = true)
                    Column(modifier = Modifier.weight(1f)) {
                        Text(status.authorName, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(
                            "$timeFormatted • Reste ${hoursRemaining}h",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    if (!status.mediaUrl.isNullOrBlank()) {
                        Icon(
                            Icons.Default.PhotoCamera,
                            contentDescription = "Photo",
                            tint = AdtPrimary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ChannelsTabContent(
    channels: List<ChannelEntity>,
    strings: TranslationStrings,
    onChannelClick: (ChannelEntity) -> Unit,
    onCreateChannel: () -> Unit
) {
    var selectedCategoryFilter by remember { mutableStateOf("Toutes") }
    val categories = listOf("Toutes", "Actualités", "Télécoms", "Emploi", "Business")

    val adminChannels = channels.filter { it.isOwner || it.adminName.contains("Créateur") }
    val otherChannels = channels.filter { !it.isOwner && !it.adminName.contains("Créateur") }

    val filteredChannels = channels.filter { chan ->
        if (selectedCategoryFilter == "Toutes") true
        else chan.category.contains(selectedCategoryFilter, ignoreCase = true) || chan.name.contains(selectedCategoryFilter, ignoreCase = true)
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp, bottom = 80.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Broadcast Intro Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = AdtPrimary.copy(alpha = 0.08f)),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(Icons.Default.Campaign, contentDescription = null, tint = AdtPrimary, modifier = Modifier.size(32.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Chaînes de diffusion unidirectionnelle", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text(
                            "Recevez des actualités vérifiées ou créez votre propre chaîne pour diffuser auprès de milliers d'abonnés.",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        // Header & Create Button
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Explorer les chaînes", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Button(
                    onClick = onCreateChannel,
                    colors = ButtonDefaults.buttonColors(containerColor = AdtPrimary),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Créer une chaîne", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Filter chips
        item {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(categories) { cat ->
                    FilterChip(
                        selected = selectedCategoryFilter == cat,
                        onClick = { selectedCategoryFilter = cat },
                        label = { Text(cat, fontSize = 11.sp) }
                    )
                }
            }
        }

        // Admin-owned channels section (if any)
        if (adminChannels.isNotEmpty() && selectedCategoryFilter == "Toutes") {
            item {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.padding(top = 6.dp)
                ) {
                    Icon(Icons.Default.AdminPanelSettings, contentDescription = null, tint = AdtPrimary, modifier = Modifier.size(16.dp))
                    Text("Vos chaînes d'administration", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = AdtPrimary)
                }
            }
            items(adminChannels) { channel ->
                ChannelItemRow(channel = channel, strings = strings, onChannelClick = onChannelClick)
            }
            item {
                Text("Toutes les chaînes certifiées", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 8.dp))
            }
            items(otherChannels) { channel ->
                ChannelItemRow(channel = channel, strings = strings, onChannelClick = onChannelClick)
            }
        } else {
            items(filteredChannels) { channel ->
                ChannelItemRow(channel = channel, strings = strings, onChannelClick = onChannelClick)
            }
        }
    }
}

@Composable
private fun ChannelItemRow(
    channel: ChannelEntity,
    strings: TranslationStrings,
    onChannelClick: (ChannelEntity) -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (channel.isOwner) AdtPrimary.copy(alpha = 0.05f) else MaterialTheme.colorScheme.surfaceVariant
        ),
        border = if (channel.isOwner) androidx.compose.foundation.BorderStroke(1.dp, AdtPrimary.copy(alpha = 0.3f)) else null,
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onChannelClick(channel) }
            .testTag("channel_item_${channel.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    AdtAvatar(name = channel.name, sizeDp = 42)
                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(channel.name, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            if (channel.isVerified) {
                                Icon(Icons.Default.Verified, contentDescription = null, tint = AdtPrimary, modifier = Modifier.size(15.dp))
                            }
                        }
                        Text(
                            "${channel.followersCount} ${strings.subscribers} • ${channel.category}",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                if (channel.isOwner) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = AdtPrimary.copy(alpha = 0.15f),
                        modifier = Modifier.padding(start = 6.dp)
                    ) {
                        Text("👑 Admin", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = AdtPrimary, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
                    }
                } else {
                    FilledTonalButton(
                        onClick = { onChannelClick(channel) },
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = if (channel.isFollowing) MaterialTheme.colorScheme.surface else AdtPrimary,
                            contentColor = if (channel.isFollowing) MaterialTheme.colorScheme.onSurface else Color.White
                        ),
                        shape = RoundedCornerShape(18.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                    ) {
                        Text(
                            if (channel.isFollowing) strings.following else strings.followChannel,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = channel.latestPostText.ifBlank { channel.description },
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun CallsTabContent(
    calls: List<CallLogEntity>,
    strings: TranslationStrings,
    onStartCall: (name: String, phone: String, avatar: String, isVideo: Boolean) -> Unit,
    onSimulateIncomingCall: ((isVideo: Boolean) -> Unit)? = null,
    onSimulateMissedCall: ((isVideo: Boolean) -> Unit)? = null
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 80.dp)
    ) {
        // E2EE Call Security Card
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFF0F172A)
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            Icons.Default.VerifiedUser,
                            contentDescription = null,
                            tint = Color(0xFF25D366),
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = "Chiffrement de bout en bout WebRTC",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = Color.White
                        )
                    }
                    Text(
                        text = "Tous les appels audio et vidéo transitent en direct pair à pair, protégés par DTLS 1.3 et SRTP-AES-256-GCM. Aucun tiers ne peut écouter vos échanges.",
                        fontSize = 11.sp,
                        color = Color.White.copy(alpha = 0.75f),
                        lineHeight = 15.sp
                    )

                    // Quick Test incoming & missed call FCM push alerts
                    if (onSimulateIncomingCall != null || onSimulateMissedCall != null) {
                        Text(
                            text = "Simulations FCM & WebRTC :",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color.White.copy(alpha = 0.9f),
                            modifier = Modifier.padding(top = 2.dp)
                        )
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.padding(top = 2.dp)
                        ) {
                            if (onSimulateIncomingCall != null) {
                                OutlinedButton(
                                    onClick = { onSimulateIncomingCall(false) },
                                    shape = RoundedCornerShape(12.dp),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                                    modifier = Modifier.weight(1f).testTag("btn_test_audio_call")
                                ) {
                                    Icon(Icons.Default.Call, contentDescription = null, tint = CallGreen, modifier = Modifier.size(13.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Entrant audio", fontSize = 10.sp)
                                }
                                OutlinedButton(
                                    onClick = { onSimulateIncomingCall(true) },
                                    shape = RoundedCornerShape(12.dp),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                                    modifier = Modifier.weight(1f).testTag("btn_test_video_call")
                                ) {
                                    Icon(Icons.Default.Videocam, contentDescription = null, tint = AdtPrimary, modifier = Modifier.size(13.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Entrant vidéo", fontSize = 10.sp)
                                }
                            }
                        }

                        if (onSimulateMissedCall != null) {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.padding(top = 2.dp)
                            ) {
                                Button(
                                    onClick = { onSimulateMissedCall(false) },
                                    shape = RoundedCornerShape(12.dp),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444).copy(alpha = 0.85f)),
                                    modifier = Modifier.weight(1f).testTag("btn_simulate_missed_audio_push")
                                ) {
                                    Icon(Icons.Default.PhoneMissed, contentDescription = null, tint = Color.White, modifier = Modifier.size(13.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("FCM Manqué Audio", fontSize = 10.sp, color = Color.White)
                                }
                                Button(
                                    onClick = { onSimulateMissedCall(true) },
                                    shape = RoundedCornerShape(12.dp),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF8B5CF6).copy(alpha = 0.85f)),
                                    modifier = Modifier.weight(1f).testTag("btn_simulate_missed_video_push")
                                ) {
                                    Icon(Icons.Default.PhoneMissed, contentDescription = null, tint = Color.White, modifier = Modifier.size(13.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("FCM Manqué Vidéo", fontSize = 10.sp, color = Color.White)
                                }
                            }
                        }
                    }
                }
            }
        }

        item {
            Text(
                "Historique des appels récents",
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = AdtPrimary,
                modifier = Modifier.padding(start = 16.dp, top = 6.dp, bottom = 6.dp)
            )
        }

        if (calls.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            Icons.Default.PhoneCallback,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                            modifier = Modifier.size(40.dp)
                        )
                        Text(
                            "Aucun appel récent. Démarrez un appel sécurisé avec vos contacts !",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }

        items(calls) { call ->
            val timeFormatted = remember(call.timestamp) {
                SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(Date(call.timestamp))
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    AdtAvatar(name = call.contactName, sizeDp = 46)
                    Column {
                        Text(
                            text = call.contactName,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = if (call.isMissed) CallRed else MaterialTheme.colorScheme.onSurface
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                if (call.isOutgoing) Icons.AutoMirrored.Filled.CallMade else Icons.AutoMirrored.Filled.CallReceived,
                                contentDescription = null,
                                tint = if (call.isMissed) CallRed else CallGreen,
                                modifier = Modifier.size(13.dp)
                            )
                            Text(
                                "$timeFormatted • ${if (call.isVideo) strings.videoCall else strings.voiceCall} • E2EE",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    IconButton(
                        onClick = {
                            onStartCall(call.contactName, call.contactPhone, call.contactAvatar, false)
                        }
                    ) {
                        Icon(
                            Icons.Default.Call,
                            contentDescription = strings.voiceCall,
                            tint = CallGreen
                        )
                    }
                    IconButton(
                        onClick = {
                            onStartCall(call.contactName, call.contactPhone, call.contactAvatar, true)
                        }
                    ) {
                        Icon(
                            Icons.Default.Videocam,
                            contentDescription = strings.videoCall,
                            tint = AdtPrimary
                        )
                    }
                }
            }
            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f), modifier = Modifier.padding(start = 76.dp))
        }
    }
}

@Composable
fun FloatingMiniCallBanner(
    activeCall: ActiveCallState,
    onRestore: () -> Unit,
    onToggleMute: () -> Unit,
    onEndCall: () -> Unit,
    onAccept: () -> Unit
) {
    val durationText = remember(activeCall.durationSeconds) {
        val minutes = activeCall.durationSeconds / 60
        val seconds = activeCall.durationSeconds % 60
        String.format("%02d:%02d", minutes, seconds)
    }

    Surface(
        color = Color(0xFF0F172A),
        shape = RoundedCornerShape(14.dp),
        shadowElevation = 6.dp,
        border = CardDefaults.outlinedCardBorder(),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp)
            .clickable { onRestore() }
            .testTag("floating_mini_call_banner")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                AdtAvatar(name = activeCall.contactName, sizeDp = 38)
                Column {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            if (activeCall.isVideo) Icons.Default.Videocam else Icons.Default.Call,
                            contentDescription = null,
                            tint = if (activeCall.isConnected) CallGreen else Color(0xFFFFB703),
                            modifier = Modifier.size(13.dp)
                        )
                        Text(
                            text = activeCall.contactName,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = Color.White,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Text(
                        text = if (activeCall.isConnected) "🔒 E2EE en cours • $durationText" else if (activeCall.isIncoming) "📞 Appel entrant..." else "Connexion...",
                        fontSize = 11.sp,
                        color = if (activeCall.isConnected) CallGreen else Color(0xFFFFB703)
                    )
                }
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                if (activeCall.isIncoming && !activeCall.isConnected) {
                    IconButton(
                        onClick = onAccept,
                        modifier = Modifier
                            .size(36.dp)
                            .background(CallGreen, CircleShape)
                    ) {
                        Icon(Icons.Default.Call, contentDescription = "Répondre", tint = Color.White, modifier = Modifier.size(18.dp))
                    }
                } else {
                    IconButton(
                        onClick = onToggleMute,
                        modifier = Modifier
                            .size(36.dp)
                            .background(if (activeCall.isMuted) CallRed else Color.White.copy(alpha = 0.15f), CircleShape)
                    ) {
                        Icon(
                            if (activeCall.isMuted) Icons.Default.MicOff else Icons.Default.Mic,
                            contentDescription = "Micro",
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                IconButton(
                    onClick = onEndCall,
                    modifier = Modifier
                        .size(36.dp)
                        .background(CallRed, CircleShape)
                ) {
                    Icon(Icons.Default.CallEnd, contentDescription = "Raccrocher", tint = Color.White, modifier = Modifier.size(18.dp))
                }
            }
        }
    }
}
