package com.example.ui.screens.tracking

import android.content.Context
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Route
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.ShareLocation
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Streetview
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Traffic
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SmallFloatingActionButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.VerticalDivider
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.GoogleMapType
import com.example.data.model.GoogleMapsHelper
import com.example.data.model.LiveLocationSharingSession
import com.example.data.model.LocationPrecisionMode
import com.example.data.model.LocationWaypoint
import com.example.data.model.UpdateIntervalPreset
import com.example.ui.theme.AdtPrimary
import com.example.ui.theme.AdtSecondary
import com.example.viewmodel.AdtViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LiveLocationSharingScreen(
    viewModel: AdtViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val session by viewModel.liveSharingSession.collectAsState()
    val countdownSec by viewModel.periodicUpdateCountdown.collectAsState()
    val activeChats by viewModel.activeChats.collectAsState()

    var zoomLevel by remember { mutableIntStateOf(16) }
    var selectedMapType by remember { mutableStateOf(GoogleMapType.ROADMAP) }
    var showTraffic by remember { mutableStateOf(false) }
    var showWaypointsSheet by remember { mutableStateOf(false) }
    var showChatPickerSheet by remember { mutableStateOf(false) }

    val currentSession = session ?: return

    val infiniteTransition = rememberInfiniteTransition(label = "pulse_radar")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.8f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "radar_scale"
    )
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 0.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "radar_alpha"
    )

    // Compute Google Maps static map preview URL with waypoints trail
    val mapUrl = remember(
        currentSession.currentLatitude,
        currentSession.currentLongitude,
        currentSession.waypoints.size,
        zoomLevel,
        selectedMapType,
        showTraffic
    ) {
        GoogleMapsHelper.buildStaticMapUrl(
            latitude = currentSession.currentLatitude,
            longitude = currentSession.currentLongitude,
            zoom = zoomLevel,
            width = 650,
            height = 500,
            mapType = selectedMapType.apiName,
            waypoints = currentSession.waypoints,
            showTraffic = showTraffic
        )
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .testTag("screen_live_location_sharing"),
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = "Partage en direct",
                                fontWeight = FontWeight.Bold,
                                fontSize = 17.sp
                            )
                            if (currentSession.isSharingActive && !currentSession.isExpired()) {
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = Color(0xFF2E7D32),
                                    modifier = Modifier.testTag("badge_live_active")
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(6.dp)
                                                .background(Color.White, CircleShape)
                                        )
                                        Text(
                                            text = if (currentSession.isPaused) "EN PAUSE" else "EN DIRECT",
                                            color = Color.White,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                        Text(
                            text = if (currentSession.isSharingActive) {
                                "Mise à jour périodique (${currentSession.updateIntervalSeconds}s) • ${currentSession.remainingTimeFormatted()}"
                            } else {
                                "Prêt à partager vos coordonnées avec Google Maps API"
                            },
                            fontSize = 11.5.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = { viewModel.closeLiveLocationSharingScreen() },
                        modifier = Modifier.testTag("btn_back_live_sharing")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Retour"
                        )
                    }
                },
                actions = {
                    // Manual update trigger
                    IconButton(
                        onClick = { viewModel.forcePeriodicLocationUpdate() },
                        modifier = Modifier.testTag("btn_force_location_refresh")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Actualiser maintenant",
                            tint = AdtPrimary
                        )
                    }
                    // Open in Google Maps app
                    IconButton(
                        onClick = {
                            GoogleMapsHelper.openInGoogleMapsApp(
                                context,
                                currentSession.currentLatitude,
                                currentSession.currentLongitude,
                                label = "Ma position en direct"
                            )
                        },
                        modifier = Modifier.testTag("btn_open_in_google_maps")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Explore,
                            contentDescription = "Ouvrir dans Google Maps",
                            tint = Color(0xFF1976D2)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // MAP VIEW CONTAINER (Upper half)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1.05f)
                    .background(Color(0xFFE0E0E0))
            ) {
                // Static Google Maps Image
                AsyncImage(
                    model = mapUrl,
                    contentDescription = "Google Maps Vue en direct",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )

                // Animated Radar Wave & Marker at Center
                Box(
                    modifier = Modifier.align(Alignment.Center),
                    contentAlignment = Alignment.Center
                ) {
                    if (currentSession.isSharingActive && !currentSession.isPaused) {
                        Box(
                            modifier = Modifier
                                .size(56.dp)
                                .scale(pulseScale)
                                .background(AdtPrimary.copy(alpha = pulseAlpha), CircleShape)
                        )
                    }
                    Surface(
                        shape = CircleShape,
                        color = AdtPrimary,
                        border = BorderStroke(2.5.dp, Color.White),
                        shadowElevation = 6.dp,
                        modifier = Modifier.size(38.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.MyLocation,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }

                // TOP FLOATING OVERLAY: Map Type Selector & Traffic Toggle
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.94f)
                    ),
                    elevation = CardDefaults.cardElevation(4.dp),
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = 10.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        GoogleMapType.values().forEach { type ->
                            val isSelected = selectedMapType == type
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = if (isSelected) AdtPrimary else Color.Transparent,
                                modifier = Modifier.clickable { selectedMapType = type }
                            ) {
                                Text(
                                    text = type.label,
                                    color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                        VerticalDivider(modifier = Modifier.height(18.dp))
                        IconButton(
                            onClick = { showTraffic = !showTraffic },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                Icons.Default.Traffic,
                                contentDescription = "Trafic",
                                tint = if (showTraffic) Color(0xFFE53935) else Color.Gray,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }

                // RIGHT FLOATING MAP CONTROLS
                Column(
                    modifier = Modifier
                        .align(Alignment.CenterEnd)
                        .padding(end = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    SmallFloatingActionButton(
                        onClick = { zoomLevel = (zoomLevel + 1).coerceAtMost(20) },
                        containerColor = MaterialTheme.colorScheme.surface,
                        modifier = Modifier.testTag("btn_map_zoom_in")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Zoom +")
                    }
                    SmallFloatingActionButton(
                        onClick = { zoomLevel = (zoomLevel - 1).coerceAtLeast(10) },
                        containerColor = MaterialTheme.colorScheme.surface,
                        modifier = Modifier.testTag("btn_map_zoom_out")
                    ) {
                        Icon(Icons.Default.Remove, contentDescription = "Zoom -")
                    }
                    SmallFloatingActionButton(
                        onClick = { zoomLevel = 16 },
                        containerColor = MaterialTheme.colorScheme.surface,
                        modifier = Modifier.testTag("btn_map_recenter")
                    ) {
                        Icon(Icons.Default.MyLocation, contentDescription = "Centrer", tint = AdtPrimary)
                    }
                    SmallFloatingActionButton(
                        onClick = {
                            GoogleMapsHelper.openStreetViewInGoogleMaps(
                                context,
                                currentSession.currentLatitude,
                                currentSession.currentLongitude
                            )
                        },
                        containerColor = MaterialTheme.colorScheme.surface,
                        modifier = Modifier.testTag("btn_map_streetview")
                    ) {
                        Icon(Icons.Default.Streetview, contentDescription = "Street View", tint = Color(0xFFF57C00))
                    }
                }

                // BOTTOM LEFT BADGE: Current Address pill
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.94f),
                    shadowElevation = 3.dp,
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(start = 12.dp, bottom = 10.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            Icons.Default.GpsFixed,
                            contentDescription = null,
                            tint = AdtPrimary,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = currentSession.currentAddress,
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Medium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            // CONTROLS & TELEMETRY SCROLLABLE DASHBOARD (Lower half)
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1.3f)
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // REAL-TIME PERIODIC UPDATE TICKER BAR
                item {
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (currentSession.isSharingActive) {
                                AdtPrimary.copy(alpha = 0.08f)
                            } else {
                                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                            }
                        ),
                        border = BorderStroke(
                            1.dp,
                            if (currentSession.isSharingActive) AdtPrimary.copy(alpha = 0.3f)
                            else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("card_periodic_update_status")
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                if (currentSession.isSharingActive && !currentSession.isPaused) {
                                    Box(contentAlignment = Alignment.Center) {
                                        val totalSec = currentSession.updateIntervalSeconds.coerceAtLeast(1).toFloat()
                                        val progress = (countdownSec.toFloat() / totalSec).coerceIn(0f, 1f)
                                        CircularProgressIndicator(
                                            progress = { progress },
                                            modifier = Modifier.size(34.dp),
                                            color = AdtPrimary,
                                            strokeWidth = 3.dp,
                                            trackColor = MaterialTheme.colorScheme.surfaceVariant
                                        )
                                        Text(
                                            text = "${countdownSec}s",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = AdtPrimary
                                        )
                                    }
                                } else {
                                    Icon(
                                        Icons.Default.Timer,
                                        contentDescription = null,
                                        tint = Color.Gray,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }

                                Column {
                                    Text(
                                        text = if (currentSession.isSharingActive) {
                                            if (currentSession.isPaused) "Transmission en pause"
                                            else "Prochaine mise à jour dans ${countdownSec}s"
                                        } else {
                                            "Mise à jour périodique configurée (${currentSession.updateIntervalSeconds}s)"
                                        },
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                    Text(
                                        text = "Google Maps API • ${currentSession.updateCount} coordonnées synchronisées",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            FilledTonalButton(
                                onClick = { viewModel.forcePeriodicLocationUpdate() },
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.testTag("btn_sync_now")
                            ) {
                                Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Sync", fontSize = 11.5.sp)
                            }
                        }
                    }
                }

                // TELEMETRY METRICS GRID (Speed, Bearing, Accuracy, Battery)
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        SharingTelemetryBadge(
                            modifier = Modifier.weight(1f),
                            icon = Icons.Default.Speed,
                            label = "Vitesse",
                            value = "%.0f km/h".format(currentSession.currentSpeedKmh),
                            color = AdtPrimary
                        )
                        SharingTelemetryBadge(
                            modifier = Modifier.weight(1f),
                            icon = Icons.Default.Explore,
                            label = "Cap / Direction",
                            value = "${currentSession.currentBearing.toInt()}°",
                            subValue = currentSession.cardinalDirection().substringBefore(" "),
                            color = Color(0xFF0288D1)
                        )
                        SharingTelemetryBadge(
                            modifier = Modifier.weight(1f),
                            icon = Icons.Default.GpsFixed,
                            label = "Précision GPS",
                            value = "±%.1fm".format(currentSession.accuracyMeters),
                            color = Color(0xFF7B1FA2)
                        )
                        SharingTelemetryBadge(
                            modifier = Modifier.weight(1f),
                            icon = Icons.Default.BatteryChargingFull,
                            label = "Batterie",
                            value = "${currentSession.batteryPercent}%",
                            color = Color(0xFF388E3C)
                        )
                    }
                }

                // EXACT COORDINATES ROW
                item {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(
                                    text = "Coordonnées géographiques précises",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = "%.6f° N, %.6f° O".format(currentSession.currentLatitude, currentSession.currentLongitude),
                                    fontSize = 12.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                            FilledTonalButton(
                                onClick = { showWaypointsSheet = true },
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Icon(Icons.Default.Route, contentDescription = null, modifier = Modifier.size(13.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Trajet (${currentSession.waypoints.size})", fontSize = 11.sp)
                            }
                        }
                    }
                }

                // RECIPIENT CHAT SELECTOR
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = "Partager avec",
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 12.5.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surface,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { showChatPickerSheet = true }
                                .testTag("btn_select_target_chat")
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Icon(
                                        Icons.Default.ShareLocation,
                                        contentDescription = null,
                                        tint = AdtPrimary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Column {
                                        Text(
                                            text = currentSession.chatTitle.ifBlank { "Sélectionner une discussion" },
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.5.sp
                                        )
                                        Text(
                                            text = "Transmission chiffrée E2EE vers ce contact",
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                                Text("Modifier", color = AdtPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }

                // PERIODIC INTERVAL SELECTION CHIPS (5s, 10s, 30s, 60s)
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = "Fréquence de mise à jour périodique",
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 12.5.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            UpdateIntervalPreset.values().forEach { preset ->
                                val isSelected = currentSession.updateIntervalSeconds == preset.seconds
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = if (isSelected) AdtPrimary else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                    border = BorderStroke(
                                        1.dp,
                                        if (isSelected) AdtPrimary else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f)
                                    ),
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable { viewModel.setSharingUpdateInterval(preset.seconds) }
                                        .testTag("chip_interval_${preset.seconds}s")
                                ) {
                                    Column(
                                        modifier = Modifier.padding(vertical = 8.dp, horizontal = 4.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Text(
                                            text = preset.label,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp,
                                            color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
                                        )
                                        Text(
                                            text = preset.badge,
                                            fontSize = 9.sp,
                                            color = if (isSelected) Color.White.copy(alpha = 0.9f) else MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // DURATION SELECTION CHIPS (15 min, 1h, 8h)
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = "Durée du partage en direct",
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 12.5.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf(
                                15 to "15 minutes",
                                60 to "1 heure",
                                480 to "8 heures"
                            ).forEach { (min, label) ->
                                val isSelected = currentSession.durationMinutes == min
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = if (isSelected) AdtPrimary else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                    border = BorderStroke(
                                        1.dp,
                                        if (isSelected) AdtPrimary else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f)
                                    ),
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable { viewModel.setSharingDuration(min) }
                                        .testTag("chip_duration_${min}m")
                                ) {
                                    Box(
                                        modifier = Modifier.padding(vertical = 8.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = label,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                            fontSize = 11.5.sp,
                                            color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // OPTIONAL COMMENT / STATUS NOTE
                item {
                    OutlinedTextField(
                        value = currentSession.comment,
                        onValueChange = { viewModel.setSharingComment(it) },
                        label = { Text("Note ou statut (optionnel)") },
                        placeholder = { Text("Ex: En route pour la réunion...") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_location_comment"),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )
                }

                // MAIN ACTION BUTTONS (Start, Pause, Stop, Itinéraire Google Maps)
                item {
                    Spacer(modifier = Modifier.height(4.dp))
                    if (!currentSession.isSharingActive || currentSession.isExpired()) {
                        Button(
                            onClick = { viewModel.startLiveSharingBroadcast() },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("btn_start_live_sharing"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = AdtPrimary)
                        ) {
                            Icon(Icons.Default.ShareLocation, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Démarrer le partage en direct",
                                fontSize = 14.5.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    } else {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // Pause / Resume button
                            OutlinedButton(
                                onClick = { viewModel.pauseOrResumeLiveSharingBroadcast() },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("btn_pause_live_sharing"),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(
                                    imageVector = if (currentSession.isPaused) Icons.Default.PlayArrow else Icons.Default.Pause,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (currentSession.isPaused) "Reprendre" else "Pause",
                                    fontSize = 13.sp
                                )
                            }

                            // Stop sharing button
                            Button(
                                onClick = { viewModel.stopLiveSharingBroadcast() },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("btn_stop_live_sharing"),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                            ) {
                                Icon(Icons.Default.Stop, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Arrêter",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    // Native Navigation Button
                    Spacer(modifier = Modifier.height(4.dp))
                    OutlinedButton(
                        onClick = {
                            GoogleMapsHelper.openNavigationInGoogleMaps(
                                context,
                                currentSession.currentLatitude,
                                currentSession.currentLongitude,
                                mode = "d"
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(46.dp)
                            .testTag("btn_open_google_navigation"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Navigation, contentDescription = null, tint = AdtPrimary, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Itinéraire dans Google Maps", fontSize = 13.sp, color = AdtPrimary)
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                }
            }
        }
    }

    // MODAL BOTTOM SHEET: Chat Picker
    if (showChatPickerSheet) {
        ModalBottomSheet(
            onDismissRequest = { showChatPickerSheet = false },
            containerColor = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Choisir le destinataire du partage",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(280.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(activeChats) { chat ->
                        val isSelected = currentSession.chatId == chat.id
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (isSelected) AdtPrimary.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                            border = BorderStroke(
                                1.dp,
                                if (isSelected) AdtPrimary else Color.Transparent
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.setSharingTargetChat(chat.id)
                                    showChatPickerSheet = false
                                }
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(chat.title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text(
                                        if (chat.isGroup) "Groupe de discussion" else "Contact direct",
                                        fontSize = 11.5.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                if (isSelected) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = AdtPrimary)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // MODAL BOTTOM SHEET: Recorded Waypoints History
    if (showWaypointsSheet) {
        ModalBottomSheet(
            onDismissRequest = { showWaypointsSheet = false },
            containerColor = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "Historique du trajet (${currentSession.waypoints.size} points)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                    IconButton(onClick = { showWaypointsSheet = false }) {
                        Icon(Icons.Default.Close, contentDescription = "Fermer")
                    }
                }

                if (currentSession.waypoints.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "Aucun point de passage enregistré pour le moment.\nLes étapes s'afficheront ici lors des mises à jour périodiques.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                } else {
                    val timeFormat = remember { SimpleDateFormat("HH:mm:ss", Locale.getDefault()) }
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(280.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(currentSession.waypoints.reversed()) { waypoint ->
                            Card(
                                shape = RoundedCornerShape(8.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(waypoint.address, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                                        Text(
                                            "Lat: %.5f, Lng: %.5f".format(waypoint.latitude, waypoint.longitude),
                                            fontSize = 10.5.sp,
                                            fontFamily = FontFamily.Monospace,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text(timeFormat.format(Date(waypoint.timestamp)), fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
                                        Text("%.0f km/h • ${waypoint.bearing.toInt()}°".format(waypoint.speedKmh), fontSize = 10.sp, color = AdtPrimary)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SharingTelemetryBadge(
    icon: ImageVector,
    label: String,
    value: String,
    color: Color,
    modifier: Modifier = Modifier,
    subValue: String? = null
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(16.dp))
            Text(text = label, fontSize = 9.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
            Text(text = value, fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = color)
            if (!subValue.isNullOrBlank()) {
                Text(text = subValue, fontSize = 8.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
