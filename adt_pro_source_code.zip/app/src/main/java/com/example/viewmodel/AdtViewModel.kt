package com.example.viewmodel

import android.app.Activity
import android.app.Application
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.auth.CredentialAuthManager
import com.example.data.auth.FirebasePhoneAuthManager
import com.example.data.auth.PhoneAuthState
import com.example.data.model.SyncEnergyMode
import com.example.data.datastore.PrivacyPreferences
import com.example.data.datastore.PrivacyPreferencesDataStore
import com.example.data.local.AppDatabase
import com.example.data.local.entity.AppSettingsEntity
import com.example.data.local.entity.CallLogEntity
import com.example.data.local.entity.ChannelEntity
import com.example.data.local.entity.ChatEntity
import com.example.data.local.entity.ContactEntity
import com.example.data.local.entity.GroupMemberEntity
import com.example.data.local.entity.MessageEntity
import com.example.data.local.entity.StatusEntity
import com.example.data.local.entity.UserEntity
import com.example.data.model.CountryData
import com.example.data.model.CountryItem
import com.example.data.model.GoogleMapsHelper
import com.example.data.model.LiveLocationPayload
import com.example.data.model.LocationWaypoint
import com.example.data.model.SampleLocationPoint
import com.example.data.model.SampleLocations
import com.example.data.model.LiveLocationSharingSession
import com.example.data.model.LocationPrecisionMode
import com.example.data.model.UpdateIntervalPreset
import com.example.data.location.LiveLocationPeriodicEngine
import com.example.data.repository.AdtRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlin.random.Random
import com.example.ui.theme.AdtPaletteColor

import com.example.data.firebase.FirebaseBackupManager
import com.example.data.firebase.BackupOperationState
import com.example.data.firebase.FirebaseInitHelper
import com.example.data.firebase.BackupMetadata
import com.example.data.firebase.BackgroundBackupStatus
import com.example.data.firebase.FirebaseAiQuickReplyService
import com.example.data.audio.TextToSpeechManager
import com.example.data.service.ChatBackupBackgroundService
import com.example.data.service.ChatBackupScheduler
import com.example.data.crypto.DatabaseSecurityStatus
import com.example.data.webrtc.CallManager
import com.example.data.webrtc.CallParticipant
import com.example.data.webrtc.CallQualityStats
import com.example.data.webrtc.E2eeSecurityInfo
import com.example.data.webrtc.WebRtcCallSession
import com.example.data.webrtc.WebRtcConnectionState
import com.example.data.webrtc.WebRtcSignalingMessage
import com.example.data.firebase.FirestoreSyncManager
import com.example.data.firebase.FirestoreSyncStatus
import com.example.data.live.*
import com.example.data.security.TwoStepVerificationManager
import com.example.data.security.TwoStepVerificationState
import com.example.data.security.RecoveryAccountType
import com.example.data.security.PinVerificationResult
import com.example.data.firebase.FirebaseDocumentManager
import com.example.data.model.SecureDocument
import com.example.data.model.DocumentScanStatus
import com.example.data.crypto.ChatEncryptionFingerprint
import com.example.data.storage.StorageManager
import com.example.data.model.StorageBreakdownOverview
import com.example.data.model.ChatStorageConsumption
import com.example.data.model.StorageMediaItem
import com.example.data.model.formatBytes
import com.example.data.search.ArchivedSearchOptions
import com.example.data.search.ArchivedSearchResult
import com.example.data.search.ArchivedSearchStats
import android.content.Context
import kotlinx.coroutines.flow.first

enum class AppScreen {
    AUTH_PHONE,
    AUTH_OTP,
    AUTH_PROFILE,
    MAIN_TABS,
    CHAT_ROOM,
    GROUP_INFO,
    CHANNEL_ROOM,
    ACTIVE_CALL,
    STATUS_VIEWER,
    CREATE_GROUP,
    CREATE_CHANNEL,
    CREATE_STATUS,
    CONTACTS_LIST,
    SETTINGS,
    PRIVACY_SETTINGS,
    CAMERA_STUDIO,
    WALLPAPER_PICKER,
    TIKTOK_LIVE,
    SYNC_CONTACTS,
    CONTACT_QR_CODE,
    LIVE_TRACKING,
    CHAT_BACKUP,
    TWO_STEP_VERIFICATION,
    ENCRYPTION_KEYS,
    ARCHIVED_CHATS,
    LIVE_LOCATION_SHARING,
    LOCKED_CHATS,
    STORAGE_MANAGEMENT
}

data class LiveTrackingState(
    val messageId: String = "",
    val chatId: String = "",
    val contactName: String = "Contact",
    val contactPhone: String = "",
    val contactAvatar: String = "",
    val payload: LiveLocationPayload,
    val isSimulating: Boolean = true,
    val simulationSpeedMultiplier: Int = 1
)

data class ActiveCallState(
    val callId: String = "",
    val contactName: String,
    val contactPhone: String,
    val contactAvatar: String,
    val isVideo: Boolean,
    val isIncoming: Boolean = false,
    val isMuted: Boolean = false,
    val isVideoOff: Boolean = false,
    val isFrontCamera: Boolean = true,
    val isLocalPreviewMain: Boolean = false,
    val isSpeakerOn: Boolean = true,
    val durationSeconds: Int = 0,
    val isConnected: Boolean = false,
    val connectionState: WebRtcConnectionState = WebRtcConnectionState.IDLE,
    val quality: CallQualityStats = CallQualityStats(),
    val e2eeInfo: E2eeSecurityInfo = E2eeSecurityInfo(),
    val audioWaveLevels: List<Float> = listOf(0.3f, 0.6f, 0.8f, 0.4f, 0.7f, 0.5f, 0.2f),
    val isGroupCall: Boolean = false,
    val roomId: String? = null,
    val participants: List<CallParticipant> = emptyList()
)

class AdtViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: AdtRepository

    val currentUser: StateFlow<UserEntity?>
    val activeChats: StateFlow<List<ChatEntity>>
    val lockedChats: StateFlow<List<ChatEntity>>
    val lockedChatsCount: StateFlow<Int>
    val archivedChats: StateFlow<List<ChatEntity>>
    val archivedChatsCount: StateFlow<Int>
    val allContacts: StateFlow<List<ContactEntity>>
    val allStatuses: StateFlow<List<StatusEntity>>
    val allChannels: StateFlow<List<ChannelEntity>>
    val allCalls: StateFlow<List<CallLogEntity>>
    val appSettings: StateFlow<AppSettingsEntity?>

    private val _archivedSearchQuery = MutableStateFlow("")
    val archivedSearchQuery: StateFlow<String> = _archivedSearchQuery.asStateFlow()

    private val _archivedSearchResults = MutableStateFlow<List<ArchivedSearchResult>>(emptyList())
    val archivedSearchResults: StateFlow<List<ArchivedSearchResult>> = _archivedSearchResults.asStateFlow()

    private val _archivedSearchStats = MutableStateFlow<ArchivedSearchStats?>(null)
    val archivedSearchStats: StateFlow<ArchivedSearchStats?> = _archivedSearchStats.asStateFlow()

    private val _archivedSearchOptions = MutableStateFlow(ArchivedSearchOptions())
    val archivedSearchOptions: StateFlow<ArchivedSearchOptions> = _archivedSearchOptions.asStateFlow()

    private val _isArchivedSearchLoading = MutableStateFlow(false)
    val isArchivedSearchLoading: StateFlow<Boolean> = _isArchivedSearchLoading.asStateFlow()

    // Privacy Preferences stored in DataStore
    private val privacyPreferencesDataStore = PrivacyPreferencesDataStore(application)
    val privacyPreferences: StateFlow<PrivacyPreferences> = privacyPreferencesDataStore.privacyPreferencesFlow.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), PrivacyPreferences()
    )

    private val _currentScreen = MutableStateFlow(AppScreen.MAIN_TABS)
    val currentScreen: StateFlow<AppScreen> = _currentScreen.asStateFlow()

    // Navigation sub-state
    private val _activeChatId = MutableStateFlow<String?>(null)
    val activeChatId: StateFlow<String?> = _activeChatId.asStateFlow()

    private val _activeChannelId = MutableStateFlow<String?>(null)
    val activeChannelId: StateFlow<String?> = _activeChannelId.asStateFlow()

    private val _activeCall = MutableStateFlow<ActiveCallState?>(null)
    val activeCall: StateFlow<ActiveCallState?> = _activeCall.asStateFlow()

    private val _activeStatus = MutableStateFlow<StatusEntity?>(null)
    val activeStatus: StateFlow<StatusEntity?> = _activeStatus.asStateFlow()

    private val _forwardingMessage = MutableStateFlow<MessageEntity?>(null)
    val forwardingMessage: StateFlow<MessageEntity?> = _forwardingMessage.asStateFlow()

    private val _cameraSourceChatId = MutableStateFlow<String?>(null)
    val cameraSourceChatId: StateFlow<String?> = _cameraSourceChatId.asStateFlow()

    private val _cameraForStatus = MutableStateFlow(false)
    val cameraForStatus: StateFlow<Boolean> = _cameraForStatus.asStateFlow()

    // Main Chat Search & Message Content Matching
    val chatSearchQuery = MutableStateFlow("")
    val matchingChatIdsFromMessages = MutableStateFlow<Set<String>>(emptySet())
    val matchingMessages = MutableStateFlow<List<MessageEntity>>(emptyList())

    // Live Location Sharing State
    val showShareLocationDialog = MutableStateFlow(false)
    val locationShareFromChatId = MutableStateFlow<String?>(null)

    private val database = AppDatabase.getDatabase(application)

    // Auth temporary state & Firebase Phone Authentication
    val firebasePhoneAuthManager = FirebasePhoneAuthManager(application, viewModelScope)
    val phoneAuthState: StateFlow<PhoneAuthState> = firebasePhoneAuthManager.authState

    // Android Credential Manager for secure phone credential store & fast 1-tap sign-in
    val credentialAuthManager = CredentialAuthManager(application)
    val isCredentialLoading = MutableStateFlow(false)
    val credentialManagerMessage = MutableStateFlow<String?>(null)
    val detectedCredential = MutableStateFlow<com.example.data.auth.StoredCredential?>(null)
    private var currentAuthActivity: Activity? = null

    // WebRTC Audio/Video Call Manager
    val callManager = CallManager(application, viewModelScope)

    // Firestore Sync Manager for Real-time Cloud Sync
    val firestoreSyncManager = FirestoreSyncManager(application, database, viewModelScope)
    val firestoreSyncStatus: StateFlow<FirestoreSyncStatus> = firestoreSyncManager.syncStatus

    // Background Synchronization Energy Management (High Performance vs Battery Saver)
    private val syncEnergyPrefs = application.getSharedPreferences("adt_sync_energy_prefs", android.content.Context.MODE_PRIVATE)
    val syncEnergyMode = MutableStateFlow(
        SyncEnergyMode.fromId(syncEnergyPrefs.getString("sync_energy_mode", SyncEnergyMode.HIGH_PERFORMANCE.id))
    )
    val isManualSyncing = MutableStateFlow(false)
    val lastManualSyncTimestamp = MutableStateFlow(
        syncEnergyPrefs.getLong("last_manual_sync_timestamp", System.currentTimeMillis())
    )
    val autoBatterySaverOnLowBattery = MutableStateFlow(
        syncEnergyPrefs.getBoolean("auto_battery_saver_on_low_battery", true)
    )
    val deviceBatteryLevel = MutableStateFlow(100)
    val isDeviceCharging = MutableStateFlow(false)
    val syncIntervalMinutes = MutableStateFlow(
        syncEnergyPrefs.getInt("sync_interval_minutes", 15)
    )
    val nextPollingTimestamp: StateFlow<Long> = firestoreSyncManager.nextPollingTimestamp
    val isPollingActive: StateFlow<Boolean> = firestoreSyncManager.isPollingActive

    // Home Screen Accent & Visual Theme Color (Rouge, Bleu, Blanche, Noir, Violet, Vert, Rose)
    private val homeColorPrefs = application.getSharedPreferences("adt_home_color_prefs", Context.MODE_PRIVATE)
    val homeColorTheme = MutableStateFlow(
        AdtPaletteColor.fromId(homeColorPrefs.getString("home_color_theme", "VERT"))
    )

    fun setHomeColorTheme(color: AdtPaletteColor) {
        homeColorTheme.value = color
        homeColorPrefs.edit().putString("home_color_theme", color.id).apply()
        updateWallpaper(color.wallpaperThemeId)
    }

    // TikTok Live Streaming & Direct Autorisé Manager
    private val liveStreamManager = LiveStreamManager(viewModelScope)
    val activeLiveSession: StateFlow<LiveStreamSessionState?> = liveStreamManager.activeSession
    val availableLiveStreams: StateFlow<List<LiveStreamItem>> = liveStreamManager.availableStreams
    val liveCreatorAuthorization: StateFlow<LiveCreatorAuthorization> = liveStreamManager.creatorAuthorization

    // Firebase Cloud Storage Chat Backup & Restore Manager
    val backupManager = FirebaseBackupManager(application, database, viewModelScope)
    val backupOperationState: StateFlow<BackupOperationState> = backupManager.operationState
    val latestBackupInfo: StateFlow<BackupMetadata?> = backupManager.latestBackupInfo
    val backgroundBackupStatus: StateFlow<BackgroundBackupStatus> = FirebaseBackupManager.backgroundStatus

    // Firebase Cloud Storage Secure Document Sharing & Server-side Scanning
    val firebaseDocumentManager = FirebaseDocumentManager(application)
    val showDocumentPicker = MutableStateFlow(false)
    val isDocumentUploading = MutableStateFlow(false)
    val documentUploadProgress = MutableStateFlow(0f)
    val documentUploadStatusMessage = MutableStateFlow("")
    val previewingDocument = MutableStateFlow<SecureDocument?>(null)
    val inspectingSecurityReportDocument = MutableStateFlow<SecureDocument?>(null)

    // Storage Management (Media consumption analysis, large attachments deletion, cache clearing)
    val storageManager = StorageManager(application, database)
    val storageOverview = MutableStateFlow(StorageBreakdownOverview())
    val isStorageLoading = MutableStateFlow(false)
    val storageActionFeedback = MutableStateFlow<String?>(null)
    val selectedChatForStorage = MutableStateFlow<ChatStorageConsumption?>(null)

    // Firebase AI Contextual Quick Replies State & User Preferences
    private val aiPrefs = application.getSharedPreferences("adt_ai_settings_prefs", Context.MODE_PRIVATE)
    val quickReplies = MutableStateFlow<List<String>>(emptyList())
    val isGeneratingQuickReplies = MutableStateFlow(false)
    val quickRepliesSourceMessageId = MutableStateFlow<String?>(null)
    val quickRepliesEnabled = MutableStateFlow(aiPrefs.getBoolean("quick_replies_enabled", true))
    val quickRepliesTone = MutableStateFlow(aiPrefs.getString("quick_replies_tone", "FRIENDLY") ?: "FRIENDLY")
    private var quickReplyGenerationJob: Job? = null

    // Text-to-Speech (TTS) Manager for long messages and accessibility
    private val ttsPrefs = application.getSharedPreferences("adt_tts_prefs", Context.MODE_PRIVATE)
    val textToSpeechManager = TextToSpeechManager(application, viewModelScope).apply {
        val savedRate = ttsPrefs.getFloat("tts_speech_rate", 1.0f)
        val savedEnabled = ttsPrefs.getBoolean("tts_long_messages_enabled", true)
        setSpeechRate(savedRate)
        setTtsFeatureEnabled(savedEnabled)
    }
    val isTtsPlaying: StateFlow<Boolean> = textToSpeechManager.isPlaying
    val currentTtsMessageId: StateFlow<String?> = textToSpeechManager.currentMessageId
    val ttsSpeechRate: StateFlow<Float> = textToSpeechManager.speechRate
    val ttsEnabledForLongMessages = MutableStateFlow(ttsPrefs.getBoolean("tts_long_messages_enabled", true))

    fun speakMessage(messageId: String, text: String) {
        val lang = appSettings.value?.language ?: "FR"
        textToSpeechManager.speak(messageId, text, lang)
    }

    fun stopTts() {
        textToSpeechManager.stop()
    }

    fun cycleTtsSpeechRate() {
        val newRate = textToSpeechManager.cycleSpeechRate()
        ttsPrefs.edit().putFloat("tts_speech_rate", newRate).apply()
    }

    fun setTtsSpeechRate(rate: Float) {
        textToSpeechManager.setSpeechRate(rate)
        ttsPrefs.edit().putFloat("tts_speech_rate", rate).apply()
    }

    fun toggleTtsForLongMessages(enabled: Boolean) {
        ttsEnabledForLongMessages.value = enabled
        textToSpeechManager.setTtsFeatureEnabled(enabled)
        ttsPrefs.edit().putBoolean("tts_long_messages_enabled", enabled).apply()
    }

    fun isLongTextMessage(text: String, mediaType: String? = null): Boolean {
        if (!ttsEnabledForLongMessages.value) return false
        return textToSpeechManager.isLongMessage(text, mediaType)
    }

    // Local Room Database AES-256 Encryption Security Status
    val databaseSecurityStatus: StateFlow<DatabaseSecurityStatus> get() = repository.databaseSecurityStatus

    // Two-Step Verification (Code PIN 6 chiffres & Compte Google / iCloud)
    private val twoStepVerificationManager = TwoStepVerificationManager(application)
    val twoStepVerificationState: StateFlow<TwoStepVerificationState> = twoStepVerificationManager.verificationStateFlow.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), TwoStepVerificationState()
    )
    val isAppLockedByTwoStep = MutableStateFlow(false)
    val twoStepRecoveryNotification = MutableStateFlow<String?>(null)

    // Biometric Authentication State (Fingerprint / Face Unlock via AndroidX Biometric)
    val isAppLockedByBiometric = MutableStateFlow(false)
    val biometricAuthErrorMessage = MutableStateFlow<String?>(null)
    private var lastBackgroundTimestamp: Long = 0L

    // E2EE Fingerprint Verification State (Persistent)
    private val e2eeVerificationPrefs = application.getSharedPreferences("adt_e2ee_fingerprints_prefs", Context.MODE_PRIVATE)
    private val _verifiedChatFingerprints = MutableStateFlow<Set<String>>(emptySet())
    val verifiedChatFingerprints: StateFlow<Set<String>> = _verifiedChatFingerprints.asStateFlow()

    fun refreshDatabaseSecurityAudit() {
        viewModelScope.launch {
            repository.auditDatabaseSecurity()
        }
    }

    fun forceEncryptLocalDatabase() {
        viewModelScope.launch {
            repository.forceEncryptLocalDatabase()
            repository.auditDatabaseSecurity()
        }
    }

    val dataEnrichmentStatus = MutableStateFlow<String?>(null)

    fun seedEnrichedData(onDone: () -> Unit = {}) {
        viewModelScope.launch {
            dataEnrichmentStatus.value = "Chargement des données..."
            repository.enrichAndSeedAllData(force = true)
            dataEnrichmentStatus.value = "Données enrichies avec succès !"
            onDone()
        }
    }

    val isLoginMode = MutableStateFlow(false)
    val selectedCountry = MutableStateFlow(CountryData.supportedCountries.first())
    val enteredDialCode = MutableStateFlow(CountryData.supportedCountries.first().dialCode.removePrefix("+"))
    val enteredPhoneNumber = MutableStateFlow("")
    val selectedOperator = MutableStateFlow("Orange")
    val generatedOtpCode = MutableStateFlow("749218")
    val enteredOtpCode = MutableStateFlow("")
    val otpBannerMessage = MutableStateFlow<String?>(null)
    val resendCountdownSeconds = MutableStateFlow(0)
    val authErrorMessage = MutableStateFlow<String?>(null)

    val profileFirstName = MutableStateFlow("")
    val profileLastName = MutableStateFlow("")
    val profileBusinessCategory = MutableStateFlow("Compte Professionnel ADT")
    val profileBio = MutableStateFlow("Disponible sur le réseau ADT Pro")
    val profileAvatarChoice = MutableStateFlow("avatar_pro")
    val verifiedFirebaseUid = MutableStateFlow<String?>(null)

    // Contact Sync State
    val isSyncingContacts = MutableStateFlow(false)
    val syncResultMessage = MutableStateFlow<String?>(null)
    val lastSyncResult = MutableStateFlow<com.example.util.ContactSyncResult?>(null)
    val lastSyncTime = MutableStateFlow<Long?>(null)

    private var callTimerJob: Job? = null
    private var resendTimerJob: Job? = null

    init {
        val db = AppDatabase.getDatabase(application)
        repository = AdtRepository(db)

        currentUser = repository.currentUserFlow.stateIn(
            viewModelScope, SharingStarted.WhileSubscribed(5000), null
        )
        activeChats = repository.activeChatsFlow.stateIn(
            viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
        )
        lockedChats = repository.lockedChatsFlow.stateIn(
            viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
        )
        lockedChatsCount = repository.lockedChatsCountFlow.stateIn(
            viewModelScope, SharingStarted.WhileSubscribed(5000), 0
        )
        archivedChats = repository.archivedChatsFlow.stateIn(
            viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
        )
        archivedChatsCount = repository.archivedChatsCountFlow.stateIn(
            viewModelScope, SharingStarted.WhileSubscribed(5000), 0
        )
        allContacts = repository.allContactsFlow.stateIn(
            viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
        )
        allStatuses = repository.allStatusesFlow.stateIn(
            viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
        )
        allChannels = repository.allChannelsFlow.stateIn(
            viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
        )
        allCalls = repository.allCallsFlow.stateIn(
            viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
        )
        appSettings = repository.appSettingsFlow.stateIn(
            viewModelScope, SharingStarted.WhileSubscribed(5000), AppSettingsEntity()
        )

        viewModelScope.launch {
            repository.initializeDefaultDataIfEmpty()
            repository.enrichAndSeedAllData(force = false)
            repository.auditDatabaseSecurity()
            repository.purgeExpiredStatuses()
            FirebaseInitHelper.ensureAuthenticated(application)
            FirebaseAiQuickReplyService.init(application)
            // Check Two-Step verification launch lock
            val twoStepState = twoStepVerificationManager.verificationStateFlow.first()
            if (twoStepState.isEnabled && twoStepState.requirePinOnLaunch) {
                isAppLockedByTwoStep.value = true
            }
            // Check Biometric launch lock
            val currentPrivacyPrefs = privacyPreferencesDataStore.privacyPreferencesFlow.first()
            if (currentPrivacyPrefs.isBiometricEnabled) {
                isAppLockedByBiometric.value = true
            }
            // Load verified E2EE fingerprints
            val storedVerified = e2eeVerificationPrefs.getStringSet("verified_chat_ids", emptySet()) ?: emptySet()
            _verifiedChatFingerprints.value = storedVerified
            var lastBackupVerifiedPhone: String? = null
            // Check if user is registered; if so, start Firestore real-time synchronization
            currentUser.collect { user ->
                if (user != null) {
                    if (!user.isRegistered && _currentScreen.value == AppScreen.MAIN_TABS) {
                        _currentScreen.value = AppScreen.AUTH_PHONE
                    } else if (user.isRegistered && user.phone.isNotBlank()) {
                        if (syncEnergyMode.value == SyncEnergyMode.HIGH_PERFORMANCE) {
                            firestoreSyncManager.startRealtimeSync(user.phone)
                        } else {
                            firestoreSyncManager.setEnergyMode(syncEnergyMode.value, user.phone)
                        }
                        updateBatteryState()
                        // Trigger automatic backup verification & remote query once per phone session
                        if (lastBackupVerifiedPhone != user.phone) {
                            lastBackupVerifiedPhone = user.phone
                            backupManager.checkAndTriggerAutoBackup(user.phone)
                            backupManager.queryRemoteBackup(user.phone)
                        }
                        firestoreSyncManager.listenForIncomingCalls(user.phone) { callId, callerName, callerPhone, callerAvatar, isVideo ->
                            if (_activeCall.value == null) {
                                callManager.handleIncomingCallOffer(
                                    callId = callId,
                                    callerName = callerName,
                                    callerPhone = callerPhone,
                                    callerAvatar = callerAvatar,
                                    isVideo = isVideo,
                                    myPhone = user.phone
                                )
                                _currentScreen.value = AppScreen.ACTIVE_CALL
                                firestoreSyncManager.listenToActiveCallSession(
                                    callId = callId,
                                    isCaller = false,
                                    onAnswerReceived = {},
                                    onCandidateReceived = { candidate ->
                                        callManager.handleRemoteIceCandidate(candidate)
                                    },
                                    onStatusChanged = { status, reason ->
                                        if (status == "ENDED" || status == "REJECTED") {
                                            callManager.handleRemoteHangup(reason ?: "L'appelant a raccroché")
                                        }
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }

        viewModelScope.launch {
            appSettings.collect { settings ->
                if (settings != null && settings.wallpaperTheme.startsWith("COULEUR_")) {
                    val pal = AdtPaletteColor.fromId(settings.wallpaperTheme)
                    if (homeColorTheme.value != pal) {
                        homeColorTheme.value = pal
                        homeColorPrefs.edit().putString("home_color_theme", pal.id).apply()
                    }
                }
            }
        }

        // Bridge WebRTC signaling events to Firestore Cloud Sync
        callManager.signalingListener = { msg ->
            when (msg) {
                is WebRtcSignalingMessage.Offer -> {
                    val currentCall = _activeCall.value
                    firestoreSyncManager.publishCallOfferToFirestore(
                        callId = msg.callId,
                        callerPhone = msg.callerPhone,
                        callerName = msg.callerName,
                        callerAvatar = currentCall?.contactAvatar ?: "",
                        calleePhone = currentCall?.contactPhone ?: "",
                        isVideo = msg.isVideo,
                        sdpOffer = msg.sdp,
                        e2eeFingerprint = currentCall?.e2eeInfo?.fingerprint ?: ""
                    )
                }
                is WebRtcSignalingMessage.Answer -> {
                    firestoreSyncManager.publishCallAnswerToFirestore(
                        callId = msg.callId,
                        sdpAnswer = msg.sdp
                    )
                }
                is WebRtcSignalingMessage.Hangup -> {
                    firestoreSyncManager.updateCallStatusInFirestore(
                        callId = msg.callId,
                        status = "ENDED",
                        reason = msg.reason
                    )
                }
                is WebRtcSignalingMessage.IceCandidate -> {
                    val currentCall = _activeCall.value
                    val isCaller = !(currentCall?.isIncoming ?: false)
                    firestoreSyncManager.publishIceCandidateToFirestore(
                        callId = msg.callId,
                        candidate = msg,
                        isCaller = isCaller
                    )
                }
                else -> {}
            }
        }

        // Listen for WebRTC CallManager state transitions
        viewModelScope.launch {
            callManager.callSession.collect { session ->
                if (session != null) {
                    _activeCall.value = ActiveCallState(
                        callId = session.callId,
                        contactName = session.contactName,
                        contactPhone = session.contactPhone,
                        contactAvatar = session.contactAvatar,
                        isVideo = session.isVideo,
                        isIncoming = session.isIncoming,
                        isMuted = session.isMuted,
                        isVideoOff = session.isVideoOff,
                        isFrontCamera = session.isFrontCamera,
                        isLocalPreviewMain = session.isLocalPreviewMain,
                        isSpeakerOn = session.isSpeakerOn,
                        durationSeconds = session.durationSeconds,
                        isConnected = session.connectionState == WebRtcConnectionState.CONNECTED,
                        connectionState = session.connectionState,
                        quality = session.quality,
                        e2eeInfo = session.e2eeInfo,
                        audioWaveLevels = session.audioWaveLevels,
                        isGroupCall = session.isGroupCall,
                        roomId = session.roomId,
                        participants = session.participants
                    )
                } else if (_currentScreen.value == AppScreen.ACTIVE_CALL) {
                    _activeCall.value = null
                    _currentScreen.value = if (_activeChatId.value != null) AppScreen.CHAT_ROOM else AppScreen.MAIN_TABS
                } else {
                    _activeCall.value = null
                }
            }
        }
        viewModelScope.launch {
            phoneAuthState.collect { state ->
                when (state) {
                    is PhoneAuthState.CodeSent -> {
                        authErrorMessage.value = null
                        if (state.simulatedSmsCode != null) {
                            generatedOtpCode.value = state.simulatedSmsCode
                            otpBannerMessage.value = "SMS ${selectedOperator.value} : Votre code Firebase ADT Pro est ${state.simulatedSmsCode}"
                        } else {
                            otpBannerMessage.value = "SMS envoyé via Firebase au ${state.phoneNumber}"
                        }
                        startResendCooldownTimer()
                        _currentScreen.value = AppScreen.AUTH_OTP
                    }
                    is PhoneAuthState.Verified -> {
                        authErrorMessage.value = null
                        verifiedFirebaseUid.value = state.firebaseUid
                        if (isLoginMode.value) {
                            // Direct login with existing verified phone
                            completeRegistration(currentAuthActivity)
                        } else {
                            _currentScreen.value = AppScreen.AUTH_PROFILE
                        }
                    }
                    is PhoneAuthState.Error -> {
                        authErrorMessage.value = state.message
                    }
                    else -> {}
                }
            }
        }
    }

    fun getMessagesForChat(chatId: String) = repository.getMessagesForChat(chatId)

    fun navigateTo(screen: AppScreen) {
        _currentScreen.value = screen
    }

    fun navigateBack() {
        if (_currentScreen.value == AppScreen.LIVE_TRACKING) {
            closeLiveTracking()
        } else if (_currentScreen.value == AppScreen.LIVE_LOCATION_SHARING) {
            closeLiveLocationSharingScreen()
        } else if (_currentScreen.value == AppScreen.CHAT_BACKUP) {
            _currentScreen.value = AppScreen.SETTINGS
        } else if (_currentScreen.value == AppScreen.ARCHIVED_CHATS) {
            clearArchivedSearch()
            _currentScreen.value = AppScreen.MAIN_TABS
        } else if (_activeChatId.value != null && _currentScreen.value == AppScreen.CHAT_ROOM) {
            _activeChatId.value = null
            _currentScreen.value = AppScreen.MAIN_TABS
        } else {
            _currentScreen.value = AppScreen.MAIN_TABS
        }
    }

    private var archivedSearchJob: Job? = null

    fun updateArchivedSearchQuery(query: String) {
        _archivedSearchQuery.value = query
        performArchivedSearch(query, _archivedSearchOptions.value)
    }

    fun updateArchivedSearchOptions(options: ArchivedSearchOptions) {
        _archivedSearchOptions.value = options
        performArchivedSearch(_archivedSearchQuery.value, options)
    }

    fun clearArchivedSearch() {
        archivedSearchJob?.cancel()
        _archivedSearchQuery.value = ""
        _archivedSearchResults.value = emptyList()
        _archivedSearchStats.value = null
        _isArchivedSearchLoading.value = false
    }

    private fun performArchivedSearch(query: String, options: ArchivedSearchOptions) {
        archivedSearchJob?.cancel()
        val trimmed = query.trim()
        if (trimmed.isBlank()) {
            _archivedSearchResults.value = emptyList()
            _archivedSearchStats.value = null
            _isArchivedSearchLoading.value = false
            return
        }

        _isArchivedSearchLoading.value = true
        archivedSearchJob = viewModelScope.launch {
            try {
                val (results, stats) = repository.searchArchivedFullText(trimmed, options)
                _archivedSearchResults.value = results
                _archivedSearchStats.value = stats
            } catch (e: Exception) {
                _archivedSearchResults.value = emptyList()
                _archivedSearchStats.value = null
            } finally {
                _isArchivedSearchLoading.value = false
            }
        }
    }

    fun setChatArchived(chatId: String, isArchived: Boolean) {
        viewModelScope.launch {
            repository.setChatArchived(chatId, isArchived)
            if (_archivedSearchQuery.value.isNotBlank()) {
                performArchivedSearch(_archivedSearchQuery.value, _archivedSearchOptions.value)
            }
        }
    }

    fun toggleArchiveChat(chatId: String) {
        viewModelScope.launch {
            val isCurrentArchived = archivedChats.value.any { it.id == chatId }
            repository.setChatArchived(chatId, !isCurrentArchived)
            if (_archivedSearchQuery.value.isNotBlank()) {
                performArchivedSearch(_archivedSearchQuery.value, _archivedSearchOptions.value)
            }
        }
    }

    fun closeLiveTracking() {
        activeTrackingState.value = null
        if (_activeChatId.value != null) {
            _currentScreen.value = AppScreen.CHAT_ROOM
        } else {
            _currentScreen.value = AppScreen.MAIN_TABS
        }
    }

    // AUTH FLOW & FIREBASE PHONE AUTHENTICATION
    fun toggleAuthMode(login: Boolean) {
        isLoginMode.value = login
        authErrorMessage.value = null
    }

    fun selectCountry(country: CountryItem) {
        selectedCountry.value = country
        enteredDialCode.value = country.dialCode.removePrefix("+")
        if (country.defaultOperators.isNotEmpty()) {
            selectedOperator.value = country.defaultOperators.first()
        }
    }

    fun onDialCodeChange(input: String) {
        val digitsOnly = input.filter { it.isDigit() }.take(4)
        enteredDialCode.value = digitsOnly
        if (digitsOnly.isNotEmpty()) {
            val match = CountryData.findByDialCode("+$digitsOnly")
            if (match != null) {
                selectedCountry.value = match
                if (match.defaultOperators.isNotEmpty() && !match.defaultOperators.contains(selectedOperator.value)) {
                    selectedOperator.value = match.defaultOperators.first()
                }
            }
        }
    }

    fun selectCountryByDialCode(dialCode: String) {
        val match = CountryData.findByDialCode(dialCode)
        if (match != null) {
            selectCountry(match)
        }
    }

    fun onPhoneNumberChange(input: String) {
        // Auto-detect country only if user pastes full number with international prefix (+243..., 00243..., etc.)
        val detected = CountryData.detectCountryAndNumber(input)
        if (detected != null) {
            val (country, remaining) = detected
            selectedCountry.value = country
            enteredDialCode.value = country.dialCode.removePrefix("+")
            if (country.defaultOperators.isNotEmpty() && !country.defaultOperators.contains(selectedOperator.value)) {
                selectedOperator.value = country.defaultOperators.first()
            }
            enteredPhoneNumber.value = remaining
        } else {
            val dial = enteredDialCode.value.trim().removePrefix("+")
            val countryDial = selectedCountry.value.dialCode
            val clean = if (input.startsWith(countryDial)) {
                input.removePrefix(countryDial).trim()
            } else if (dial.isNotEmpty() && input.startsWith("+$dial")) {
                input.removePrefix("+$dial").trim()
            } else if (dial.isNotEmpty() && input.startsWith(dial)) {
                input.removePrefix(dial).trim()
            } else if (input.startsWith(countryDial.removePrefix("+"))) {
                input.removePrefix(countryDial.removePrefix("+")).trim()
            } else {
                input.filter { it.isDigit() || it == ' ' }
            }
            enteredPhoneNumber.value = clean
        }
    }

    fun selectOperator(operator: String) {
        selectedOperator.value = operator
    }

    fun applyPresetPhoneNumber(countryName: String, phoneWithoutDial: String, operator: String, fName: String = "", lName: String = "") {
        val country = CountryData.supportedCountries.firstOrNull { it.name.equals(countryName, ignoreCase = true) }
            ?: CountryData.supportedCountries.first()
        selectedCountry.value = country
        enteredDialCode.value = country.dialCode.removePrefix("+")
        enteredPhoneNumber.value = phoneWithoutDial
        selectedOperator.value = operator
        if (fName.isNotBlank()) profileFirstName.value = fName
        if (lName.isNotBlank()) profileLastName.value = lName
    }

    fun getFullFormattedPhoneNumber(): String {
        val rawDial = enteredDialCode.value.trim().removePrefix("+")
        val code = if (rawDial.isNotBlank()) "+$rawDial" else selectedCountry.value.dialCode
        val cleanDial = code.removePrefix("+")
        var rawNumber = enteredPhoneNumber.value.trim().replace(" ", "").replace("-", "")
        if (rawNumber.startsWith(cleanDial)) {
            rawNumber = rawNumber.removePrefix(cleanDial)
        }
        return "$code$rawNumber"
    }

    fun requestOtp(activity: Activity? = null) {
        if (activity != null) currentAuthActivity = activity
        val fullFormattedNumber = getFullFormattedPhoneNumber()
        authErrorMessage.value = null
        enteredOtpCode.value = ""
        firebasePhoneAuthManager.sendVerificationCode(activity ?: currentAuthActivity, fullFormattedNumber, isResend = false)
    }

    fun resendOtp(activity: Activity? = null) {
        if (resendCountdownSeconds.value > 0) return
        if (activity != null) currentAuthActivity = activity
        val fullFormattedNumber = getFullFormattedPhoneNumber()
        firebasePhoneAuthManager.sendVerificationCode(activity ?: currentAuthActivity, fullFormattedNumber, isResend = true)
        startResendCooldownTimer()
    }

    private fun startResendCooldownTimer() {
        resendTimerJob?.cancel()
        resendCountdownSeconds.value = 60
        resendTimerJob = viewModelScope.launch {
            while (resendCountdownSeconds.value > 0) {
                delay(1000)
                resendCountdownSeconds.value -= 1
            }
        }
    }

    fun autoFillOtp() {
        enteredOtpCode.value = generatedOtpCode.value
    }

    fun verifyOtp(activity: Activity? = null): Boolean {
        if (activity != null) currentAuthActivity = activity
        val code = enteredOtpCode.value.trim()
        if (code.length == 6) {
            firebasePhoneAuthManager.verifySmsCode(code)
            return true
        }
        return false
    }

    fun fetchCredentialManagerAccount(activity: Activity?) {
        if (activity == null) return
        currentAuthActivity = activity
        viewModelScope.launch {
            isCredentialLoading.value = true
            credentialManagerMessage.value = "Recherche des identifiants enregistrés..."
            try {
                val stored = credentialAuthManager.getStoredPhoneCredential(activity)
                if (stored != null) {
                    detectedCredential.value = stored
                    onPhoneNumberChange(stored.phoneNumber)
                    val label = if (stored.displayName.isNotBlank()) " (${stored.displayName})" else ""
                    credentialManagerMessage.value = "Identifiant chargé : ${stored.phoneNumber}$label"
                    authErrorMessage.value = null
                } else {
                    detectedCredential.value = null
                    credentialManagerMessage.value = "Aucun identifiant trouvé. Saisissez votre numéro pour l'enregistrer automatiquement."
                }
            } catch (e: Exception) {
                credentialManagerMessage.value = "Erreur Gestionnaire d'identifiants: ${e.message}"
            } finally {
                isCredentialLoading.value = false
            }
        }
    }

    fun loginWithDetectedCredential(activity: Activity?) {
        val cred = detectedCredential.value ?: return
        if (activity != null) currentAuthActivity = activity
        onPhoneNumberChange(cred.phoneNumber)
        isLoginMode.value = true
        completeRegistration(activity ?: currentAuthActivity)
    }

    fun completeRegistration(activity: Activity? = null) {
        if (activity != null) currentAuthActivity = activity
        val act = activity ?: currentAuthActivity
        viewModelScope.launch {
            val phone = getFullFormattedPhoneNumber()
            val dialCode = if (enteredDialCode.value.isNotBlank()) "+${enteredDialCode.value.trim()}" else selectedCountry.value.dialCode
            val firstName = profileFirstName.value.trim().ifBlank { if (isLoginMode.value) "Membre" else "Utilisateur" }
            val lastName = profileLastName.value.trim().ifBlank { "ADT" }
            repository.registerUser(
                phone = phone,
                countryCode = dialCode,
                firstName = firstName,
                lastName = lastName,
                businessCategory = profileBusinessCategory.value,
                bio = profileBio.value,
                operatorName = selectedOperator.value,
                avatarUrl = profileAvatarChoice.value
            )

            // Save phone credential into Android Credential Manager for secure future 1-tap sign-ins
            val fullCleanPhone = phone.replace(" ", "")
            if (act != null) {
                try {
                    val saved = credentialAuthManager.savePhoneCredential(
                        activity = act,
                        phoneNumber = fullCleanPhone,
                        displayName = "$firstName $lastName"
                    )
                    if (saved) {
                        credentialManagerMessage.value = "Identifiant $fullCleanPhone enregistré dans le Gestionnaire d'identifiants !"
                    }
                } catch (e: Exception) {
                    // Ignore background credential saving error
                }
            } else {
                credentialAuthManager.savePhoneToLocalCache(fullCleanPhone, "$firstName $lastName")
            }

            _currentScreen.value = AppScreen.MAIN_TABS
        }
    }

    fun logoutUser() {
        viewModelScope.launch {
            firebasePhoneAuthManager.signOut()
            credentialAuthManager.clearCredentialState()
            detectedCredential.value = null
            credentialManagerMessage.value = null
            repository.updateSettings { it }
            _currentScreen.value = AppScreen.AUTH_PHONE
        }
    }

    // CONTACTS & SYNC
    fun openSyncContacts() {
        _currentScreen.value = AppScreen.SYNC_CONTACTS
    }

    fun syncContactsWithDevice() {
        viewModelScope.launch {
            isSyncingContacts.value = true
            try {
                val result = repository.syncContactsWithDevice(getApplication())
                lastSyncResult.value = result
                lastSyncTime.value = System.currentTimeMillis()
                syncResultMessage.value = "Synchronisation terminée : ${result.adtUsers.size} membres ADT Pro trouvés, ${result.nonAdtContacts.size} contacts prêts à être invités."
            } catch (e: Exception) {
                syncResultMessage.value = "Erreur de synchronisation: ${e.message}"
            } finally {
                isSyncingContacts.value = false
            }
        }
    }

    fun clearSyncMessage() {
        syncResultMessage.value = null
    }

    val qrInitialTab = MutableStateFlow(0)
    val qrScannedHistory = MutableStateFlow<List<ContactEntity>>(emptyList())

    fun openContactQrCode(initialTab: Int = 0) {
        qrInitialTab.value = initialTab
        _currentScreen.value = AppScreen.CONTACT_QR_CODE
    }

    fun addContactFromQr(contact: ContactEntity, onComplete: (Boolean) -> Unit = {}) {
        viewModelScope.launch {
            try {
                repository.insertContact(contact)
                val current = qrScannedHistory.value
                qrScannedHistory.value = listOf(contact) + current.filter { it.id != contact.id }
                onComplete(true)
            } catch (e: Exception) {
                onComplete(false)
            }
        }
    }

    /**
     * Ajoute un nouveau contact directement par son nom et son numéro de téléphone (avec indicatif).
     */
    fun addNewContact(
        name: String,
        phone: String,
        countryCode: String = "",
        onComplete: (Boolean) -> Unit = {}
    ) {
        viewModelScope.launch {
            try {
                val cleanPhone = phone.trim()
                val id = "contact_" + cleanPhone.filter { it.isDigit() }.ifBlank { java.util.UUID.randomUUID().toString().take(8) }
                val newContact = ContactEntity(
                    id = id,
                    name = name.trim().ifBlank { cleanPhone },
                    phone = cleanPhone,
                    countryCode = countryCode.ifBlank { CountryData.detectCountryAndNumber(cleanPhone)?.first?.dialCode ?: "" },
                    avatarUrl = "",
                    bio = "Nouveau contact ADT Pro",
                    isAdtUser = true,
                    isOnline = false,
                    lastSeenText = "Récemment ajouté"
                )
                repository.insertContact(newContact)
                onComplete(true)
            } catch (e: Exception) {
                onComplete(false)
            }
        }
    }

    fun inviteContact(context: android.content.Context, contact: ContactEntity, customMessage: String? = null) {
        val defaultText = "Bonjour ${contact.name}, rejoins-moi sur ADT Pro, la messagerie chiffrée, appels HD et canaux professionnels sécurisés : https://adtpro.app/join"
        val message = customMessage?.ifBlank { defaultText } ?: defaultText
        try {
            val sendIntent = android.content.Intent(android.content.Intent.ACTION_VIEW).apply {
                data = android.net.Uri.parse("sms:${contact.phone}")
                putExtra("sms_body", message)
                flags = android.content.Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(sendIntent)
        } catch (_: Exception) {
            shareGeneralInvite(context, message)
        }
    }

    fun inviteDirectPhone(context: android.content.Context, phone: String, recipientName: String = "", customMessage: String? = null) {
        val greeting = if (recipientName.isNotBlank()) "Bonjour $recipientName, " else "Bonjour ! "
        val defaultText = "${greeting}Rejoins-moi sur ADT Pro, la messagerie chiffrée et réseau télécoms professionnel sécurisé : https://adtpro.app/join"
        val message = customMessage?.ifBlank { defaultText } ?: defaultText
        try {
            val sendIntent = android.content.Intent(android.content.Intent.ACTION_VIEW).apply {
                data = android.net.Uri.parse("sms:$phone")
                putExtra("sms_body", message)
                flags = android.content.Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(sendIntent)
        } catch (_: Exception) {
            shareGeneralInvite(context, message)
        }
    }

    fun inviteMultipleContactsBySms(context: android.content.Context, contacts: List<ContactEntity>, customMessage: String? = null) {
        if (contacts.isEmpty()) return
        val phoneList = contacts.joinToString(";") { it.phone.filter { c -> c.isDigit() || c == '+' } }
        val body = customMessage ?: "Bonjour, rejoins-moi sur ADT Pro pour échanger en toute sécurité avec appels HD et messagerie chiffrée : https://adtpro.app/join"
        try {
            val smsIntent = android.content.Intent(android.content.Intent.ACTION_VIEW).apply {
                data = android.net.Uri.parse("sms:$phoneList")
                putExtra("sms_body", body)
                flags = android.content.Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(smsIntent)
        } catch (_: Exception) {
            shareGeneralInvite(context, body)
        }
    }

    fun shareGeneralInvite(context: android.content.Context, customMessage: String? = null) {
        val myPhone = currentUser.value?.phone.orEmpty()
        val inviteUrl = if (myPhone.isNotBlank()) "https://adtpro.app/join?ref=${android.net.Uri.encode(myPhone)}" else "https://adtpro.app/join"
        val shareText = customMessage ?: "Rejoins-moi sur ADT Pro, l'application de messagerie chiffrée, appels HD sécurisés et canaux de diffusion professionnels ! Télécharge l'application ici : $inviteUrl"
        try {
            val shareIntent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(android.content.Intent.EXTRA_TEXT, shareText)
                flags = android.content.Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(android.content.Intent.createChooser(shareIntent, "Inviter un ami sur ADT Pro"))
        } catch (_: Exception) {}
    }

    // CHAT ACTIONS
    fun openChat(chatId: String) {
        _activeChatId.value = chatId
        firestoreSyncManager.activeChatId = chatId
        _currentScreen.value = AppScreen.CHAT_ROOM
        firestoreSyncManager.attachChatRoomListener(chatId)
        viewModelScope.launch {
            repository.markChatAsRead(chatId)
            val myPhone = currentUser.value?.phone ?: ""
            if (myPhone.isNotBlank()) {
                firestoreSyncManager.markIncomingMessagesAsRead(chatId, myPhone)
            }
        }
    }

    fun closeChat() {
        val chatId = _activeChatId.value
        if (chatId != null) {
            firestoreSyncManager.detachChatRoomListener(chatId)
        }
        firestoreSyncManager.activeChatId = null
        _activeChatId.value = null
        clearQuickReplies()
        _currentScreen.value = AppScreen.MAIN_TABS
    }

    fun clearQuickReplies() {
        quickReplyGenerationJob?.cancel()
        quickReplyGenerationJob = null
        quickReplies.value = emptyList()
        quickRepliesSourceMessageId.value = null
        isGeneratingQuickReplies.value = false
    }

    fun toggleQuickRepliesEnabled(enabled: Boolean) {
        aiPrefs.edit().putBoolean("quick_replies_enabled", enabled).apply()
        quickRepliesEnabled.value = enabled
        if (!enabled) {
            clearQuickReplies()
        } else {
            val chatId = _activeChatId.value
            if (chatId != null) {
                viewModelScope.launch {
                    val messages = getMessagesForChat(chatId).first()
                    checkAndGenerateQuickReplies(messages, forceRegenerate = true)
                }
            }
        }
    }

    fun setQuickRepliesTone(tone: String) {
        aiPrefs.edit().putString("quick_replies_tone", tone).apply()
        quickRepliesTone.value = tone
        regenerateQuickReplies()
    }

    /**
     * Analyse le dernier message reçu dans la conversation active et génère des suggestions
     * de réponses rapides adaptées grâce à Firebase AI (avec fallback intelligent).
     */
    fun checkAndGenerateQuickReplies(
        messages: List<MessageEntity>,
        forceRegenerate: Boolean = false,
        explicitTargetMessage: MessageEntity? = null
    ) {
        if (!quickRepliesEnabled.value) {
            clearQuickReplies()
            return
        }

        if (messages.isEmpty() && explicitTargetMessage == null) {
            quickReplies.value = emptyList()
            quickRepliesSourceMessageId.value = null
            return
        }

        // Le message cible est soit spécifié explicitement, soit le dernier message reçu
        val lastReceived = explicitTargetMessage ?: run {
            val lastMessage = messages.lastOrNull() ?: run {
                clearQuickReplies()
                return
            }

            // Si le dernier message global est sortant (l'utilisateur a déjà répondu) et pas de forçage, masquer les suggestions
            if (lastMessage.isOutgoing && !forceRegenerate) {
                if (quickReplies.value.isNotEmpty()) {
                    clearQuickReplies()
                }
                return
            }

            if (!lastMessage.isOutgoing) lastMessage else (messages.lastOrNull { !it.isOutgoing } ?: run {
                clearQuickReplies()
                return
            })
        }

        // Si c'est déjà ce message qui a généré les réponses actuelles et pas de forçage, pas besoin de recalculer
        if (!forceRegenerate && quickRepliesSourceMessageId.value == lastReceived.id && quickReplies.value.isNotEmpty()) {
            return
        }

        quickReplyGenerationJob?.cancel()
        quickReplyGenerationJob = viewModelScope.launch {
            isGeneratingQuickReplies.value = true
            quickRepliesSourceMessageId.value = lastReceived.id

            val currentChat = activeChats.value.find { it.id == lastReceived.chatId }
            val chatTitle = currentChat?.title ?: "Discussion"
            val senderName = lastReceived.senderName.ifBlank { "Contact" }
            val messageText = lastReceived.text

            val language = appSettings.value?.language ?: "FR"
            val tone = quickRepliesTone.value

            // Historique contextuel des messages récents précédant ce message
            val targetIndex = messages.indexOfFirst { it.id == lastReceived.id }
            val previousMessages = if (targetIndex > 0) {
                messages.subList(0, targetIndex).takeLast(4)
            } else {
                emptyList()
            }
            val recentContext = previousMessages.map { msg ->
                Pair(if (msg.isOutgoing) "Moi" else msg.senderName.ifBlank { "Contact" }, msg.text)
            }

            try {
                val suggestions = FirebaseAiQuickReplyService.generateQuickReplies(
                    context = getApplication<Application>(),
                    lastMessage = messageText,
                    senderName = senderName,
                    chatTitle = chatTitle,
                    language = language,
                    tone = tone,
                    recentMessages = recentContext
                )
                quickReplies.value = suggestions.take(3)
            } catch (e: Exception) {
                quickReplies.value = FirebaseAiQuickReplyService.generateSmartContextualFallback(messageText, language).take(3)
            } finally {
                isGeneratingQuickReplies.value = false
            }
        }
    }

    fun regenerateQuickReplies() {
        val chatId = _activeChatId.value ?: return
        viewModelScope.launch {
            val messages = getMessagesForChat(chatId).first()
            checkAndGenerateQuickReplies(messages, forceRegenerate = true)
        }
    }

    fun generateQuickRepliesForSpecificMessage(targetMessage: MessageEntity) {
        val chatId = _activeChatId.value ?: return
        viewModelScope.launch {
            val messages = getMessagesForChat(chatId).first()
            checkAndGenerateQuickReplies(messages, forceRegenerate = true, explicitTargetMessage = targetMessage)
        }
    }

    fun forceGenerateQuickRepliesForLastReceived() {
        val chatId = _activeChatId.value ?: return
        viewModelScope.launch {
            val messages = getMessagesForChat(chatId).first()
            checkAndGenerateQuickReplies(messages, forceRegenerate = true)
        }
    }

    fun openDirectChatWithContact(contact: ContactEntity) {
        viewModelScope.launch {
            val chatId = repository.getOrCreateDirectChat(contact)
            openChat(chatId)
        }
    }

    fun sendTextMessage(text: String, replyTo: MessageEntity? = null) {
        val chatId = _activeChatId.value ?: return
        if (text.isBlank()) return
        val currentChat = activeChats.value.find { it.id == chatId }
        val title = currentChat?.title ?: "Discussion"
        val isGroup = currentChat?.isGroup ?: false
        val avatar = currentChat?.avatarUrl ?: ""

        // Réinitialiser les suggestions une fois le message envoyé
        quickReplies.value = emptyList()
        quickRepliesSourceMessageId.value = null

        viewModelScope.launch {
            val msg = repository.sendMessage(
                chatId = chatId,
                text = text.trim(),
                mediaType = "TEXT",
                replyToText = replyTo?.text,
                replyToSender = replyTo?.senderName
            )
            firestoreSyncManager.uploadMessageToFirestore(msg, title, isGroup, avatar)
            scheduleReceiptProgression(msg.id, chatId, isGroup)
        }
    }

    fun sendVoiceNote(durationSeconds: Int) {
        val chatId = _activeChatId.value ?: return
        val currentChat = activeChats.value.find { it.id == chatId }
        val title = currentChat?.title ?: "Discussion"
        val isGroup = currentChat?.isGroup ?: false
        val avatar = currentChat?.avatarUrl ?: ""

        viewModelScope.launch {
            val msg = repository.sendMessage(
                chatId = chatId,
                text = "Message vocal ($durationSeconds s)",
                mediaType = "AUDIO",
                mediaDuration = durationSeconds
            )
            firestoreSyncManager.uploadMessageToFirestore(msg, title, isGroup, avatar)
            scheduleReceiptProgression(msg.id, chatId, isGroup)
        }
    }

    fun sendPhotoMessage(caption: String, photoLabel: String) {
        val chatId = _activeChatId.value ?: return
        val currentChat = activeChats.value.find { it.id == chatId }
        val title = currentChat?.title ?: "Discussion"
        val isGroup = currentChat?.isGroup ?: false
        val avatar = currentChat?.avatarUrl ?: ""

        viewModelScope.launch {
            val msg = repository.sendMessage(
                chatId = chatId,
                text = if (caption.isNotBlank()) caption else "Photo partagée",
                mediaType = "PHOTO",
                mediaUrl = photoLabel
            )
            firestoreSyncManager.uploadMessageToFirestore(msg, title, isGroup, avatar)
            scheduleReceiptProgression(msg.id, chatId, isGroup)
        }
    }

    fun sendVideoMessage(caption: String, duration: Int) {
        val chatId = _activeChatId.value ?: return
        val currentChat = activeChats.value.find { it.id == chatId }
        val title = currentChat?.title ?: "Discussion"
        val isGroup = currentChat?.isGroup ?: false
        val avatar = currentChat?.avatarUrl ?: ""

        viewModelScope.launch {
            val msg = repository.sendMessage(
                chatId = chatId,
                text = if (caption.isNotBlank()) caption else "Vidéo professionnelle",
                mediaType = "VIDEO",
                mediaDuration = duration
            )
            firestoreSyncManager.uploadMessageToFirestore(msg, title, isGroup, avatar)
            scheduleReceiptProgression(msg.id, chatId, isGroup)
        }
    }

    fun sendStickerMessage(stickerEmoji: String, stickerTitle: String) {
        val chatId = _activeChatId.value ?: return
        val currentChat = activeChats.value.find { it.id == chatId }
        val title = currentChat?.title ?: "Discussion"
        val isGroup = currentChat?.isGroup ?: false
        val avatar = currentChat?.avatarUrl ?: ""

        viewModelScope.launch {
            val msg = repository.sendMessage(
                chatId = chatId,
                text = "$stickerEmoji $stickerTitle",
                mediaType = "STICKER",
                mediaUrl = stickerEmoji
            )
            firestoreSyncManager.uploadMessageToFirestore(msg, title, isGroup, avatar)
            scheduleReceiptProgression(msg.id, chatId, isGroup)
        }
    }

    // Document Sharing & Safety Scanning Controls
    fun openDocumentPicker() {
        showDocumentPicker.value = true
    }

    fun closeDocumentPicker() {
        showDocumentPicker.value = false
        isDocumentUploading.value = false
        documentUploadProgress.value = 0f
        documentUploadStatusMessage.value = ""
    }

    fun openDocumentPreview(document: SecureDocument) {
        previewingDocument.value = document
    }

    fun closeDocumentPreview() {
        previewingDocument.value = null
    }

    fun openDocumentSecurityReport(document: SecureDocument) {
        inspectingSecurityReportDocument.value = document
    }

    fun closeDocumentSecurityReport() {
        inspectingSecurityReportDocument.value = null
    }

    fun sendSecureDocument(
        document: SecureDocument,
        rawBytes: ByteArray? = null,
        caption: String = ""
    ) {
        val chatId = _activeChatId.value ?: return
        val currentChat = activeChats.value.find { it.id == chatId }
        val title = currentChat?.title ?: "Discussion"
        val isGroup = currentChat?.isGroup ?: false
        val avatar = currentChat?.avatarUrl ?: ""

        viewModelScope.launch {
            isDocumentUploading.value = true
            documentUploadProgress.value = 0.1f
            documentUploadStatusMessage.value = "Chiffrement du document (AES-256)..."

            val documentWithCaption = document.copy(
                caption = caption.trim()
            )

            documentUploadProgress.value = 0.3f
            documentUploadStatusMessage.value = "Téléversement vers Firebase Storage..."

            val scannedDocument = firebaseDocumentManager.uploadAndScanDocument(
                chatId = chatId,
                document = documentWithCaption,
                rawBytes = rawBytes,
                onProgress = { p ->
                    documentUploadProgress.value = p
                    if (p >= 0.7f) {
                        documentUploadStatusMessage.value = "Analyse antivirus côté serveur (Cloud Armor)..."
                    }
                }
            )

            documentUploadProgress.value = 1.0f
            documentUploadStatusMessage.value = "Document sécurisé et validé !"
            delay(200)

            val serializedMeta = scannedDocument.serialize()
            val msg = repository.sendMessage(
                chatId = chatId,
                text = scannedDocument.fileName,
                mediaType = "DOCUMENT",
                mediaUrl = serializedMeta
            )

            firestoreSyncManager.uploadMessageToFirestore(msg, title, isGroup, avatar)
            scheduleReceiptProgression(msg.id, chatId, isGroup)

            closeDocumentPicker()
        }
    }

    fun updateChatSearchQuery(query: String) {
        chatSearchQuery.value = query
        if (query.isBlank()) {
            matchingChatIdsFromMessages.value = emptySet()
            matchingMessages.value = emptyList()
        } else {
            viewModelScope.launch {
                val matchingIds = repository.getChatIdsMatchingMessageText(query)
                matchingChatIdsFromMessages.value = matchingIds.toSet()
                matchingMessages.value = repository.searchMessagesByText(query)
            }
        }
    }

    fun openShareLocationDialog(fromChatId: String? = null) {
        locationShareFromChatId.value = fromChatId
        showShareLocationDialog.value = true
    }

    fun closeShareLocationDialog() {
        showShareLocationDialog.value = false
        locationShareFromChatId.value = null
    }

    fun shareLiveLocation(
        targetPhonesOrChatIds: List<String>,
        durationMinutes: Int,
        comment: String,
        location: SampleLocationPoint
    ) {
        val now = System.currentTimeMillis()
        val payload = LiveLocationPayload(
            latitude = location.latitude,
            longitude = location.longitude,
            address = location.address,
            durationMinutes = durationMinutes,
            startedAt = now,
            expiresAt = now + durationMinutes * 60 * 1000L,
            isActive = true,
            comment = comment
        )
        val serialized = payload.serialize()

        viewModelScope.launch {
            targetPhonesOrChatIds.forEach { targetId ->
                val chatId = if (targetId.startsWith("chat_")) {
                    targetId
                } else {
                    val contact = allContacts.value.find { it.phone == targetId || it.id == targetId }
                    if (contact != null) {
                        repository.getOrCreateDirectChat(contact)
                    } else {
                        targetId
                    }
                }

                val currentChat = activeChats.value.find { it.id == chatId }
                val title = currentChat?.title ?: "Discussion"
                val isGroup = currentChat?.isGroup ?: false
                val avatar = currentChat?.avatarUrl ?: ""

                val msgText = if (comment.isNotBlank()) "📍 $comment" else "📍 Position en direct partagée (${durationMinutes} min)"
                val msg = repository.sendMessage(
                    chatId = chatId,
                    text = msgText,
                    mediaType = "LIVE_LOCATION",
                    mediaUrl = serialized,
                    mediaDuration = durationMinutes * 60
                )
                firestoreSyncManager.uploadMessageToFirestore(msg, title, isGroup, avatar)
                scheduleReceiptProgression(msg.id, chatId, isGroup)
            }
            closeShareLocationDialog()
        }
    }

    fun stopLiveLocationSharing(messageId: String) {
        viewModelScope.launch {
            repository.stopLiveLocation(messageId)
        }
    }

    // --- REAL-TIME LIVE LOCATION SHARING WITH GOOGLE MAPS API & PERIODIC UPDATES ---
    val liveLocationEngine = LiveLocationPeriodicEngine(application)
    val liveSharingSession = MutableStateFlow<LiveLocationSharingSession?>(null)
    val periodicUpdateCountdown = MutableStateFlow<Int>(10)
    private var periodicLocationBroadcastJob: Job? = null

    fun openLiveLocationSharingScreen(fromChatId: String? = null) {
        val targetChat = if (!fromChatId.isNullOrBlank()) {
            activeChats.value.find { it.id == fromChatId }
        } else {
            _activeChatId.value?.let { currentId -> activeChats.value.find { it.id == currentId } }
        }

        val existing = liveSharingSession.value
        if (existing == null) {
            val initialLocation = SampleLocations.presets.first()
            liveSharingSession.value = LiveLocationSharingSession(
                chatId = targetChat?.id,
                chatTitle = targetChat?.title ?: "Tous mes contacts",
                currentLatitude = initialLocation.latitude,
                currentLongitude = initialLocation.longitude,
                currentAddress = initialLocation.address,
                isSharingActive = false,
                updateIntervalSeconds = 10,
                durationMinutes = 60,
                precisionMode = LocationPrecisionMode.HIGH_ACCURACY,
                waypoints = emptyList()
            )
        } else if (targetChat != null && !existing.isSharingActive) {
            liveSharingSession.value = existing.copy(
                chatId = targetChat.id,
                chatTitle = targetChat.title
            )
        }

        navigateTo(AppScreen.LIVE_LOCATION_SHARING)
    }

    fun closeLiveLocationSharingScreen() {
        if (_activeChatId.value != null) {
            _currentScreen.value = AppScreen.CHAT_ROOM
        } else {
            _currentScreen.value = AppScreen.MAIN_TABS
        }
    }

    fun setSharingUpdateInterval(seconds: Int) {
        val current = liveSharingSession.value ?: return
        val clamped = seconds.coerceIn(3, 120)
        liveSharingSession.value = current.copy(updateIntervalSeconds = clamped)
        periodicUpdateCountdown.value = clamped
    }

    fun setSharingDuration(minutes: Int) {
        val current = liveSharingSession.value ?: return
        val now = System.currentTimeMillis()
        liveSharingSession.value = current.copy(
            durationMinutes = minutes,
            startedAt = now,
            expiresAt = now + minutes * 60 * 1000L
        )
    }

    fun setSharingPrecisionMode(mode: LocationPrecisionMode) {
        val current = liveSharingSession.value ?: return
        liveSharingSession.value = current.copy(
            precisionMode = mode,
            updateIntervalSeconds = mode.suggestedIntervalSec
        )
        periodicUpdateCountdown.value = mode.suggestedIntervalSec
    }

    fun setSharingComment(comment: String) {
        val current = liveSharingSession.value ?: return
        liveSharingSession.value = current.copy(comment = comment)
    }

    fun setSharingTargetChat(chatId: String) {
        val current = liveSharingSession.value ?: return
        val chat = activeChats.value.find { it.id == chatId }
        liveSharingSession.value = current.copy(
            chatId = chatId,
            chatTitle = chat?.title ?: "Discussion"
        )
    }

    fun startLiveSharingBroadcast() {
        val session = liveSharingSession.value ?: return
        val targetChatId = session.chatId ?: _activeChatId.value ?: activeChats.value.firstOrNull()?.id ?: return
        val targetChat = activeChats.value.find { it.id == targetChatId }
        val title = targetChat?.title ?: "Discussion"
        val isGroup = targetChat?.isGroup ?: false
        val avatar = targetChat?.avatarUrl ?: ""

        val now = System.currentTimeMillis()
        val expiresAt = now + session.durationMinutes * 60 * 1000L

        viewModelScope.launch {
            val payload = session.copy(
                isSharingActive = true,
                startedAt = now,
                expiresAt = expiresAt,
                lastUpdatedAt = now,
                updateCount = 1
            ).toLiveLocationPayload()

            val msgText = if (session.comment.isNotBlank()) "📍 ${session.comment}" else "📍 Position en direct partagée (${session.durationMinutes} min)"
            val msg = repository.sendMessage(
                chatId = targetChatId,
                text = msgText,
                mediaType = "LIVE_LOCATION",
                mediaUrl = payload.serialize(),
                mediaDuration = session.durationMinutes * 60
            )

            firestoreSyncManager.uploadMessageToFirestore(msg, title, isGroup, avatar)
            scheduleReceiptProgression(msg.id, targetChatId, isGroup)

            val updatedSession = session.copy(
                chatId = targetChatId,
                chatTitle = title,
                isSharingActive = true,
                startedAt = now,
                expiresAt = expiresAt,
                lastUpdatedAt = now,
                updateCount = 1,
                messageId = msg.id,
                isPaused = false
            )
            liveSharingSession.value = updatedSession
            startPeriodicLocationBroadcastLoop()
        }
    }

    fun pauseOrResumeLiveSharingBroadcast() {
        val current = liveSharingSession.value ?: return
        val newPaused = !current.isPaused
        liveSharingSession.value = current.copy(isPaused = newPaused)
        if (newPaused) {
            periodicLocationBroadcastJob?.cancel()
        } else {
            startPeriodicLocationBroadcastLoop()
        }
    }

    fun stopLiveSharingBroadcast() {
        periodicLocationBroadcastJob?.cancel()
        periodicLocationBroadcastJob = null

        val current = liveSharingSession.value ?: return
        val msgId = current.messageId
        if (!msgId.isNullOrBlank()) {
            viewModelScope.launch {
                repository.stopLiveLocation(msgId)
            }
        }
        liveSharingSession.value = current.copy(
            isSharingActive = false,
            isPaused = false
        )
    }

    fun forcePeriodicLocationUpdate() {
        viewModelScope.launch {
            performSinglePeriodicLocationUpdate()
        }
    }

    private fun startPeriodicLocationBroadcastLoop() {
        periodicLocationBroadcastJob?.cancel()
        periodicLocationBroadcastJob = viewModelScope.launch {
            while (true) {
                val session = liveSharingSession.value
                if (session == null || !session.isSharingActive || session.isExpired() || session.isPaused) {
                    break
                }

                val interval = session.updateIntervalSeconds.coerceAtLeast(3)
                periodicUpdateCountdown.value = interval

                for (sec in interval downTo 1) {
                    periodicUpdateCountdown.value = sec
                    delay(1000L)
                    val activeSession = liveSharingSession.value
                    if (activeSession == null || !activeSession.isSharingActive || activeSession.isExpired() || activeSession.isPaused) {
                        break
                    }
                }

                val checkSession = liveSharingSession.value
                if (checkSession != null && checkSession.isSharingActive && !checkSession.isExpired() && !checkSession.isPaused) {
                    performSinglePeriodicLocationUpdate()
                }
            }
        }
    }

    private suspend fun performSinglePeriodicLocationUpdate() {
        val current = liveSharingSession.value ?: return
        if (!current.isSharingActive || current.isExpired()) return

        val updatedSession = liveLocationEngine.computeNextPeriodicStep(current)
        liveSharingSession.value = updatedSession
        periodicUpdateCountdown.value = updatedSession.updateIntervalSeconds

        // Synchronize updated coordinates with Room and Firestore
        val msgId = updatedSession.messageId
        val chatId = updatedSession.chatId
        if (!msgId.isNullOrBlank() && !chatId.isNullOrBlank()) {
            val payload = updatedSession.toLiveLocationPayload()
            repository.updateLiveLocationPayload(msgId, payload)
            firestoreSyncManager.updateMessageStatusInFirestore(chatId, msgId, "UPDATED_LOCATION")
        }
    }

    // --- GOOGLE MAPS LIVE LOCATION MOVEMENT TRACKING ---
    val activeTrackingState = MutableStateFlow<LiveTrackingState?>(null)

    fun openLiveTracking(
        messageId: String,
        chatId: String,
        contactName: String,
        contactPhone: String,
        contactAvatar: String,
        payload: LiveLocationPayload
    ) {
        val initialWaypoints = if (payload.waypoints.isEmpty()) {
            GoogleMapsHelper.generateRealisticMovementRoute(payload.latitude, payload.longitude, count = 8)
        } else {
            payload.waypoints
        }

        val enrichedPayload = payload.copy(
            waypoints = initialWaypoints,
            contactName = contactName,
            contactPhone = contactPhone
        )

        activeTrackingState.value = LiveTrackingState(
            messageId = messageId,
            chatId = chatId,
            contactName = contactName,
            contactPhone = contactPhone,
            contactAvatar = contactAvatar,
            payload = enrichedPayload,
            isSimulating = true,
            simulationSpeedMultiplier = 1
        )
        navigateTo(AppScreen.LIVE_TRACKING)
    }

    fun updateLiveTrackingPayload(updatedPayload: LiveLocationPayload) {
        val current = activeTrackingState.value ?: return
        activeTrackingState.value = current.copy(payload = updatedPayload)
        if (current.messageId.isNotBlank()) {
            viewModelScope.launch {
                repository.updateLiveLocationPayload(current.messageId, updatedPayload)
            }
        }
    }

    fun toggleTrackingSimulation() {
        val current = activeTrackingState.value ?: return
        activeTrackingState.value = current.copy(isSimulating = !current.isSimulating)
    }

    fun setSimulationMultiplier(multiplier: Int) {
        val current = activeTrackingState.value ?: return
        activeTrackingState.value = current.copy(simulationSpeedMultiplier = multiplier)
    }

    fun simulateNextMovementStep() {
        val current = activeTrackingState.value ?: return
        val payload = current.payload
        if (!payload.isActive || payload.isExpired()) return

        val speed = when ((current.payload.waypoints.size) % 5) {
            0 -> 26f
            1 -> 38f
            2 -> 46f
            3 -> 32f
            else -> 15f
        }
        var newBearing = (payload.bearingDegrees + ((-15..25).random())).coerceIn(0f, 360f)
        val deltaLat = (kotlin.math.cos(Math.toRadians(newBearing.toDouble())) * 0.00065 * (speed / 30f))
        val deltaLng = (kotlin.math.sin(Math.toRadians(newBearing.toDouble())) * 0.00075 * (speed / 30f))

        val newLat = payload.latitude + deltaLat
        val newLng = payload.longitude + deltaLng
        val now = System.currentTimeMillis()

        val newWaypoint = LocationWaypoint(
            latitude = newLat,
            longitude = newLng,
            timestamp = now,
            speedKmh = speed,
            bearing = newBearing,
            address = "Point de passage #${payload.waypoints.size + 1}"
        )

        val updatedWaypoints = payload.waypoints + newWaypoint
        val updatedPayload = payload.copy(
            latitude = newLat,
            longitude = newLng,
            currentSpeedKmh = speed,
            bearingDegrees = newBearing,
            waypoints = updatedWaypoints,
            batteryPercent = (payload.batteryPercent - 1).coerceAtLeast(12)
        )

        updateLiveTrackingPayload(updatedPayload)
    }

    fun stopCurrentLiveTracking() {
        val current = activeTrackingState.value ?: return
        val expiredPayload = current.payload.copy(isActive = false)
        activeTrackingState.value = current.copy(payload = expiredPayload, isSimulating = false)
        if (current.messageId.isNotBlank()) {
            viewModelScope.launch {
                repository.stopLiveLocation(current.messageId)
            }
        }
    }

    private fun scheduleReceiptProgression(messageId: String, chatId: String, isGroup: Boolean) {
        viewModelScope.launch {
            // Step 1: Delivered receipt after ~1.2 seconds -> Double grey checkmark
            kotlinx.coroutines.delay(1200)
            repository.updateMessageStatus(messageId, "DELIVERED")
            firestoreSyncManager.updateMessageStatusInFirestore(chatId, messageId, "DELIVERED")

            // Step 2: Read receipt after ~2.8 seconds -> Double BLUE checkmark
            kotlinx.coroutines.delay(2000)
            repository.updateMessageStatus(messageId, "READ")
            firestoreSyncManager.updateMessageStatusInFirestore(chatId, messageId, "READ")
        }
    }

    // FORWARDING
    fun startForwarding(message: MessageEntity) {
        _forwardingMessage.value = message
    }

    fun cancelForwarding() {
        _forwardingMessage.value = null
    }

    fun completeForwardTo(targetChatId: String) {
        val message = _forwardingMessage.value ?: return
        viewModelScope.launch {
            repository.forwardMessage(message, targetChatId)
            _forwardingMessage.value = null
            openChat(targetChatId)
        }
    }

    fun reactToMessage(messageId: String, emoji: String?) {
        viewModelScope.launch {
            val existing = repository.getMessageById(messageId)
            val newEmoji = if (emoji != null && existing?.reaction == emoji) null else emoji
            val updated = repository.reactToMessage(messageId, newEmoji)
            if (updated != null) {
                firestoreSyncManager.updateMessageReactionInFirestore(updated.chatId, messageId, newEmoji)
            }
        }
    }

    fun deleteMessage(messageId: String) {
        viewModelScope.launch {
            repository.deleteMessage(messageId)
        }
    }

    // GROUP MANAGEMENT
    fun createGroup(
        name: String,
        selected: List<ContactEntity>,
        category: String,
        desc: String,
        avatarUrl: String = "group_custom"
    ) {
        viewModelScope.launch {
            val groupId = repository.createGroup(name, selected, category, desc, avatarUrl)
            openChat(groupId)
        }
    }

    fun getGroupMembers(groupId: String) = repository.getGroupMembersFlow(groupId)

    fun addGroupMembers(groupId: String, contacts: List<ContactEntity>) {
        viewModelScope.launch {
            repository.addGroupMembers(groupId, contacts)
        }
    }

    fun removeGroupMember(groupId: String, memberPhone: String, memberName: String) {
        viewModelScope.launch {
            repository.removeGroupMember(groupId, memberPhone, memberName)
        }
    }

    fun toggleGroupAdmin(groupId: String, memberPhone: String, memberName: String, makeAdmin: Boolean) {
        viewModelScope.launch {
            repository.toggleGroupAdmin(groupId, memberPhone, memberName, makeAdmin)
        }
    }

    fun updateGroupInfo(groupId: String, newTitle: String, newDescription: String) {
        viewModelScope.launch {
            repository.updateGroupInfo(groupId, newTitle, newDescription)
        }
    }

    fun leaveGroup(groupId: String) {
        viewModelScope.launch {
            repository.leaveGroup(groupId)
            closeChat()
        }
    }

    fun deleteGroup(groupId: String) {
        viewModelScope.launch {
            repository.deleteGroup(groupId)
            closeChat()
        }
    }

    fun openGroupInfo() {
        _currentScreen.value = AppScreen.GROUP_INFO
    }

    // CHANNELS & BROADCAST
    fun openChannel(channelId: String) {
        _activeChannelId.value = channelId
        _currentScreen.value = AppScreen.CHANNEL_ROOM
    }

    fun getPostsForChannel(channelId: String) = repository.getPostsForChannelFlow(channelId)

    fun getChannel(channelId: String) = repository.getChannelFlow(channelId)

    fun createChannel(name: String, description: String, category: String) {
        viewModelScope.launch {
            val channelId = repository.createChannel(name, description, category)
            openChannel(channelId)
        }
    }

    fun broadcastPost(
        channelId: String,
        text: String,
        mediaType: String = "TEXT",
        mediaUrl: String? = null,
        mediaTitle: String? = null,
        isPinned: Boolean = false,
        pollQuestion: String? = null,
        pollOption1: String? = null,
        pollOption2: String? = null,
        pollOption3: String? = null,
        pollOption4: String? = null
    ) {
        viewModelScope.launch {
            val post = repository.broadcastChannelPost(
                channelId = channelId,
                text = text,
                mediaType = mediaType,
                mediaUrl = mediaUrl,
                mediaTitle = mediaTitle,
                isPinned = isPinned,
                pollQuestion = pollQuestion,
                pollOption1 = pollOption1,
                pollOption2 = pollOption2,
                pollOption3 = pollOption3,
                pollOption4 = pollOption4
            )
            val channel = repository.getChannelFlow(channelId)
            // Sync to Firestore cloud
            firestoreSyncManager.uploadChannelPostToFirestore(post, "")
        }
    }

    fun reactToChannelPost(postId: String, emoji: String) {
        viewModelScope.launch {
            repository.reactToChannelPost(postId, emoji)
        }
    }

    fun voteChannelPoll(postId: String, optionIndex: Int) {
        viewModelScope.launch {
            repository.voteChannelPoll(postId, optionIndex)
        }
    }

    fun togglePinChannelPost(postId: String, isPinned: Boolean) {
        viewModelScope.launch {
            repository.togglePinChannelPost(postId, isPinned)
        }
    }

    fun deleteChannelPost(postId: String) {
        viewModelScope.launch {
            repository.deleteChannelPost(postId)
        }
    }

    fun toggleChannelFollow(channelId: String, currentFollowState: Boolean) {
        viewModelScope.launch {
            repository.toggleChannelFollow(channelId, !currentFollowState)
        }
    }

    fun toggleChannelMute(channelId: String, currentMuteState: Boolean) {
        viewModelScope.launch {
            repository.toggleChannelMute(channelId, !currentMuteState)
        }
    }

    fun deleteChannel(channelId: String) {
        viewModelScope.launch {
            repository.deleteChannel(channelId)
            _activeChannelId.value = null
            _currentScreen.value = AppScreen.MAIN_TABS
        }
    }

    // STATUS
    fun openStatus(status: StatusEntity) {
        _activeStatus.value = status
        _currentScreen.value = AppScreen.STATUS_VIEWER
        viewModelScope.launch {
            repository.viewStatus(status.id)
        }
    }

    fun switchActiveStatus(status: StatusEntity) {
        _activeStatus.value = status
        viewModelScope.launch {
            repository.viewStatus(status.id)
        }
    }

    fun reactToStatus(status: StatusEntity, emoji: String) {
        viewModelScope.launch {
            val contact = allContacts.value.find { it.phone == status.authorPhone }
                ?: ContactEntity(
                    id = status.authorPhone.ifBlank { "contact_${status.id}" },
                    name = status.authorName,
                    phone = status.authorPhone,
                    countryCode = "+221",
                    avatarUrl = status.authorAvatar,
                    bio = "Membre ADT Pro",
                    isAdtUser = true,
                    isOnline = true,
                    lastSeenText = "En ligne"
                )
            val chatId = repository.getOrCreateDirectChat(contact)
            val replyMsg = repository.sendMessage(
                chatId = chatId,
                text = "$emoji A réagi à votre statut : \"${status.text.take(50)}\"",
                mediaType = "TEXT"
            )
            firestoreSyncManager.uploadMessageToFirestore(replyMsg, status.authorName, false, status.authorAvatar)
            scheduleReceiptProgression(replyMsg.id, chatId, false)
        }
    }

    fun postNewStatus(text: String, bgHex: String) {
        viewModelScope.launch {
            repository.postStatus(text = text, bgHex = bgHex)
            _currentScreen.value = AppScreen.MAIN_TABS
        }
    }

    fun postPhotoStatus(caption: String, photoUri: String, bgHex: String = "#075E54") {
        viewModelScope.launch {
            repository.postStatus(text = caption, mediaUrl = photoUri, bgHex = bgHex)
            _currentScreen.value = AppScreen.MAIN_TABS
        }
    }

    fun deleteStatus(statusId: String) {
        viewModelScope.launch {
            repository.deleteStatus(statusId)
            if (_activeStatus.value?.id == statusId) {
                _activeStatus.value = null
                _currentScreen.value = AppScreen.MAIN_TABS
            }
        }
    }

    fun replyToStatus(status: StatusEntity, replyText: String) {
        if (replyText.isBlank()) return
        viewModelScope.launch {
            // Find or create direct chat with the status author
            val contact = allContacts.value.find { it.phone == status.authorPhone }
                ?: ContactEntity(
                    id = status.authorPhone.ifBlank { "contact_${status.id}" },
                    name = status.authorName,
                    phone = status.authorPhone,
                    countryCode = "+221",
                    avatarUrl = status.authorAvatar,
                    bio = "Membre ADT Pro",
                    isAdtUser = true,
                    isOnline = true,
                    lastSeenText = "En ligne"
                )
            val chatId = repository.getOrCreateDirectChat(contact)
            val replyMsg = repository.sendMessage(
                chatId = chatId,
                text = "💬 En réponse à votre statut : \"${status.text.take(60)}\"\n\n$replyText",
                mediaType = "TEXT"
            )
            firestoreSyncManager.uploadMessageToFirestore(replyMsg, status.authorName, false, status.authorAvatar)
            scheduleReceiptProgression(replyMsg.id, chatId, false)
            openChat(chatId)
        }
    }

    // CALLS
    fun startGroupConferenceCall(groupId: String, groupTitle: String, isVideo: Boolean) {
        _currentScreen.value = AppScreen.ACTIVE_CALL
        val user = currentUser.value
        val myPhone = user?.phone.orEmpty().ifBlank { "+221770000000" }
        val myName = user?.name.orEmpty().ifBlank { "Moi" }
        val myId = user?.id?.toString() ?: "self_user"

        // Gather initial contacts from group members if available
        val sampleGroupContacts = allContacts.value.take(3).map { contact ->
            com.example.data.webrtc.CallParticipant(
                userId = contact.id,
                userName = contact.name,
                userPhone = contact.phone,
                avatarUrl = contact.avatarUrl,
                isSelf = false,
                isConnected = true,
                isAudioMuted = false,
                isVideoOff = !isVideo,
                isE2eeVerified = true
            )
        }

        callManager.startGroupConferenceRoom(
            groupId = groupId,
            groupTitle = groupTitle,
            isVideo = isVideo,
            myUserId = myId,
            myUserName = myName,
            myPhone = myPhone,
            initialParticipants = sampleGroupContacts
        )
    }

    fun inviteParticipantToConference(userId: String, userName: String) {
        val contact = allContacts.value.find { it.id == userId || it.name == userName }
        val participant = com.example.data.webrtc.CallParticipant(
            userId = userId,
            userName = userName,
            userPhone = contact?.phone.orEmpty(),
            avatarUrl = contact?.avatarUrl.orEmpty(),
            isSelf = false,
            isConnected = true,
            isAudioMuted = false,
            isVideoOff = false,
            isE2eeVerified = true
        )
        callManager.addParticipantToConference(participant)
    }

    fun startCall(name: String, phone: String, avatar: String, isVideo: Boolean) {
        _currentScreen.value = AppScreen.ACTIVE_CALL
        val myPhone = currentUser.value?.phone.orEmpty().ifBlank { "+221770000000" }
        val callId = callManager.startOutgoingCall(
            contactName = name,
            contactPhone = phone,
            contactAvatar = avatar,
            isVideo = isVideo,
            myPhone = myPhone
        )
        // Attach active call listener to Firestore for real-time bidirectional signaling
        firestoreSyncManager.listenToActiveCallSession(
            callId = callId,
            isCaller = true,
            onAnswerReceived = { sdpAnswer ->
                callManager.handleAnswerReceived(sdpAnswer)
            },
            onCandidateReceived = { candidate ->
                callManager.handleRemoteIceCandidate(candidate)
            },
            onStatusChanged = { status, reason ->
                if (status == "ENDED" || status == "REJECTED") {
                    callManager.handleRemoteHangup(reason ?: "Appel terminé à distance")
                }
            }
        )
    }

    fun acceptIncomingCall() {
        val current = _activeCall.value
        callManager.acceptIncomingCall()
        _currentScreen.value = AppScreen.ACTIVE_CALL
        if (current != null) {
            firestoreSyncManager.listenToActiveCallSession(
                callId = current.callId,
                isCaller = false,
                onAnswerReceived = {},
                onCandidateReceived = { candidate ->
                    callManager.handleRemoteIceCandidate(candidate)
                },
                onStatusChanged = { status, reason ->
                    if (status == "ENDED" || status == "REJECTED") {
                        callManager.handleRemoteHangup(reason ?: "L'appelant a raccroché")
                    }
                }
            )
        }
    }

    fun toggleCallMute() {
        callManager.toggleMicrophone()
    }

    fun toggleCallVideo() {
        callManager.toggleVideo()
    }

    fun toggleCallSpeaker() {
        callManager.toggleSpeaker()
    }

    fun switchCallCamera() {
        callManager.switchCamera()
    }

    fun toggleVideoPreviewSwap() {
        callManager.toggleVideoPreviewSwap()
    }

    fun upgradeToVideoCall() {
        callManager.upgradeToVideoCall()
    }

    fun minimizeCall() {
        _currentScreen.value = if (_activeChatId.value != null) AppScreen.CHAT_ROOM else AppScreen.MAIN_TABS
    }

    fun restoreCall() {
        if (_activeCall.value != null) {
            _currentScreen.value = AppScreen.ACTIVE_CALL
        }
    }

    fun simulateIncomingCall(isVideo: Boolean = false, contact: ContactEntity? = null) {
        val caller = contact ?: allContacts.value.firstOrNull() ?: ContactEntity(
            id = "c_incoming_test",
            name = "Awa Diop",
            phone = "+221 77 555 12 34",
            countryCode = "+221",
            avatarUrl = "avatar_2",
            bio = "Responsable Télécoms",
            isAdtUser = true,
            isOnline = true,
            lastSeenText = "En ligne"
        )
        val myPhone = currentUser.value?.phone.orEmpty().ifBlank { "+221770000000" }
        val testCallId = "call_${System.currentTimeMillis()}"
        callManager.handleIncomingCallOffer(
            callId = testCallId,
            callerName = caller.name,
            callerPhone = caller.phone,
            callerAvatar = caller.avatarUrl,
            isVideo = isVideo,
            myPhone = myPhone
        )
        _currentScreen.value = AppScreen.ACTIVE_CALL
    }

    /**
     * Simulates or triggers a missed call push notification via CallNotificationHelper,
     * demonstrating FCM behavior when an audio or video call is missed while in background.
     */
    fun simulateMissedCallNotification(isVideo: Boolean = false, contact: ContactEntity? = null) {
        val caller = contact ?: allContacts.value.firstOrNull() ?: ContactEntity(
            id = "c_missed_test",
            name = "Awa Diop",
            phone = "+221 77 555 12 34",
            countryCode = "+221",
            avatarUrl = "avatar_2",
            bio = "Responsable Télécoms",
            isAdtUser = true,
            isOnline = true,
            lastSeenText = "En ligne"
        )
        val testCallId = "call_missed_${System.currentTimeMillis()}"

        viewModelScope.launch {
            // 1. Log as missed call in local Room database
            repository.logCall(
                contactName = caller.name,
                contactPhone = caller.phone,
                contactAvatar = caller.avatarUrl,
                durationSeconds = 0,
                isVideo = isVideo,
                isOutgoing = false,
                isMissed = true
            )

            // 2. Post high-priority system notification
            com.example.data.notification.CallNotificationHelper.showMissedCallNotification(
                context = getApplication(),
                callId = testCallId,
                callerName = caller.name,
                callerPhone = caller.phone,
                callerAvatar = caller.avatarUrl,
                isVideo = isVideo
            )
        }
    }

    fun verifyCallSafetyNumber() {
        callManager.toggleSafetyNumberVerified()
    }

    fun endCall() {
        firestoreSyncManager.detachActiveCallSessionListener()
        val current = _activeCall.value
        if (current != null) {
            viewModelScope.launch {
                repository.logCall(
                    contactName = current.contactName,
                    contactPhone = current.contactPhone,
                    contactAvatar = current.contactAvatar,
                    durationSeconds = current.durationSeconds,
                    isVideo = current.isVideo,
                    isOutgoing = !current.isIncoming,
                    isMissed = current.durationSeconds == 0 && !current.isConnected
                )
            }
        }
        callManager.endCall()
        _activeCall.value = null
        _currentScreen.value = if (_activeChatId.value != null) AppScreen.CHAT_ROOM else AppScreen.MAIN_TABS
    }

    // SETTINGS
    fun updateUserProfile(firstName: String, lastName: String, bio: String, businessCategory: String, avatarUrl: String) {
        viewModelScope.launch {
            repository.updateProfile(
                firstName = firstName,
                lastName = lastName,
                bio = bio,
                businessCategory = businessCategory,
                avatarUrl = avatarUrl
            )
        }
    }

    fun updateStickerPack(stickerPack: String) {
        viewModelScope.launch {
            repository.updateSettings { it.copy(activeStickerPack = stickerPack) }
        }
    }

    fun updateLanguage(language: String) {
        viewModelScope.launch {
            com.example.ui.util.LocaleHelper.setLocale(getApplication(), language)
            repository.updateSettings { it.copy(language = language) }
        }
    }

    fun updateTheme(themeMode: String) {
        viewModelScope.launch {
            repository.updateSettings { it.copy(themeMode = themeMode) }
        }
    }

    fun updateDarkSchedule(
        scheduleType: String,
        startHour: Int,
        startMinute: Int,
        endHour: Int,
        endMinute: Int
    ) {
        viewModelScope.launch {
            repository.updateSettings {
                it.copy(
                    darkScheduleType = scheduleType,
                    darkScheduleStartHour = startHour,
                    darkScheduleStartMinute = startMinute,
                    darkScheduleEndHour = endHour,
                    darkScheduleEndMinute = endMinute
                )
            }
        }
    }

    fun toggleThemeModeCycle() {
        viewModelScope.launch {
            val currentMode = appSettings.value?.themeMode ?: "DARK"
            val nextMode = when (currentMode) {
                "DARK" -> "LIGHT"
                "LIGHT" -> "AUTO_SCHEDULE"
                "AUTO_SCHEDULE" -> "DARK"
                else -> "DARK"
            }
            repository.updateSettings { it.copy(themeMode = nextMode) }
        }
    }

    fun updateWallpaper(wallpaperTheme: String) {
        viewModelScope.launch {
            repository.updateSettings { it.copy(wallpaperTheme = wallpaperTheme) }
        }
    }

    fun openCamera(fromChatId: String? = null, forStatus: Boolean = false) {
        _cameraSourceChatId.value = fromChatId
        _cameraForStatus.value = forStatus
        _currentScreen.value = AppScreen.CAMERA_STUDIO
    }

    fun openWallpaperPicker() {
        _currentScreen.value = AppScreen.WALLPAPER_PICKER
    }

    fun sendPhotoOrVideoMessage(
        chatId: String,
        caption: String,
        mediaType: String = "PHOTO",
        durationSeconds: Int = 0
    ) {
        viewModelScope.launch {
            repository.sendMessage(
                chatId = chatId,
                text = caption,
                mediaType = mediaType,
                mediaDuration = durationSeconds
            )
        }
    }

    fun createStatusStory(caption: String, bgHex: String = "#075E54") {
        viewModelScope.launch {
            repository.postStatus(text = caption, bgHex = bgHex)
        }
    }

    // PRIVACY DATASTORE METHODS
    fun updateReadReceipts(enabled: Boolean) {
        viewModelScope.launch {
            privacyPreferencesDataStore.setReadReceipts(enabled)
            repository.updateSettings { it.copy(readReceipts = enabled) }
        }
    }

    fun updateProfilePhotoVisibility(visibility: String) {
        viewModelScope.launch {
            privacyPreferencesDataStore.setProfilePhotoVisibility(visibility)
            repository.updateSettings { it.copy(privacyPhoto = visibility) }
        }
    }

    fun updateLastSeenVisibility(visibility: String) {
        viewModelScope.launch {
            privacyPreferencesDataStore.setLastSeenVisibility(visibility)
            repository.updateSettings { it.copy(privacyLastSeen = visibility) }
        }
    }

    fun updateOnlineStatusVisibility(visibility: String) {
        viewModelScope.launch {
            privacyPreferencesDataStore.setOnlineStatusVisibility(visibility)
        }
    }

    fun updateGroupsAddPermission(permission: String) {
        viewModelScope.launch {
            privacyPreferencesDataStore.setGroupsAddPermission(permission)
        }
    }

    fun updateDefaultMessageTimer(timer: String) {
        viewModelScope.launch {
            privacyPreferencesDataStore.setDefaultMessageTimer(timer)
        }
    }

    fun updatePrivacySettings(lastSeen: String, photo: String, readReceipts: Boolean) {
        viewModelScope.launch {
            privacyPreferencesDataStore.setLastSeenVisibility(lastSeen)
            privacyPreferencesDataStore.setProfilePhotoVisibility(photo)
            privacyPreferencesDataStore.setReadReceipts(readReceipts)
            repository.updateSettings {
                it.copy(
                    privacyLastSeen = lastSeen,
                    privacyPhoto = photo,
                    readReceipts = readReceipts
                )
            }
        }
    }

    // SIGNAL PROTOCOL END-TO-END ENCRYPTION (E2EE)
    fun getSafetyNumber(chatId: String, otherPhone: String): String {
        return firestoreSyncManager.signalCryptoEngine.getSafetyNumber(chatId, otherPhone)
    }

    fun getMyIdentityPublicKey(): String {
        return firestoreSyncManager.signalCryptoEngine.getMyIdentityPublicKeyBase64()
    }

    fun getMyIdentityFingerprint(): String {
        return firestoreSyncManager.signalCryptoEngine.getMyIdentityFingerprint()
    }

    fun openEncryptionKeysScreen() {
        _currentScreen.value = AppScreen.ENCRYPTION_KEYS
    }

    fun toggleFingerprintVerified(chatId: String) {
        val current = _verifiedChatFingerprints.value.toMutableSet()
        if (current.contains(chatId)) {
            current.remove(chatId)
        } else {
            current.add(chatId)
        }
        _verifiedChatFingerprints.value = current
        e2eeVerificationPrefs.edit().putStringSet("verified_chat_ids", current).apply()
    }

    fun getChatEncryptionFingerprints(): List<ChatEncryptionFingerprint> {
        val chats = activeChats.value
        val contacts = allContacts.value
        val verifiedSet = _verifiedChatFingerprints.value
        val myPhone = currentUser.value?.phone.orEmpty()

        if (chats.isEmpty()) {
            val demoList = listOf(
                Triple("session_moussa", "Moussa Diop", "+221 77 123 45 67"),
                Triple("session_aissatou", "Aïssatou Sow", "+221 78 234 56 78"),
                Triple("session_groupe_famille", "Groupe Famille Teranga", "Groupe sécurisé (6 participants)")
            )
            return demoList.mapIndexed { index, (cId, title, sub) ->
                val isGrp = index == 2
                val phone = if (isGrp) "+221770000000" else sub.replace(" ", "")
                val safety = firestoreSyncManager.signalCryptoEngine.getSafetyNumber(cId, phone)
                val hex = firestoreSyncManager.signalCryptoEngine.getSessionKeyFingerprint(cId, phone)
                val isVer = verifiedSet.contains(cId)
                ChatEncryptionFingerprint(
                    chatId = cId,
                    title = title,
                    subtitle = sub,
                    avatarUrl = title,
                    isGroup = isGrp,
                    safetyNumber = safety,
                    hexFingerprint = hex,
                    shortFingerprint = hex.take(11),
                    visualFingerprintColors = ChatEncryptionFingerprint.deriveVisualColors(hex),
                    ephemeralKeySnippet = "Curve25519-EPH-${(index + 1) * 382}",
                    ratchetStep = 4 + index * 2,
                    isVerified = isVer,
                    verifiedDate = if (isVer) "Aujourd'hui" else null,
                    totalMessagesEncrypted = (index + 1) * 37,
                    lastActiveTimestamp = System.currentTimeMillis() - (index * 7200000L)
                )
            }
        }

        return chats.map { chat ->
            val otherPhone = chat.creatorPhone.ifBlank {
                contacts.find { it.name.equals(chat.title, ignoreCase = true) }?.phone ?: "+221770000000"
            }
            val contact = contacts.find { it.phone == otherPhone || it.name.equals(chat.title, ignoreCase = true) }
            val title = if (chat.isGroup) chat.title else (contact?.name ?: chat.title.ifBlank { otherPhone })
            val subtitle = if (chat.isGroup) "Discussion chiffrée (${chat.membersCount} membres)" else otherPhone
            val safetyNumber = firestoreSyncManager.signalCryptoEngine.getSafetyNumber(chat.id, otherPhone)
            val hexFingerprint = firestoreSyncManager.signalCryptoEngine.getSessionKeyFingerprint(chat.id, otherPhone)
            val isVerified = verifiedSet.contains(chat.id)

            ChatEncryptionFingerprint(
                chatId = chat.id,
                title = title,
                subtitle = subtitle,
                avatarUrl = chat.avatarUrl.ifBlank { title },
                isGroup = chat.isGroup,
                safetyNumber = safetyNumber,
                hexFingerprint = hexFingerprint,
                shortFingerprint = hexFingerprint.take(11),
                visualFingerprintColors = ChatEncryptionFingerprint.deriveVisualColors(hexFingerprint),
                ephemeralKeySnippet = "Curve25519-EPH-${chat.id.takeLast(4).uppercase()}",
                ratchetStep = 8,
                isVerified = isVerified,
                verifiedDate = if (isVerified) "08/09/2026" else null,
                totalMessagesEncrypted = chat.unreadCount + 14,
                lastActiveTimestamp = chat.lastTimestamp
            )
        }
    }

    // TIKTOK LIVE STREAMING & DIRECT AUTORISÉ
    fun startHostingLive(title: String, category: LiveCategory) {
        val userName = currentUser.value?.name ?: "Créateur ADT"
        val userAvatar = currentUser.value?.name ?: "ADT"
        liveStreamManager.startHosting(
            title = title,
            category = category,
            hostName = userName,
            hostAvatar = userAvatar,
            isFrontCamera = true
        )
        _currentScreen.value = AppScreen.TIKTOK_LIVE
    }

    fun watchLiveStream(streamId: String) {
        liveStreamManager.watchStream(streamId)
        _currentScreen.value = AppScreen.TIKTOK_LIVE
    }

    fun sendLiveComment(text: String) {
        val userName = currentUser.value?.name ?: "Moi"
        val userAvatar = currentUser.value?.name ?: "Moi"
        liveStreamManager.sendComment(userName, userAvatar, text)
    }

    fun sendLiveGift(gift: LiveGift) {
        val userName = currentUser.value?.name ?: "Moi"
        val userAvatar = currentUser.value?.name ?: "Moi"
        liveStreamManager.sendGift(gift, userName, userAvatar)
    }

    fun sendLiveLike(xPercent: Float = 0.8f) {
        liveStreamManager.sendLike(xPercent)
    }

    fun toggleFollowLiveHost() {
        liveStreamManager.toggleFollowHost()
    }

    fun toggleLiveCamera() {
        liveStreamManager.toggleCamera()
    }

    fun toggleLiveMic() {
        liveStreamManager.toggleMic()
    }

    fun setLiveFilter(filterName: String) {
        liveStreamManager.setFilter(filterName)
    }

    fun setLiveBeautyLevel(level: Float) {
        liveStreamManager.setBeautyLevel(level)
    }

    fun toggleLivePkBattle() {
        liveStreamManager.togglePkBattle()
    }

    fun showEndSummaryDialog() {
        liveStreamManager.showEndSummaryDialog()
    }

    fun leaveLiveStream() {
        liveStreamManager.closeSession()
        _currentScreen.value = AppScreen.MAIN_TABS
    }

    // FIREBASE STORAGE ENCRYPTED CHAT BACKUP & RESTORE METHODS

    fun openChatBackup() {
        _currentScreen.value = AppScreen.CHAT_BACKUP
        val phone = currentUser.value?.phone.orEmpty()
        if (phone.isNotBlank()) {
            queryRemoteBackup(phone)
        }
    }

    fun performManualBackup() {
        val phone = currentUser.value?.phone.orEmpty().ifBlank { "+221770001122" }
        val settings = appSettings.value
        val includeMedia = settings?.backupIncludeMedia ?: false
        val wifiOnly = settings?.backupOnlyWifi ?: false
        viewModelScope.launch {
            backupManager.performBackup(
                userPhone = phone,
                includeMedia = includeMedia,
                wifiOnly = wifiOnly
            )
        }
    }

    fun restoreChatBackup() {
        val phone = currentUser.value?.phone.orEmpty().ifBlank { "+221770001122" }
        viewModelScope.launch {
            backupManager.restoreBackup(userPhone = phone)
        }
    }

    fun queryRemoteBackup(phone: String? = null) {
        val targetPhone = phone ?: currentUser.value?.phone.orEmpty().ifBlank { "+221770001122" }
        viewModelScope.launch {
            backupManager.queryRemoteBackup(targetPhone)
        }
    }

    fun updateAutoBackupFrequency(freq: String) {
        viewModelScope.launch {
            repository.updateSettings { it.copy(autoBackupFrequency = freq) }
            val wifiOnly = appSettings.value?.backupOnlyWifi ?: true
            ChatBackupScheduler.schedulePeriodicBackup(getApplication(), freq, wifiOnly)
            val phone = currentUser.value?.phone.orEmpty()
            if (phone.isNotBlank() && freq != "OFF") {
                backupManager.checkAndTriggerAutoBackup(phone)
            }
        }
    }

    fun updateBackupOnlyWifi(wifiOnly: Boolean) {
        viewModelScope.launch {
            repository.updateSettings { it.copy(backupOnlyWifi = wifiOnly) }
            val freq = appSettings.value?.autoBackupFrequency ?: "DAILY"
            ChatBackupScheduler.schedulePeriodicBackup(getApplication(), freq, wifiOnly)
        }
    }

    fun updateBackupIncludeMedia(includeMedia: Boolean) {
        viewModelScope.launch {
            repository.updateSettings { it.copy(backupIncludeMedia = includeMedia) }
        }
    }

    /**
     * Start background backup as a foreground service with live persistent notification
     */
    fun triggerBackgroundBackup() {
        val phone = currentUser.value?.phone.orEmpty().ifBlank { "+221770001122" }
        val settings = appSettings.value
        val includeMedia = settings?.backupIncludeMedia ?: false
        val wifiOnly = settings?.backupOnlyWifi ?: false
        ChatBackupScheduler.triggerImmediateBackgroundBackup(
            context = getApplication(),
            userPhone = phone,
            includeMedia = includeMedia,
            wifiOnly = wifiOnly
        )
    }

    /**
     * Cancel currently running background backup service
     */
    fun cancelBackgroundBackup() {
        ChatBackupBackgroundService.cancelBackup(getApplication())
    }

    fun resetBackupOperationState() {
        backupManager.resetState()
    }

    // TWO-STEP VERIFICATION (PIN & GOOGLE / ICLOUD ACCOUNT) METHODS

    fun openTwoStepVerification() {
        _currentScreen.value = AppScreen.TWO_STEP_VERIFICATION
    }

    fun enableTwoStepVerification(
        pin: String,
        accountType: RecoveryAccountType,
        email: String,
        onResult: (Boolean, String?) -> Unit
    ) {
        viewModelScope.launch {
            val result = twoStepVerificationManager.enableTwoStep(pin, accountType, email)
            if (result.isSuccess) {
                onResult(true, null)
            } else {
                onResult(false, result.exceptionOrNull()?.message ?: "Erreur d'activation")
            }
        }
    }

    fun disableTwoStepVerification(
        currentPin: String,
        onResult: (Boolean, String?) -> Unit
    ) {
        viewModelScope.launch {
            val result = twoStepVerificationManager.disableTwoStep(currentPin)
            if (result.isSuccess) {
                isAppLockedByTwoStep.value = false
                onResult(true, null)
            } else {
                onResult(false, result.exceptionOrNull()?.message ?: "Code PIN incorrect")
            }
        }
    }

    fun changeTwoStepPin(
        currentPin: String,
        newPin: String,
        onResult: (Boolean, String?) -> Unit
    ) {
        viewModelScope.launch {
            val result = twoStepVerificationManager.changePin(currentPin, newPin)
            if (result.isSuccess) {
                onResult(true, null)
            } else {
                onResult(false, result.exceptionOrNull()?.message ?: "Erreur de modification du PIN")
            }
        }
    }

    fun changeTwoStepRecoveryAccount(
        currentPin: String,
        accountType: RecoveryAccountType,
        newEmail: String,
        onResult: (Boolean, String?) -> Unit
    ) {
        viewModelScope.launch {
            val result = twoStepVerificationManager.changeRecoveryAccount(currentPin, accountType, newEmail)
            if (result.isSuccess) {
                onResult(true, null)
            } else {
                onResult(false, result.exceptionOrNull()?.message ?: "Erreur de mise à jour du compte")
            }
        }
    }

    fun verifyTwoStepPin(
        pin: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        viewModelScope.launch {
            when (val result = twoStepVerificationManager.verifyPin(pin)) {
                is PinVerificationResult.Success -> {
                    isAppLockedByTwoStep.value = false
                    onSuccess()
                }
                is PinVerificationResult.WrongPin -> {
                    onError("Code PIN incorrect. Tentatives restantes : ${result.remainingAttempts}")
                }
                is PinVerificationResult.LockedOut -> {
                    onError("Trop de tentatives infructueuses. Réessayez dans ${result.remainingSeconds}s")
                }
                is PinVerificationResult.NotConfigured -> {
                    isAppLockedByTwoStep.value = false
                    onSuccess()
                }
            }
        }
    }

    fun lockAppWithTwoStep() {
        if (twoStepVerificationState.value.isEnabled) {
            isAppLockedByTwoStep.value = true
        }
    }

    fun setRequireTwoStepPinOnLaunch(require: Boolean) {
        viewModelScope.launch {
            twoStepVerificationManager.setRequirePinOnLaunch(require)
        }
    }

    fun sendTwoStepRecoveryCode(onCodeSent: (code: String, destination: String) -> Unit) {
        viewModelScope.launch {
            val state = twoStepVerificationState.value
            val code = twoStepVerificationManager.generateRecoveryCode()
            val accountLabel = if (state.recoveryAccountType == RecoveryAccountType.GOOGLE) {
                "votre Compte Google (${state.recoveryEmail.ifBlank { "associé" }})"
            } else if (state.recoveryAccountType == RecoveryAccountType.ICLOUD) {
                "votre Compte iCloud (${state.recoveryEmail.ifBlank { "associé" }})"
            } else {
                "votre e-mail de secours"
            }
            twoStepRecoveryNotification.value = "Code de sécurité ADT Pro : $code envoyé à $accountLabel"
            onCodeSent(code, accountLabel)
        }
    }

    fun resetTwoStepPinWithRecovery(
        code: String,
        newPin: String,
        onResult: (Boolean, String?) -> Unit
    ) {
        viewModelScope.launch {
            val result = twoStepVerificationManager.resetPinWithRecoveryCode(code, newPin)
            if (result.isSuccess) {
                isAppLockedByTwoStep.value = false
                twoStepRecoveryNotification.value = null
                onResult(true, null)
            } else {
                onResult(false, result.exceptionOrNull()?.message ?: "Code invalide")
            }
        }
    }

    fun dismissRecoveryNotification() {
        twoStepRecoveryNotification.value = null
    }

    // ==========================================
    // BIOMETRIC AUTHENTICATION MANAGEMENT
    // ==========================================

    fun unlockAppWithBiometric() {
        isAppLockedByBiometric.value = false
        isAppLockedByTwoStep.value = false
        biometricAuthErrorMessage.value = null
    }

    fun lockAppWithBiometric() {
        if (privacyPreferences.value.isBiometricEnabled) {
            isAppLockedByBiometric.value = true
        }
    }

    fun setBiometricLockEnabled(enabled: Boolean) {
        viewModelScope.launch {
            privacyPreferencesDataStore.setBiometricEnabled(enabled)
            if (!enabled) {
                isAppLockedByBiometric.value = false
                biometricAuthErrorMessage.value = null
            }
        }
    }

    fun setBiometricLockTimeout(timeout: String) {
        viewModelScope.launch {
            privacyPreferencesDataStore.setBiometricTimeout(timeout)
        }
    }

    fun setBiometricHideNotifications(hide: Boolean) {
        viewModelScope.launch {
            privacyPreferencesDataStore.setBiometricHideNotifications(hide)
        }
    }

    fun setBiometricAuthErrorMessage(message: String?) {
        biometricAuthErrorMessage.value = message
    }

    // ==========================================
    // LOCKED CHATS MANAGEMENT (BIOMETRIC SECURITY)
    // ==========================================
    val isLockedChatsSessionUnlocked = MutableStateFlow(false)
    val lockedChatsAuthErrorMessage = MutableStateFlow<String?>(null)

    fun unlockLockedChatsSession() {
        isLockedChatsSessionUnlocked.value = true
        lockedChatsAuthErrorMessage.value = null
    }

    fun lockLockedChatsSession() {
        isLockedChatsSessionUnlocked.value = false
        lockedChatsAuthErrorMessage.value = null
    }

    fun setChatLocked(chatId: String, isLocked: Boolean) {
        viewModelScope.launch {
            repository.setChatLocked(chatId, isLocked)
        }
    }

    fun openLockedChatsScreen() {
        _currentScreen.value = AppScreen.LOCKED_CHATS
    }

    fun onAppBackgrounded() {
        lastBackgroundTimestamp = System.currentTimeMillis()
        // Lock locked chats session on background for strict confidentiality
        lockLockedChatsSession()
    }

    fun onAppForegrounded() {
        if (!privacyPreferences.value.isBiometricEnabled) return
        if (isAppLockedByBiometric.value) return

        val timeoutStr = privacyPreferences.value.biometricTimeout
        val timeoutMs = when (timeoutStr) {
            "IMMEDIATELY" -> 0L
            "1_MIN" -> 60_000L
            "5_MIN" -> 300_000L
            "15_MIN" -> 900_000L
            "1_HOUR" -> 3_600_000L
            else -> 0L
        }

        if (lastBackgroundTimestamp > 0L) {
            val elapsed = System.currentTimeMillis() - lastBackgroundTimestamp
            if (elapsed >= timeoutMs) {
                isAppLockedByBiometric.value = true
            }
        }

        if (syncEnergyMode.value == SyncEnergyMode.BATTERY_SAVER) {
            triggerImmediateManualSync()
        }
        updateBatteryState()
    }

    fun updateBatteryState() {
        try {
            val intentFilter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            val batteryStatus = getApplication<Application>().registerReceiver(null, intentFilter)
            val level = batteryStatus?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = batteryStatus?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
            val batteryPct = if (level >= 0 && scale > 0) (level * 100 / scale) else 85
            deviceBatteryLevel.value = batteryPct

            val status = batteryStatus?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
            val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
            isDeviceCharging.value = charging

            if (autoBatterySaverOnLowBattery.value && batteryPct in 1..20 && !charging && syncEnergyMode.value == SyncEnergyMode.HIGH_PERFORMANCE) {
                setSyncEnergyMode(SyncEnergyMode.BATTERY_SAVER)
            }
        } catch (e: Exception) {
            android.util.Log.w("AdtViewModel", "Could not read battery state: ${e.message}")
        }
    }

    fun setSyncEnergyMode(mode: SyncEnergyMode) {
        syncEnergyMode.value = mode
        syncEnergyPrefs.edit().putString("sync_energy_mode", mode.id).apply()
        val userPhone = currentUser.value?.phone ?: ""
        firestoreSyncManager.setEnergyMode(mode, userPhone)
        ChatBackupScheduler.adjustBackgroundScheduleForBatteryMode(getApplication(), mode, syncIntervalMinutes.value)
    }

    fun toggleAutoBatterySaver(enabled: Boolean) {
        autoBatterySaverOnLowBattery.value = enabled
        syncEnergyPrefs.edit().putBoolean("auto_battery_saver_on_low_battery", enabled).apply()
        updateBatteryState()
    }

    fun triggerImmediateManualSync() {
        if (isManualSyncing.value) return
        viewModelScope.launch {
            isManualSyncing.value = true
            val userPhone = currentUser.value?.phone ?: ""
            firestoreSyncManager.triggerManualSync(userPhone)
            val now = System.currentTimeMillis()
            lastManualSyncTimestamp.value = now
            isManualSyncing.value = false
        }
    }

    fun setSyncIntervalMinutes(minutes: Int) {
        val clamped = minutes.coerceIn(5, 120)
        syncIntervalMinutes.value = clamped
        syncEnergyPrefs.edit().putInt("sync_interval_minutes", clamped).apply()
        val userPhone = currentUser.value?.phone ?: ""
        firestoreSyncManager.setPollingInterval(clamped, userPhone)
        ChatBackupScheduler.adjustBackgroundScheduleForBatteryMode(getApplication(), syncEnergyMode.value, clamped)
    }

    // Storage Management Methods
    fun openStorageManagement() {
        _currentScreen.value = AppScreen.STORAGE_MANAGEMENT
        refreshStorageOverview()
    }

    fun refreshStorageOverview() {
        viewModelScope.launch {
            isStorageLoading.value = true
            try {
                val overview = storageManager.computeStorageOverview()
                storageOverview.value = overview
                selectedChatForStorage.value?.let { currentSelected ->
                    selectedChatForStorage.value = overview.chatsStorage.find { it.chatId == currentSelected.chatId }
                }
            } catch (e: Exception) {
                android.util.Log.e("AdtViewModel", "Error refreshing storage overview: ${e.message}")
            } finally {
                isStorageLoading.value = false
            }
        }
    }

    fun selectChatForStorage(chat: ChatStorageConsumption?) {
        selectedChatForStorage.value = chat
    }

    fun deleteStorageAttachments(messageIds: Collection<String>) {
        if (messageIds.isEmpty()) return
        viewModelScope.launch {
            isStorageLoading.value = true
            try {
                val freedBytes = storageManager.deleteMediaAttachments(messageIds)
                storageActionFeedback.value = "Espace libéré avec succès : ${formatBytes(freedBytes)} (${messageIds.size} pièce(s) jointe(s))"
                refreshStorageOverview()
            } catch (e: Exception) {
                storageActionFeedback.value = "Erreur lors de la suppression : ${e.message}"
            } finally {
                isStorageLoading.value = false
            }
        }
    }

    fun clearStorageForChat(chatId: String, mediaTypes: Set<String> = emptySet()) {
        viewModelScope.launch {
            isStorageLoading.value = true
            try {
                val freedBytes = storageManager.clearChatMedia(chatId, mediaTypes)
                storageActionFeedback.value = "Médias de la discussion purgés : ${formatBytes(freedBytes)} libérés"
                refreshStorageOverview()
            } catch (e: Exception) {
                storageActionFeedback.value = "Erreur : ${e.message}"
            } finally {
                isStorageLoading.value = false
            }
        }
    }

    fun clearStorageCache() {
        viewModelScope.launch {
            isStorageLoading.value = true
            try {
                val freedBytes = storageManager.clearAppCache()
                storageActionFeedback.value = "Cache d'application vidé : ${formatBytes(freedBytes)} libérés"
                refreshStorageOverview()
            } catch (e: Exception) {
                storageActionFeedback.value = "Erreur lors du vidage du cache : ${e.message}"
            } finally {
                isStorageLoading.value = false
            }
        }
    }

    fun clearStorageFeedback() {
        storageActionFeedback.value = null
    }

    override fun onCleared() {
        super.onCleared()
        textToSpeechManager.shutdown()
        callManager.endCall()
    }
}
