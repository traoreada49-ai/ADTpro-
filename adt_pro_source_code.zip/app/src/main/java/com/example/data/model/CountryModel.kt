package com.example.data.model

data class CountryItem(
    val name: String,
    val dialCode: String,
    val flagEmoji: String,
    val exampleNumber: String,
    val defaultOperators: List<String>
)

object CountryData {
    val supportedCountries = listOf(
        CountryItem("Sénégal", "+221", "🇸🇳", "77 123 45 67", listOf("Orange", "Moov Africa", "Free", "Wave")),
        CountryItem("RD Congo", "+243", "🇨🇩", "81 234 56 78", listOf("Vodacom", "Orange", "Airtel", "Africell")),
        CountryItem("Kenya", "+254", "🇰🇪", "712 345 678", listOf("Safaricom", "Airtel", "Telkom Kenya")),
        CountryItem("Tanzanie", "+255", "🇹🇿", "712 345 678", listOf("Vodacom", "Airtel", "Tigo", "Halotel")),
        CountryItem("Mauritanie", "+222", "🇲🇷", "45 12 34 56", listOf("Mauritel", "Chinguitel", "Mattel")),
        CountryItem("Cameroun", "+237", "🇨🇲", "699 12 34 56", listOf("Orange", "MTN", "Camtel", "Nexttel")),
        CountryItem("Mali", "+223", "🇲🇱", "66 12 34 56", listOf("Orange", "Moov Africa", "Telecel")),
        CountryItem("Côte d'Ivoire", "+225", "🇨🇮", "07 12 34 56 78", listOf("Orange", "Moov Africa", "MTN", "Wave")),
        CountryItem("Burkina Faso", "+226", "🇧🇫", "70 12 34 56", listOf("Orange", "Moov Africa", "Telecel")),
        CountryItem("Guinée", "+224", "🇬🇳", "620 12 34 56", listOf("Orange", "MTN", "Cellcom")),
        CountryItem("Niger", "+227", "🇳🇪", "90 12 34 56", listOf("Orange", "Moov Africa", "Airtel", "Niger Telecom")),
        CountryItem("Togo", "+228", "🇹🇬", "90 12 34 56", listOf("Moov Africa", "Togocom")),
        CountryItem("Bénin", "+229", "🇧🇯", "97 12 34 56", listOf("Moov Africa", "MTN", "Celtiis")),
        CountryItem("Congo (Brazzaville)", "+242", "🇨🇬", "06 123 45 67", listOf("MTN", "Airtel")),
        CountryItem("Gabon", "+241", "🇬🇦", "074 12 34 56", listOf("Moov Africa", "Airtel")),
        CountryItem("Tchad", "+235", "🇹🇩", "66 12 34 56", listOf("Airtel", "Moov Africa")),
        CountryItem("Maurice", "+230", "🇲🇺", "57 12 34 56", listOf("Orange", "Emtel", "CHi")),
        CountryItem("Ghana", "+233", "🇬🇭", "24 123 4567", listOf("MTN", "Telecel", "AirtelTigo")),
        CountryItem("Nigeria", "+234", "🇳🇬", "803 123 4567", listOf("MTN", "Airtel", "Glo", "9mobile")),
        CountryItem("France", "+33", "🇫🇷", "06 12 34 56 78", listOf("Orange", "SFR", "Bouygues", "Free")),
        CountryItem("Espagne", "+34", "🇪🇸", "612 345 678", listOf("Orange", "Movistar", "Vodafone", "Yoigo")),
        CountryItem("États-Unis", "+1", "🇺🇸", "202 555 0123", listOf("AT&T", "Verizon", "T-Mobile")),
        CountryItem("Canada", "+1", "🇨🇦", "416 555 0199", listOf("Rogers", "Bell", "Telus")),
        CountryItem("Belgique", "+32", "🇧🇪", "470 12 34 56", listOf("Proximus", "Orange", "Base")),
        CountryItem("Suisse", "+41", "🇨🇭", "78 123 45 67", listOf("Swisscom", "Sunrise", "Salt")),
        CountryItem("Royaume-Uni", "+44", "🇬🇧", "7911 123456", listOf("EE", "Vodafone", "O2", "Three")),
        CountryItem("Allemagne", "+49", "🇩🇪", "151 12345678", listOf("Telekom", "Vodafone", "O2")),
        CountryItem("Mexique", "+52", "🇲🇽", "55 1234 5678", listOf("Telcel", "AT&T", "Movistar")),
        CountryItem("Brésil", "+55", "🇧🇷", "11 91234 5678", listOf("Vivo", "Claro", "TIM")),
        CountryItem("Colombie", "+57", "🇨🇴", "300 123 4567", listOf("Claro", "Tigo", "Movistar")),
        CountryItem("Australie", "+61", "🇦🇺", "412 345 678", listOf("Telstra", "Optus", "Vodafone")),
        CountryItem("Indonésie", "+62", "🇮🇩", "812 3456 7890", listOf("Telkomsel", "Indosat", "XL Axiata")),
        CountryItem("Kazakhstan", "+7", "🇰🇿", "701 123 45 67", listOf("Beeline", "Kcell", "Tele2")),
        CountryItem("Russie", "+7", "🇷🇺", "912 345 67 89", listOf("MTS", "MegaFon", "Beeline", "Tele2")),
        CountryItem("Chine", "+86", "🇨🇳", "138 0013 8000", listOf("China Mobile", "China Telecom", "China Unicom")),
        CountryItem("Japon", "+81", "🇯🇵", "90 1234 5678", listOf("NTT Docomo", "SoftBank", "au", "Rakuten")),
        CountryItem("Corée du Sud", "+82", "🇰🇷", "10 1234 5678", listOf("SK Telecom", "KT", "LG U+")),
        CountryItem("Turquie", "+90", "🇹🇷", "532 123 45 67", listOf("Turkcell", "Vodafone", "Türk Telekom")),
        CountryItem("Inde", "+91", "🇮🇳", "98123 45678", listOf("Jio", "Airtel", "Vi", "BSNL")),
        CountryItem("Arabie Saoudite", "+966", "🇸🇦", "50 123 4567", listOf("STC", "Mobily", "Zain")),
        CountryItem("Émirats Arabes Unis", "+971", "🇦🇪", "50 123 4567", listOf("e& (Etisalat)", "du")),
        CountryItem("Qatar", "+974", "🇶🇦", "3312 3456", listOf("Ooredoo", "Vodafone")),
        CountryItem("Maroc", "+212", "🇲🇦", "612 34 56 78", listOf("Maroc Telecom", "Orange", "inwi")),
        CountryItem("Algérie", "+213", "🇩🇿", "550 12 34 56", listOf("Djezzy", "Mobilis", "Ooredoo")),
        CountryItem("Madagascar", "+261", "🇲🇬", "34 12 345 67", listOf("Orange", "Telma", "Airtel")),
        CountryItem("Rwanda", "+250", "🇷🇼", "788 123 456", listOf("MTN", "Airtel")),
        CountryItem("Burundi", "+257", "🇧🇮", "79 123 456", listOf("Econet", "Lumitel")),
        CountryItem("Centrafrique", "+236", "🇨🇫", "75 12 34 56", listOf("Orange", "Telecel")),
        CountryItem("Comores", "+269", "🇰🇲", "32 12 345", listOf("Comores Telecom", "Telma")),
        CountryItem("Djibouti", "+253", "🇩🇯", "77 12 34 56", listOf("Djibouti Telecom")),
        CountryItem("Guinée équatoriale", "+240", "🇬🇶", "222 123 456", listOf("Getesa", "Muni")),
        CountryItem("Cap-Vert", "+238", "🇨🇻", "991 23 45", listOf("CV Movel", "Unitel T+")),
        CountryItem("Italie", "+39", "🇮🇹", "312 345 6789", listOf("TIM", "Vodafone", "WindTre", "Iliad")),
        CountryItem("Portugal", "+351", "🇵🇹", "912 345 678", listOf("MEO", "NOS", "Vodafone")),
        CountryItem("Pays-Bas", "+31", "🇳🇱", "6 12345678", listOf("KPN", "Vodafone", "Odido")),
        CountryItem("Haïti", "+509", "🇭🇹", "34 12 3456", listOf("Digicel", "Natcom")),
        CountryItem("Éthiopie", "+251", "🇪🇹", "91 123 4567", listOf("Ethio Telecom", "Safaricom")),
        CountryItem("Égypte", "+20", "🇪🇬", "10 1234 5678", listOf("Vodafone", "Orange", "Etisalat (e&)", "WE")),
        CountryItem("Norvège", "+47", "🇳🇴", "912 34 567", listOf("Telenor", "Telia", "Ice")),
        CountryItem("Suède", "+46", "🇸🇪", "70 123 45 67", listOf("Telia", "Tele2", "Telenor", "Tre")),
        CountryItem("Israël", "+972", "🇮🇱", "50 123 4567", listOf("Cellcom", "Partner", "Pelephone", "Hot Mobile")),
        CountryItem("Pakistan", "+92", "🇵🇰", "300 1234567", listOf("Jazz", "Telenor", "Zong", "Ufone")),
        CountryItem("Panama", "+507", "🇵🇦", "6123 4567", listOf("+Móvil", "Tigo", "Digicel"))
    )

    fun normalize(text: String): String {
        return text.lowercase()
            .replace("é", "e")
            .replace("è", "e")
            .replace("ê", "e")
            .replace("ë", "e")
            .replace("à", "a")
            .replace("á", "a")
            .replace("â", "a")
            .replace("î", "i")
            .replace("ï", "i")
            .replace("ô", "o")
            .replace("ö", "o")
            .replace("ù", "u")
            .replace("ú", "u")
            .replace("ü", "u")
            .replace("ç", "c")
            .replace("l'", "")
            .replace("d'", "")
            .trim()
    }

    fun matchesSearch(item: CountryItem, query: String): Boolean {
        if (query.isBlank()) return true
        val cleanQuery = normalize(query)
        val cleanName = normalize(item.name)
        val cleanDial = item.dialCode.replace("+", "").trim()
        val queryDial = query.replace("+", "").trim()

        return cleanName.contains(cleanQuery) ||
                item.name.contains(query, ignoreCase = true) ||
                item.dialCode.contains(query) ||
                (queryDial.isNotBlank() && cleanDial.startsWith(queryDial))
    }

    fun findByDialCode(code: String): CountryItem? {
        val clean = if (code.startsWith("+")) code else "+$code"
        return supportedCountries.firstOrNull { it.dialCode == clean }
    }

    /**
     * Auto-detect country and remaining phone number if input starts with a known international dial code
     * (e.g. +1, +33, +221, +225, +243, or 00...). Only activates when user explicitly enters international prefix (+ or 00),
     * avoiding unwanted switches when entering ordinary local subscriber digits.
     */
    fun detectCountryAndNumber(input: String): Pair<CountryItem, String>? {
        val trimmed = input.trim()
        val hasInternationalPrefix = trimmed.startsWith("+") || trimmed.startsWith("00")
        if (!hasInternationalPrefix) {
            return null
        }
        val sanitized = trimmed
            .replace(" ", "")
            .replace("(", "")
            .replace(")", "")
            .replace("-", "")
            .replace(".", "")
        val withPlus = if (sanitized.startsWith("+")) sanitized else "+" + sanitized.substring(2)
        
        // Sort descending by dial code length to match longest prefix first
        for (country in supportedCountries.sortedByDescending { it.dialCode.length }) {
            if (withPlus.startsWith(country.dialCode) && withPlus.length > country.dialCode.length) {
                var remaining = withPlus.substring(country.dialCode.length)
                // If remaining starts with leading 0 (e.g. +33 06...), strip the trunk prefix
                if (remaining.startsWith("0") && remaining.length > 1) {
                    remaining = remaining.removePrefix("0")
                }
                return Pair(country, remaining)
            }
        }
        return null
    }
}
