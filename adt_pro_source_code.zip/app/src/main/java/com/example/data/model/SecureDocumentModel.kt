package com.example.data.model

import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * Supported document formats for secure sharing in ADT Pro chats.
 */
enum class DocumentType(val extension: String, val displayName: String, val mimeType: String) {
    PDF("pdf", "Document PDF", "application/pdf"),
    DOCX("docx", "Document Word", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"),
    XLSX("xlsx", "Tableur Excel", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"),
    PPTX("pptx", "Présentation PowerPoint", "application/vnd.openxmlformats-officedocument.presentationml.presentation"),
    TXT("txt", "Texte Brut", "text/plain"),
    OTHER("doc", "Document Bureau", "application/octet-stream");

    companion object {
        fun fromFileName(fileName: String): DocumentType {
            val ext = fileName.substringAfterLast('.', "").lowercase()
            return when (ext) {
                "pdf" -> PDF
                "docx", "doc", "odt" -> DOCX
                "xlsx", "xls", "csv" -> XLSX
                "pptx", "ppt", "odp" -> PPTX
                "txt" -> TXT
                else -> OTHER
            }
        }

        fun fromMimeType(mime: String): DocumentType {
            return when {
                mime.contains("pdf", ignoreCase = true) -> PDF
                mime.contains("word", ignoreCase = true) || mime.contains("officedocument.wordprocessingml", ignoreCase = true) -> DOCX
                mime.contains("excel", ignoreCase = true) || mime.contains("spreadsheetml", ignoreCase = true) || mime.contains("csv", ignoreCase = true) -> XLSX
                mime.contains("powerpoint", ignoreCase = true) || mime.contains("presentationml", ignoreCase = true) -> PPTX
                mime.contains("text", ignoreCase = true) -> TXT
                else -> OTHER
            }
        }
    }
}

/**
 * Status of server-side security scanning.
 */
enum class DocumentScanStatus(val label: String) {
    PENDING("En attente d'analyse"),
    SCANNING("Analyse antivirus en cours..."),
    SAFE("Sécurisé • Aucune menace"),
    THREAT_DETECTED("Alerte • Fichier suspect"),
    WARNING("Avertissement de sécurité")
}

/**
 * Status of file upload to Firebase Storage.
 */
enum class DocumentUploadStatus {
    PENDING,
    UPLOADING,
    UPLOADED,
    FAILED
}

/**
 * Detailed report produced by the server-side security scanning engine.
 */
data class DocumentScanResult(
    val scannedAt: Long = System.currentTimeMillis(),
    val scannerEngine: String = "Google Cloud Armor & ADT Shield v3.4",
    val threatScore: Int = 0, // 0 = 100% Safe, 100 = Severe Threat
    val threatsFound: List<String> = emptyList(),
    val signatureVerified: Boolean = true,
    val macroThreatDetected: Boolean = false,
    val sha256Hash: String = "",
    val summary: String = "Fichier validé. Aucune macro malveillante ni payload suspect détecté."
) {
    fun toJson(): JSONObject {
        val json = JSONObject()
        json.put("scannedAt", scannedAt)
        json.put("scannerEngine", scannerEngine)
        json.put("threatScore", threatScore)
        val arr = JSONArray()
        threatsFound.forEach { arr.put(it) }
        json.put("threatsFound", arr)
        json.put("signatureVerified", signatureVerified)
        json.put("macroThreatDetected", macroThreatDetected)
        json.put("sha256Hash", sha256Hash)
        json.put("summary", summary)
        return json
    }

    companion object {
        fun fromJson(json: JSONObject): DocumentScanResult {
            val threats = mutableListOf<String>()
            val arr = json.optJSONArray("threatsFound")
            if (arr != null) {
                for (i in 0 until arr.length()) {
                    threats.add(arr.optString(i))
                }
            }
            return DocumentScanResult(
                scannedAt = json.optLong("scannedAt", System.currentTimeMillis()),
                scannerEngine = json.optString("scannerEngine", "Google Cloud Armor & ADT Shield v3.4"),
                threatScore = json.optInt("threatScore", 0),
                threatsFound = threats,
                signatureVerified = json.optBoolean("signatureVerified", true),
                macroThreatDetected = json.optBoolean("macroThreatDetected", false),
                sha256Hash = json.optString("sha256Hash", ""),
                summary = json.optString("summary", "Fichier validé.")
            )
        }
    }
}

/**
 * Complete model representing a document shared securely in chat.
 */
data class SecureDocument(
    val id: String = UUID.randomUUID().toString(),
    val fileName: String,
    val fileType: DocumentType = DocumentType.fromFileName(fileName),
    val mimeType: String = fileType.mimeType,
    val fileSizeBytes: Long,
    val formattedSize: String = formatFileSize(fileSizeBytes),
    val pageCount: Int = 1,
    val localUri: String? = null,
    val storagePath: String = "",
    val downloadUrl: String = "",
    val sha256Hash: String = "",
    val encryptionInfo: String = "AES-256-GCM / TLS 1.3 Firebase Storage",
    val uploadStatus: DocumentUploadStatus = DocumentUploadStatus.UPLOADED,
    val scanStatus: DocumentScanStatus = DocumentScanStatus.SAFE,
    val scanResult: DocumentScanResult = DocumentScanResult(sha256Hash = sha256Hash),
    val caption: String = ""
) {
    /**
     * Serializes this document model into a JSON string to store in MessageEntity.mediaUrl.
     */
    fun serialize(): String {
        val json = JSONObject()
        json.put("id", id)
        json.put("fileName", fileName)
        json.put("fileType", fileType.name)
        json.put("mimeType", mimeType)
        json.put("fileSizeBytes", fileSizeBytes)
        json.put("formattedSize", formattedSize)
        json.put("pageCount", pageCount)
        json.put("localUri", localUri ?: "")
        json.put("storagePath", storagePath)
        json.put("downloadUrl", downloadUrl)
        json.put("sha256Hash", sha256Hash)
        json.put("encryptionInfo", encryptionInfo)
        json.put("uploadStatus", uploadStatus.name)
        json.put("scanStatus", scanStatus.name)
        json.put("scanResult", scanResult.toJson())
        json.put("caption", caption)
        return json.toString()
    }

    companion object {
        fun deserialize(raw: String?): SecureDocument? {
            if (raw.isNullOrBlank()) return null
            return try {
                val json = JSONObject(raw)
                val typeName = json.optString("fileType", "PDF")
                val fileType = try {
                    DocumentType.valueOf(typeName)
                } catch (e: Exception) {
                    DocumentType.fromFileName(json.optString("fileName", "doc.pdf"))
                }
                val uploadStatusStr = json.optString("uploadStatus", "UPLOADED")
                val uploadStatus = try {
                    DocumentUploadStatus.valueOf(uploadStatusStr)
                } catch (e: Exception) {
                    DocumentUploadStatus.UPLOADED
                }
                val scanStatusStr = json.optString("scanStatus", "SAFE")
                val scanStatus = try {
                    DocumentScanStatus.valueOf(scanStatusStr)
                } catch (e: Exception) {
                    DocumentScanStatus.SAFE
                }
                val scanObj = json.optJSONObject("scanResult")
                val scanResult = if (scanObj != null) {
                    DocumentScanResult.fromJson(scanObj)
                } else {
                    DocumentScanResult(sha256Hash = json.optString("sha256Hash", ""))
                }

                SecureDocument(
                    id = json.optString("id", UUID.randomUUID().toString()),
                    fileName = json.optString("fileName", "Document"),
                    fileType = fileType,
                    mimeType = json.optString("mimeType", fileType.mimeType),
                    fileSizeBytes = json.optLong("fileSizeBytes", 0L),
                    formattedSize = json.optString("formattedSize", "1.0 Mo"),
                    pageCount = json.optInt("pageCount", 1),
                    localUri = json.optString("localUri").ifBlank { null },
                    storagePath = json.optString("storagePath", ""),
                    downloadUrl = json.optString("downloadUrl", ""),
                    sha256Hash = json.optString("sha256Hash", ""),
                    encryptionInfo = json.optString("encryptionInfo", "AES-256-GCM / TLS 1.3"),
                    uploadStatus = uploadStatus,
                    scanStatus = scanStatus,
                    scanResult = scanResult,
                    caption = json.optString("caption", "")
                )
            } catch (e: Exception) {
                null
            }
        }

        fun formatFileSize(bytes: Long): String {
            if (bytes <= 0) return "0 Ko"
            val kb = bytes / 1024.0
            val mb = kb / 1024.0
            return when {
                mb >= 1.0 -> String.format(java.util.Locale.US, "%.1f Mo", mb)
                kb >= 1.0 -> String.format(java.util.Locale.US, "%.0f Ko", kb)
                else -> "$bytes o"
            }
        }
    }
}

/**
 * Pre-defined verified enterprise documents ready to be tested and shared in chat.
 */
object SampleCorporateDocuments {
    val samples = listOf(
        SecureDocument(
            id = "doc_sample_1",
            fileName = "Contrat_Partenariat_Entreprises_ADT.pdf",
            fileType = DocumentType.PDF,
            mimeType = "application/pdf",
            fileSizeBytes = 2_450_000L,
            formattedSize = "2.4 Mo",
            pageCount = 8,
            storagePath = "chats/corporate/documents/doc_sample_1/Contrat_Partenariat_Entreprises_ADT.pdf",
            downloadUrl = "https://firebasestorage.googleapis.com/v0/b/adt-pro-social.appspot.com/o/documents%2FContrat_Partenariat.pdf?alt=media",
            sha256Hash = "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
            encryptionInfo = "Chiffré de bout en bout • AES-256-GCM",
            uploadStatus = DocumentUploadStatus.UPLOADED,
            scanStatus = DocumentScanStatus.SAFE,
            scanResult = DocumentScanResult(
                threatScore = 0,
                threatsFound = emptyList(),
                signatureVerified = true,
                macroThreatDetected = false,
                sha256Hash = "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
                summary = "PDF Certifié ISO 32000. Intégrité vérifiée, aucune macro ni script exécutable."
            ),
            caption = "Contrat officiel de partenariat ADT Pro pour validation bilatérale."
        ),
        SecureDocument(
            id = "doc_sample_2",
            fileName = "Tableau_Bord_Financier_Afrique_2026.xlsx",
            fileType = DocumentType.XLSX,
            mimeType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            fileSizeBytes = 1_180_000L,
            formattedSize = "1.2 Mo",
            pageCount = 4, // sheets
            storagePath = "chats/corporate/documents/doc_sample_2/Tableau_Bord_Financier_Afrique_2026.xlsx",
            downloadUrl = "https://firebasestorage.googleapis.com/v0/b/adt-pro-social.appspot.com/o/documents%2FTableau_Financier.xlsx?alt=media",
            sha256Hash = "8f434346648f6b96df89dda901c5176b10a6d83961dd3c1ac88b59b2dc327aa4",
            encryptionInfo = "Chiffré au repos • Google Cloud Storage",
            uploadStatus = DocumentUploadStatus.UPLOADED,
            scanStatus = DocumentScanStatus.SAFE,
            scanResult = DocumentScanResult(
                threatScore = 0,
                threatsFound = emptyList(),
                signatureVerified = true,
                macroThreatDetected = false,
                sha256Hash = "8f434346648f6b96df89dda901c5176b10a6d83961dd3c1ac88b59b2dc327aa4",
                summary = "Classeur Excel OpenXML validé. Signatures numériques de formules conformes."
            ),
            caption = "Synthèse financière et prévisionnel budgétaire Q3/Q4."
        ),
        SecureDocument(
            id = "doc_sample_3",
            fileName = "Cahier_des_Charges_Fibre_Optique.docx",
            fileType = DocumentType.DOCX,
            mimeType = "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            fileSizeBytes = 890_000L,
            formattedSize = "890 Ko",
            pageCount = 12,
            storagePath = "chats/corporate/documents/doc_sample_3/Cahier_des_Charges_Fibre_Optique.docx",
            downloadUrl = "https://firebasestorage.googleapis.com/v0/b/adt-pro-social.appspot.com/o/documents%2FCahier_Charges.docx?alt=media",
            sha256Hash = "1a8565fd2a96cf2c70a694f997724483a4ff98864cfb107616231362eacda7a2",
            encryptionInfo = "Chiffré de bout en bout • AES-256",
            uploadStatus = DocumentUploadStatus.UPLOADED,
            scanStatus = DocumentScanStatus.SAFE,
            scanResult = DocumentScanResult(
                threatScore = 0,
                threatsFound = emptyList(),
                signatureVerified = true,
                macroThreatDetected = false,
                sha256Hash = "1a8565fd2a96cf2c70a694f997724483a4ff98864cfb107616231362eacda7a2",
                summary = "Spécifications techniques vérifiées. Aucun composant OLE ou macro VBA externe."
            ),
            caption = "Architecture réseau et déploiement fibre optique régionale."
        ),
        SecureDocument(
            id = "doc_sample_4",
            fileName = "Presentation_Investisseurs_Fintech.pptx",
            fileType = DocumentType.PPTX,
            mimeType = "application/vnd.openxmlformats-officedocument.presentationml.presentation",
            fileSizeBytes = 4_650_000L,
            formattedSize = "4.6 Mo",
            pageCount = 18,
            storagePath = "chats/corporate/documents/doc_sample_4/Presentation_Investisseurs_Fintech.pptx",
            downloadUrl = "https://firebasestorage.googleapis.com/v0/b/adt-pro-social.appspot.com/o/documents%2FPresentation_Fintech.pptx?alt=media",
            sha256Hash = "4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a",
            encryptionInfo = "Chiffré au repos • Google Cloud Storage",
            uploadStatus = DocumentUploadStatus.UPLOADED,
            scanStatus = DocumentScanStatus.SAFE,
            scanResult = DocumentScanResult(
                threatScore = 0,
                threatsFound = emptyList(),
                signatureVerified = true,
                macroThreatDetected = false,
                sha256Hash = "4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a",
                summary = "Support PowerPoint validé. Médias intégrés analysés sans vulnérabilité."
            ),
            caption = "Deck de présentation stratégique pour le tour de table d'investissement."
        )
    )
}
