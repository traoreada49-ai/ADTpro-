package com.example.data.notification

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat
import com.example.MainActivity

/**
 * Manages system notification channels and posting rich notifications for missed and incoming calls,
 * ensuring users never miss critical audio/video communications even when the application is backgrounded or closed.
 */
object CallNotificationHelper {

    const val CHANNEL_MISSED_CALLS_ID = "adt_missed_calls_channel"
    const val CHANNEL_INCOMING_CALLS_ID = "adt_incoming_calls_channel"

    private const val NOTIFICATION_BASE_ID = 5000

    fun createNotificationChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            // Channel for missed calls
            val missedCallsChannel = NotificationChannel(
                CHANNEL_MISSED_CALLS_ID,
                "Appels manqués",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Notifications pour les appels audio et vidéo manqués"
                enableLights(true)
                enableVibration(true)
                setShowBadge(true)
            }
            notificationManager.createNotificationChannel(missedCallsChannel)

            // Channel for incoming calls in background
            val incomingCallsChannel = NotificationChannel(
                CHANNEL_INCOMING_CALLS_ID,
                "Appels entrants",
                NotificationManager.IMPORTANCE_MAX
            ).apply {
                description = "Alertes prioritaires pour les appels vidéo et audio entrants"
                enableLights(true)
                enableVibration(true)
                val ringtoneUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
                setSound(
                    ringtoneUri,
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
            }
            notificationManager.createNotificationChannel(incomingCallsChannel)
        }
    }

    /**
     * Display a rich system notification alerting the user of a missed audio or video call.
     */
    fun showMissedCallNotification(
        context: Context,
        callId: String,
        callerName: String,
        callerPhone: String,
        callerAvatar: String,
        isVideo: Boolean,
        timestamp: Long = System.currentTimeMillis()
    ) {
        createNotificationChannels(context)

        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        // Intent to open app directly on Calls tab or Call back
        val openAppIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("OPEN_SCREEN", "CALLS")
            putExtra("CALL_ID", callId)
            putExtra("CALLER_PHONE", callerPhone)
            putExtra("CALLER_NAME", callerName)
        }
        val contentPendingIntent = PendingIntent.getActivity(
            context,
            callId.hashCode(),
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Action intent: Call Back
        val callBackIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("ACTION_CALL_BACK", true)
            putExtra("CALLER_PHONE", callerPhone)
            putExtra("CALLER_NAME", callerName)
            putExtra("CALLER_AVATAR", callerAvatar)
            putExtra("IS_VIDEO", isVideo)
        }
        val callBackPendingIntent = PendingIntent.getActivity(
            context,
            (callId + "_callback").hashCode(),
            callBackIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Action intent: Send a message
        val messageIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("ACTION_MESSAGE_CONTACT", true)
            putExtra("CALLER_PHONE", callerPhone)
            putExtra("CALLER_NAME", callerName)
        }
        val messagePendingIntent = PendingIntent.getActivity(
            context,
            (callId + "_message").hashCode(),
            messageIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val title = if (isVideo) "Appel vidéo manqué" else "Appel audio manqué"
        val callTypeIcon = if (isVideo) "📹" else "📞"
        val subtitle = "$callTypeIcon De $callerName ($callerPhone)"

        val notification = NotificationCompat.Builder(context, CHANNEL_MISSED_CALLS_ID)
            .setSmallIcon(android.R.drawable.sym_call_missed)
            .setContentTitle(title)
            .setContentText(subtitle)
            .setSubText("ADT Pro Chiffré")
            .setWhen(timestamp)
            .setShowWhen(true)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_MISSED_CALL)
            .setContentIntent(contentPendingIntent)
            .addAction(
                android.R.drawable.sym_action_call,
                if (isVideo) "Rappeler en vidéo" else "Rappeler",
                callBackPendingIntent
            )
            .addAction(
                android.R.drawable.ic_dialog_email,
                "Envoyer un message",
                messagePendingIntent
            )
            .build()

        val notificationId = NOTIFICATION_BASE_ID + Math.abs(callId.hashCode() % 1000)
        notificationManager.notify(notificationId, notification)
    }

    /**
     * Cancel notification by ID
     */
    fun cancelNotification(context: Context, notificationId: Int) {
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.cancel(notificationId)
    }
}
