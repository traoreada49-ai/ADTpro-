package com.example.data.model

/**
 * Modes de performance et d'économie d'énergie pour le service de synchronisation d'arrière-plan ADT Pro.
 */
enum class SyncEnergyMode(
    val id: String,
    val label: String,
    val subtitle: String,
    val description: String,
    val badge: String,
    val syncIntervalText: String,
    val batteryImpact: String,
    val estimatedSavings: String
) {
    HIGH_PERFORMANCE(
        id = "HIGH_PERFORMANCE",
        label = "Haute Performance",
        subtitle = "Temps réel & latence minimale",
        description = "Maintient les flux en direct, délivre les messages instantanément et télécharge les médias automatiquement.",
        badge = "⚡ Performance Max",
        syncIntervalText = "Temps réel (< 100 ms)",
        batteryImpact = "Consommation nominale",
        estimatedSavings = "Latence zéro"
    ),
    BATTERY_SAVER(
        id = "BATTERY_SAVER",
        label = "Économie d'Énergie",
        subtitle = "Cadencé (15 min) & radio préservée",
        description = "Suspend les écoutes continues en veille, regroupe les transferts toutes les 15 min et limite le préchargement lourd.",
        badge = "🔋 Économie active",
        syncIntervalText = "Toutes les 15 minutes",
        batteryImpact = "Basse consommation (-60%)",
        estimatedSavings = "+3h d'autonomie estimée"
    );

    companion object {
        fun fromId(id: String?): SyncEnergyMode {
            return entries.firstOrNull { it.id.equals(id, ignoreCase = true) } ?: HIGH_PERFORMANCE
        }
    }
}
