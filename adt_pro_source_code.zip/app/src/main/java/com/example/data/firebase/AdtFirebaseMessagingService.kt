package com.example.data.firebase

import android.content.Context
import android.util.Log
import com.example.data.local.AppDatabase
import com.example.data.notification.CallNotificationHelper
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Firebase Cloud Messaging Service for ADT Pro.
 * Handles push notifications received when the app is in the background or killed,
 * specifically alerting the user to missed audio/video calls and incoming call offers.
 */
class AdtFirebaseMessagingService : FirebaseMessagingService() {

    private val serviceJob = SupervisorJob()
    private val serviceScope = CoroutineScope(Dispatchers.IO + serviceJob)

    companion object {
        private const val TAG = "AdtFirebaseMessaging"
        const val TYPE_MISSED_CALL = "MISSED_CALL"
        const val TYPE_INCOMING_CALL = "INCOMING_CALL"
        const val TYPE_NEW_MESSAGE = "NEW_MESSAGE"

        /**
         * Subscribe current user phone topic or store token
         */
        fun registerDeviceToken(context: Context, token: String, userPhone: String?) {
            Log.i(TAG, "New FCM Device Registration Token: $token for phone: $userPhone")
            // Can be synced to Firestore users collection
        }
    }

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        Log.i(TAG, "Refreshed FCM Token: $token")
        serviceScope.launch {
            try {
                val db = AppDatabase.getDatabase(applicationContext)
                val user = db.userDao().getUser()
                registerDeviceToken(applicationContext, token, user?.phone)
            } catch (e: Exception) {
                Log.w(TAG, "Failed to register new FCM token: ${e.message}")
            }
        }
    }

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)
        Log.d(TAG, "FCM Message received from: ${remoteMessage.from}, data=${remoteMessage.data}")

        val data = remoteMessage.data
        val notificationType = data["type"] ?: data["notification_type"] ?: ""

        when (notificationType) {
            TYPE_MISSED_CALL -> {
                val callId = data["callId"] ?: "call_${System.currentTimeMillis()}"
                val callerName = data["callerName"] ?: "Contact ADT"
                val callerPhone = data["callerPhone"] ?: ""
                val callerAvatar = data["callerAvatar"] ?: ""
                val isVideo = data["isVideo"]?.toBoolean() ?: false
                val timestamp = data["timestamp"]?.toLongOrNull() ?: System.currentTimeMillis()

                Log.i(TAG, "Handling FCM MISSED_CALL: caller=$callerName, phone=$callerPhone, video=$isVideo")

                // Post system push notification
                CallNotificationHelper.showMissedCallNotification(
                    context = applicationContext,
                    callId = callId,
                    callerName = callerName,
                    callerPhone = callerPhone,
                    callerAvatar = callerAvatar,
                    isVideo = isVideo,
                    timestamp = timestamp
                )

                // Also persist missed call entry in local database
                serviceScope.launch {
                    try {
                        val db = AppDatabase.getDatabase(applicationContext)
                        db.callDao().insertCall(
                            com.example.data.local.entity.CallLogEntity(
                                id = callId,
                                contactName = callerName,
                                contactPhone = callerPhone,
                                contactAvatar = callerAvatar,
                                timestamp = timestamp,
                                durationSeconds = 0,
                                isVideo = isVideo,
                                isOutgoing = false,
                                isMissed = true
                            )
                        )
                    } catch (e: Exception) {
                        Log.w(TAG, "Error inserting missed call from FCM: ${e.message}")
                    }
                }
            }

            TYPE_INCOMING_CALL -> {
                val callId = data["callId"] ?: "call_${System.currentTimeMillis()}"
                val callerName = data["callerName"] ?: "Contact ADT"
                val callerPhone = data["callerPhone"] ?: ""
                val callerAvatar = data["callerAvatar"] ?: ""
                val isVideo = data["isVideo"]?.toBoolean() ?: false
                Log.i(TAG, "Incoming call push notification received for $callerName")
                // Can trigger high-priority ring / heads-up notification
            }

            else -> {
                // If it contains notification payload from Firebase Console
                remoteMessage.notification?.let { notif ->
                    val title = notif.title ?: "ADT Pro"
                    val body = notif.body ?: ""
                    Log.d(TAG, "Notification title: $title, body: $body")
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceJob.cancel()
    }
}
