package com.example.data.firebase

import android.content.Context
import android.util.Log
import com.example.BuildConfig
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.tasks.await

/**
 * Centralized thread-safe initializer for Firebase services across the application.
 * Ensures that the default FirebaseApp is always properly initialized, even in
 * environments without google-services.json or when default resource initialization
 * returns null.
 */
object FirebaseInitHelper {
    private const val TAG = "FirebaseInitHelper"
    @Volatile
    private var isCloudStorageActive: Boolean? = null

    @Synchronized
    fun ensureInitialized(context: Context): FirebaseApp {
        val appContext = context.applicationContext ?: context
        return try {
            // First check if an active default app already exists
            try {
                FirebaseApp.getInstance()
            } catch (e: IllegalStateException) {
                initializeDefaultApp(appContext)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Checking default FirebaseApp state: ${e.message}")
            initializeDefaultApp(appContext)
        }
    }

    private fun initializeDefaultApp(context: Context): FirebaseApp {
        // Attempt standard resource-based initialization first
        val defaultApp = try {
            FirebaseApp.initializeApp(context)
        } catch (e: Exception) {
            Log.d(TAG, "Resource initializeApp note: ${e.message}")
            null
        }

        if (defaultApp != null) {
            Log.i(TAG, "FirebaseApp initialized from default resources")
            return defaultApp
        }

        // Fallback: initialize with explicit configuration parameters
        val apiKey = BuildConfig.GEMINI_API_KEY.ifBlank { "AIzaSyAdtProDefaultMockKey0123456789" }
        val options = FirebaseOptions.Builder()
            .setApplicationId("1:322385470478:android:aistudioadtprosocial")
            .setApiKey(apiKey)
            .setProjectId("adt-pro-social")
            .setGcmSenderId("322385470478")
            .setStorageBucket("adt-pro-social.appspot.com")
            .build()

        return try {
            val app = FirebaseApp.initializeApp(context, options)
            Log.i(TAG, "FirebaseApp initialized with explicit fallback options")
            app
        } catch (e: IllegalStateException) {
            // Might have been initialized concurrently
            FirebaseApp.getInstance()
        }
    }

    fun getAuth(context: Context): FirebaseAuth? {
        return try {
            ensureInitialized(context)
            FirebaseAuth.getInstance()
        } catch (e: Exception) {
            Log.e(TAG, "Error obtaining FirebaseAuth: ${e.message}")
            null
        }
    }

    fun hasAuthenticatedUser(context: Context): Boolean {
        return try {
            val auth = getAuth(context)
            auth?.currentUser != null
        } catch (e: Exception) {
            false
        }
    }

    suspend fun ensureAuthenticated(context: Context): Boolean {
        val auth = getAuth(context) ?: return false
        if (auth.currentUser != null) return true
        return try {
            auth.signInAnonymously().await()
            Log.i(TAG, "Firebase authenticated anonymously for cloud services: ${auth.currentUser?.uid}")
            true
        } catch (e: Exception) {
            Log.d(TAG, "Firebase anonymous auth note (offline/local fallback): ${e.message}")
            false
        }
    }

    fun isCloudStorageAvailable(): Boolean = isCloudStorageActive ?: true

    fun markCloudStorageUnavailable() {
        isCloudStorageActive = false
        Log.w(TAG, "Cloud storage bucket marked as unavailable; falling back to high-res local encrypted vault.")
    }

    fun getStorage(context: Context): FirebaseStorage? {
        if (isCloudStorageActive == false) {
            return null
        }
        return try {
            ensureInitialized(context)
            FirebaseStorage.getInstance()
        } catch (e: Exception) {
            Log.w(TAG, "Error obtaining FirebaseStorage: ${e.message}")
            null
        }
    }

    fun getFirestore(context: Context): FirebaseFirestore? {
        return try {
            ensureInitialized(context)
            FirebaseFirestore.getInstance()
        } catch (e: Exception) {
            Log.e(TAG, "Error obtaining FirebaseFirestore: ${e.message}")
            null
        }
    }
}
