package com.example.data.firebase

import android.content.Context
import android.util.Log
import com.example.BuildConfig
import com.google.firebase.Firebase
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.ai.FirebaseAI
import com.google.firebase.ai.GenerativeModel
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.GenerativeBackend
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Service gérant les suggestions de réponses rapides contextuelles basées sur le dernier message reçu,
 * utilisant Firebase AI (modèle Gemini 2.5 Flash / Gemini 3.5 Flash) avec fallback direct REST API et heuristiques contextuelles.
 */
object FirebaseAiQuickReplyService {

    private const val TAG = "FirebaseAiQuickReply"
    // Modern Gemini 3.5 Flash model for fast and accurate contextual text generation
    private const val MODEL_NAME = "gemini-3.5-flash"
    private const val FALLBACK_MODEL_NAME = "gemini-flash-latest"

    private var generativeModel: GenerativeModel? = null
    private var isInitialized = false
    private var applicationContext: Context? = null

    private val httpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(12, TimeUnit.SECONDS)
            .readTimeout(12, TimeUnit.SECONDS)
            .writeTimeout(12, TimeUnit.SECONDS)
            .build()
    }

    /**
     * Initialise le modèle Firebase AI avec fallback gracieux si Firebase n'est pas configuré.
     */
    fun init(context: Context) {
        applicationContext = context.applicationContext
        if (isInitialized && generativeModel != null) return

        try {
            // S'assurer qu'une FirebaseApp par défaut existe
            var app = try {
                FirebaseInitHelper.ensureInitialized(context)
            } catch (e: Exception) {
                null
            }

            if (app == null) {
                try {
                    val options = FirebaseOptions.Builder()
                        .setApplicationId(context.packageName)
                        .setProjectId("adt-pro-messenger")
                        .setApiKey(BuildConfig.GEMINI_API_KEY.ifBlank { "AIzaSyDummyKeyForStudioAiApp123456" })
                        .build()
                    app = FirebaseApp.initializeApp(context.applicationContext, options, "ADTProAiApp")
                } catch (initEx: Exception) {
                    Log.w(TAG, "Fallback initializeApp: ${initEx.message}")
                }
            }

            if (app != null) {
                // Utilisation de Firebase AI (Google AI backend)
                val firebaseAi = try {
                    Firebase.ai(app, GenerativeBackend.googleAI())
                } catch (e: Exception) {
                    FirebaseAI.getInstance(app, GenerativeBackend.googleAI())
                }

                val config = generationConfig {
                    temperature = 0.7f
                    maxOutputTokens = 180
                }

                generativeModel = try {
                    firebaseAi.generativeModel(
                        modelName = MODEL_NAME,
                        generationConfig = config
                    )
                } catch (e: Exception) {
                    firebaseAi.generativeModel(
                        modelName = FALLBACK_MODEL_NAME,
                        generationConfig = config
                    )
                }
                isInitialized = true
                Log.d(TAG, "Firebase AI GenerativeModel initialized successfully ($MODEL_NAME)")
            } else {
                Log.w(TAG, "FirebaseApp is null, direct REST and smart engine will handle requests")
            }
        } catch (e: Exception) {
            Log.w(TAG, "Firebase AI initialization deferred: ${e.message}")
        }
    }

    /**
     * Génère des suggestions de réponses rapides pour le dernier message reçu.
     * @param context Contexte Android pour auto-initialiser Firebase AI si nécessaire
     * @param lastMessage Le texte du dernier message reçu
     * @param senderName Le nom de l'expéditeur
     * @param chatTitle Le titre ou contexte de la conversation
     * @param language La langue préférée de l'utilisateur ("FR", "EN", "ES", "AR", etc.)
     * @param tone Le style de réponse souhaité ("FRIENDLY", "PROFESSIONAL", "SHORT")
     * @param recentMessages L'historique récent des derniers messages pour la compréhension contextuelle
     * @return Liste de 3 suggestions concises adaptées au contexte
     */
    suspend fun generateQuickReplies(
        context: Context? = null,
        lastMessage: String,
        senderName: String = "Contact",
        chatTitle: String = "Discussion",
        language: String = "FR",
        tone: String = "FRIENDLY",
        recentMessages: List<Pair<String, String>> = emptyList()
    ): List<String> = withContext(Dispatchers.IO) {
        if (lastMessage.isBlank()) return@withContext emptyList()

        if (!isInitialized || generativeModel == null) {
            val ctx = context ?: applicationContext
            if (ctx != null) {
                init(ctx)
            }
        }

        val prompt = buildPrompt(
            lastMessage = lastMessage,
            senderName = senderName,
            chatTitle = chatTitle,
            language = language,
            tone = tone,
            recentMessages = recentMessages
        )

        // 1. Tenter d'utiliser le SDK Firebase GenAI (GenerativeModel)
        try {
            val model = generativeModel
            if (model != null) {
                val response = model.generateContent(prompt)
                val rawText = response.text?.trim().orEmpty()
                val parsed = parseSuggestions(rawText)
                if (parsed.isNotEmpty()) {
                    Log.d(TAG, "Quick replies generated via Firebase GenAI SDK: $parsed")
                    return@withContext parsed.take(3)
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Firebase AI generateContent exception, attempting Gemini REST API: ${e.message}")
        }

        // 2. Fallback direct sur l'API Gemini REST avec la clé API injectée
        val restReplies = callGeminiRestApi(prompt)
        if (restReplies.isNotEmpty()) {
            Log.d(TAG, "Quick replies generated via Gemini REST fallback: $restReplies")
            return@withContext restReplies.take(3)
        }

        // 3. Fallback contextuel intelligent ultra-rapide (hors-ligne ou sans quota réseau)
        return@withContext generateSmartContextualFallback(lastMessage, language).take(3)
    }

    /**
     * Appel direct de secours via l'API REST Google Gemini (gemini-3.5-flash / gemini-2.5-flash).
     */
    private suspend fun callGeminiRestApi(prompt: String): List<String> = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isBlank() || apiKey.startsWith("MY_GEMINI")) return@withContext emptyList()

        for (model in listOf(MODEL_NAME, FALLBACK_MODEL_NAME)) {
            try {
                val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey"
                val jsonObject = JSONObject().apply {
                    val contents = JSONArray().apply {
                        val content = JSONObject().apply {
                            val parts = JSONArray().apply {
                                put(JSONObject().apply { put("text", prompt) })
                            }
                            put("parts", parts)
                        }
                        put(content)
                    }
                    put("contents", contents)
                    val config = JSONObject().apply {
                        put("temperature", 0.7)
                        put("maxOutputTokens", 180)
                    }
                    put("generationConfig", config)
                }

                val mediaType = "application/json; charset=utf-8".toMediaTypeOrNull()
                val requestBody = RequestBody.create(mediaType, jsonObject.toString())
                val request = Request.Builder()
                    .url(url)
                    .post(requestBody)
                    .build()

                val response = httpClient.newCall(request).execute()
                if (response.isSuccessful) {
                    val bodyStr = response.body?.string().orEmpty()
                    val root = JSONObject(bodyStr)
                    val candidates = root.optJSONArray("candidates")
                    val firstCandidate = candidates?.optJSONObject(0)
                    val content = firstCandidate?.optJSONObject("content")
                    val parts = content?.optJSONArray("parts")
                    val text = parts?.optJSONObject(0)?.optString("text").orEmpty()
                    val parsed = parseSuggestions(text)
                    if (parsed.isNotEmpty()) {
                        return@withContext parsed
                    }
                } else {
                    Log.w(TAG, "Gemini REST API ($model) response status: ${response.code}")
                }
            } catch (e: Exception) {
                Log.w(TAG, "Gemini REST API ($model) invocation error: ${e.message}")
            }
        }
        emptyList()
    }

    /**
     * Construit un prompt optimisé demandant explicitement un tableau JSON de 3 courtes réponses contextuelles.
     */
    private fun buildPrompt(
        lastMessage: String,
        senderName: String,
        chatTitle: String,
        language: String,
        tone: String = "FRIENDLY",
        recentMessages: List<Pair<String, String>> = emptyList()
    ): String {
        val langInstruction = when (language.uppercase()) {
            "EN" -> "in English"
            "ES" -> "en español"
            "AR" -> "باللغة العربية"
            "RU" -> "на русском"
            "ZH" -> "用中文 (Simplified Chinese)"
            "PT" -> "em português"
            "DE" -> "auf Deutsch"
            "SW" -> "kwa Kiswahili"
            "BAMBARA", "BM" -> "en bamanankan (bambara)"
            "WOLOF", "WO" -> "en wolof"
            "HAUSA", "HA" -> "da harshen hausa"
            "FRANGLAIS" -> "en franglais urbain moderne et amical"
            else -> "en français moderne, naturel et bienveillant"
        }

        val toneInstruction = when (tone.uppercase()) {
            "PROFESSIONAL" -> "Ton de réponse : professionnel, courtois, respectueux et direct pour un contexte d'entreprise."
            "SHORT" -> "Ton de réponse : ultra-court et synthétique (1 à 4 mots maximum par suggestion)."
            else -> "Ton de réponse : chaleureux, naturel, amical et poli."
        }

        val historyBlock = if (recentMessages.isNotEmpty()) {
            val formatted = recentMessages.takeLast(4).joinToString("\n") { (sender, text) ->
                "- $sender: \"$text\""
            }
            "Historique récent de la conversation :\n$formatted\n"
        } else ""

        return """
            Tu es l'assistant de messagerie instantanée ADT Pro propulsé par le SDK Firebase GenAI (Gemini).
            Analyse attentivement le contexte de la conversation et le dernier message reçu ci-dessous, puis génère exactement 3 suggestions de réponses rapides, courtes et percutantes (entre 1 et 6 mots par suggestion), adaptées à une réponse instantanée $langInstruction.
            
            $toneInstruction
            
            Conversation: $chatTitle
            $historyBlock
            Dernier message reçu de $senderName: "$lastMessage"
            
            Consignes :
            - Proposer 3 options complémentaires (par exemple : une affirmation positive, une alternative/temporisation, et une confirmation d'action).
            - Respecter scrupuleusement la langue demandée ($langInstruction).
            - Format de réponse attendu: STRICTEMENT un tableau JSON de 3 chaînes de caractères, rien d'autre. Exemple :
            ["D'accord, parfait !", "Je m'en occupe tout de suite", "On se rappelle plus tard ?"]
        """.trimIndent()
    }

    /**
     * Parse la réponse du modèle (JSON array ou lignes de puces).
     */
    fun parseSuggestions(raw: String): List<String> {
        if (raw.isBlank()) return emptyList()

        val results = mutableListOf<String>()

        // Tentative d'extraction du JSON array
        try {
            val startIndex = raw.indexOf('[')
            val endIndex = raw.lastIndexOf(']')
            if (startIndex != -1 && endIndex != -1 && endIndex > startIndex) {
                val jsonSubstring = raw.substring(startIndex, endIndex + 1)
                val jsonArray = JSONArray(jsonSubstring)
                for (i in 0 until jsonArray.length()) {
                    val item = jsonArray.optString(i)?.trim().orEmpty()
                    if (item.isNotBlank() && item.length in 2..65) {
                        results.add(cleanReplyText(item))
                    }
                }
                if (results.isNotEmpty()) return results
            }
        } catch (e: Exception) {
            Log.d(TAG, "Could not parse JSON array directly: ${e.message}")
        }

        // Si ce n'est pas un JSON valide, parser par lignes (1., -, etc.)
        val lines = raw.lines()
        for (line in lines) {
            val cleaned = line.trim()
                .removePrefix("-")
                .removePrefix("*")
                .replace(Regex("""^\d+[\.\)]\s*"""), "")
                .trim('"', ' ', '`', '\'', '[', ']')
                .trim()
            if (cleaned.isNotBlank() && cleaned.length in 2..65 && !cleaned.startsWith("{") && !cleaned.endsWith("}")) {
                results.add(cleanReplyText(cleaned))
            }
        }

        return results
    }

    private fun cleanReplyText(text: String): String {
        return text.trim('"', '\'', ' ', '`')
            .replace("\\n", " ")
            .replace(Regex("""\s+"""), " ")
    }

    /**
     * Générateur contextuel de secours très réactif analysant le contenu sémantique
     * (salutations, questions d'horaires, remerciements, confirmations, localisation, urgence).
     */
    fun generateSmartContextualFallback(text: String, language: String = "FR"): List<String> {
        val lower = text.lowercase().trim()

        val isEnglish = language.equals("EN", ignoreCase = true)
        val isSpanish = language.equals("ES", ignoreCase = true)
        val isArabic = language.equals("AR", ignoreCase = true)

        // 1. Salutations / Bonjour / Bonsoir
        if (lower.contains("bonjour") || lower.contains("salut") || lower.contains("coucou") ||
            lower.contains("hello") || lower.contains("bonsoir") || lower.contains("salam")
        ) {
            return when {
                isEnglish -> listOf("Hello! How are you?", "Hi there!", "Good morning!", "Hey! What's up?")
                isSpanish -> listOf("¡Hola! ¿Cómo estás?", "¡Buenas!", "¡Hola! Todo bien?", "¡Hola!")
                isArabic -> listOf("وعليكم السلام!", "أهلاً وسهلاً!", "مرحباً بك", "صباح الخير!")
                else -> listOf("Bonjour ! Comment vas-tu ?", "Salut ! Ça va bien ?", "Coucou ! Que puis-je pour toi ?", "Bonjour !")
            }
        }

        // 2. Question "Comment ça va / Tu vas bien"
        if (lower.contains("comment vas-tu") || lower.contains("comment tu vas") || lower.contains("ca va") ||
            lower.contains("ça va") || lower.contains("tu vas bien") || lower.contains("how are you")
        ) {
            return when {
                isEnglish -> listOf("I'm doing well, thanks! And you?", "All good on my side!", "Great! How about you?", "Very well, thank you!")
                isSpanish -> listOf("¡Muy bien, gracias! ¿Y tú?", "¡Todo perfecto!", "¡Bien! ¿Y por tu parte?", "¡Genial!")
                isArabic -> listOf("الحمد لله بخير، وأنت؟", "كل شيء تمام!", "بخير، شكراً لك", "الحمد لله")
                else -> listOf("Très bien, merci ! Et toi ?", "Ça va super bien !", "Tout va bien par ici, et toi ?", "Impeccable, merci !")
            }
        }

        // 3. Remerciements (Merci / Thanks / Shukran)
        if (lower.contains("merci") || lower.contains("thanks") || lower.contains("thank you") ||
            lower.contains("gracias") || lower.contains("shukran") || lower.contains("choukran")
        ) {
            return when {
                isEnglish -> listOf("You're welcome!", "Anytime!", "Glad I could help!", "With pleasure!")
                isSpanish -> listOf("¡De nada!", "¡Un placer!", "¡A la orden!", "¡No hay de qué!")
                isArabic -> listOf("العفو!", "لا شكر على واجب", "على الرحب والسعة", "في خدمتك دائماً")
                else -> listOf("Je t'en prie !", "Avec grand plaisir !", "De rien !", "Pas de souci, à ton service !")
            }
        }

        // 4. Question sur l'heure, un rendez-vous ou "Quand"
        if (lower.contains("quand") || lower.contains("quelle heure") || lower.contains("rdv") ||
            lower.contains("rendez-vous") || lower.contains("disponible") || lower.contains("dispo") ||
            lower.contains("when") || lower.contains("time")
        ) {
            return when {
                isEnglish -> listOf("I'm available now", "Let's say in 30 minutes?", "Tomorrow morning works best", "I'll confirm the time shortly")
                isSpanish -> listOf("Estoy disponible ahora", "¿Quedamos en 30 min?", "Mañana por la mañana", "Te aviso enseguida")
                isArabic -> listOf("أنا متاح الآن", "بعد 30 دقيقة إن شاء الله", "غداً صباحاً يناسبني", "سأؤكد لك الموعد بعد قليل")
                else -> listOf("Je suis dispo maintenant !", "Disons dans 30 minutes ?", "Demain matin ça te va ?", "Je te confirme l'heure très vite !")
            }
        }

        // 5. Question sur la localisation / "Où es-tu"
        if (lower.contains("ou es-tu") || lower.contains("où es-tu") || lower.contains("t'es où") ||
            lower.contains("t es ou") || lower.contains("localisation") || lower.contains("where are you")
        ) {
            return when {
                isEnglish -> listOf("I'm on my way!", "At the office right now", "Sharing my live location...", "Almost there!")
                isSpanish -> listOf("¡Ya voy de camino!", "Estoy en la oficina", "Te comparto mi ubicación", "Llego en 5 min")
                isArabic -> listOf("أنا في الطريق إليك!", "في المكتب حالياً", "سأرسل موقعي الآن", "على وشك الوصول")
                else -> listOf("Je suis en route !", "Au bureau pour le moment", "Je te partage ma position en direct", "J'arrive d'ici 5 minutes !")
            }
        }

        // 6. Demande de confirmation ou accord (OK, d'accord, c'est bon ?)
        if (lower.endsWith("?") && (lower.contains("d'accord") || lower.contains("possible") || lower.contains("marche") || lower.contains("ok"))) {
            return when {
                isEnglish -> listOf("Sounds good to me!", "Yes, absolutely!", "No problem at all", "Let's do that!")
                isSpanish -> listOf("¡Me parece perfecto!", "¡Sí, por supuesto!", "Sin problema", "¡Hecho!")
                isArabic -> listOf("نعم، بالتأكيد!", "تمام، اتفقنا!", "لا مشكلة على الإطلاق", "على بركة الله")
                else -> listOf("C'est parfait pour moi !", "Oui, absolument !", "Ça marche, c'est noté !", "Pas de problème !")
            }
        }

        // 7. Question générale se terminant par "?"
        if (lower.endsWith("?") || lower.contains("est-ce que") || lower.contains("pourquoi")) {
            return when {
                isEnglish -> listOf("Yes, absolutely!", "I'll check and get back to you", "No, not right now", "Sure, give me a moment")
                isSpanish -> listOf("¡Sí, por supuesto!", "Lo reviso y te confirmo", "No por el momento", "Dame un momento")
                isArabic -> listOf("نعم، بكل تأكيد", "سأتأكد وأرد عليك حالاً", "ليس الآن للأسف", "لحظة واحدة من فضلك")
                else -> listOf("Oui, tout à fait !", "Je vérifie et je te dis ça", "Non, pas pour le moment", "Laisse-moi deux minutes !")
            }
        }

        // 8. Urgence ou alerte
        if (lower.contains("urgent") || lower.contains("vite") || lower.contains("rapide") || lower.contains("urgence")) {
            return when {
                isEnglish -> listOf("I'm on it right now!", "Calling you in a second", "Understood, handling it!", "I'm here")
                isSpanish -> listOf("¡Me pongo a ello ya!", "Te llamo enseguida", "Entendido, lo gestiono", "Estoy aquí")
                isArabic -> listOf("أنا في الأمر حالاً!", "سأتصل بك في الحال", "مفهوم، جاري المعالجة", "أنا معك")
                else -> listOf("Je m'en occupe immédiatement !", "Je t'appelle tout de suite", "Bien reçu, c'est pris en charge", "Je suis là !")
            }
        }

        // 9. Document ou fichier partagé
        if (lower.contains(".pdf") || lower.contains(".doc") || lower.contains(".xls") ||
            lower.contains("document") || lower.contains("fichier") || lower.contains("contrat") || lower.contains("rapport")
        ) {
            return when {
                isEnglish -> listOf("Received, reviewing now!", "Thanks for sending this!", "Got the document, looks good", "I'll read it shortly")
                isSpanish -> listOf("¡Recibido, lo reviso ya!", "¡Gracias por el documento!", "Visto, te confirmo pronto", "Lo leo en breve")
                isArabic -> listOf("تم الاستلام، جاري الاطلاع!", "شكراً على إرسال الملف!", "سأقرأه بعد قليل إن شاء الله", "وصل الملف تماماً")
                else -> listOf("Bien reçu, je regarde ça !", "Merci pour le document !", "Document bien ouvert, je te dis ça", "Je consulte ça de suite !")
            }
        }

        // 10. Localisation ou partage de position en direct
        if (lower.contains("position") || lower.contains("trajet") || lower.contains("en direct") || lower.contains("gps") || lower.contains("carte")) {
            return when {
                isEnglish -> listOf("Got your live location!", "On my way to you!", "See you there in a bit", "Tracking your route")
                isSpanish -> listOf("¡Veo tu ubicación!", "¡Voy hacia ti!", "Nos vemos en un momento", "Sigo tu ruta")
                isArabic -> listOf("تم استلام موقعك المباشر!", "أنا في الطريق إليك", "أراك بعد قليل", "متابع مسارك")
                else -> listOf("Bien reçu ta position !", "Je suis en route vers toi !", "À tout de suite !", "Je te rejoins dans un instant !")
            }
        }

        // 11. Message vocal ou appel
        if (lower.contains("vocal") || lower.contains("audio") || lower.contains("appel") || lower.contains("voix")) {
            return when {
                isEnglish -> listOf("Listening right now!", "Got your voice message", "I'll call you right back", "Understood!")
                isSpanish -> listOf("¡Lo escucho ahora!", "Mensaje de voz recibido", "Te llamo en un momento", "¡Entendido!")
                isArabic -> listOf("جاري الاستماع الآن!", "وصلني التسجيل الصوتي", "سأتصل بك بعد قليل", "مفهوم تماماً")
                else -> listOf("J'écoute ton vocal de suite !", "Bien reçu ton message vocal", "Je te rappelle dans deux minutes", "C'est bien noté !")
            }
        }

        // 12. Par défaut / Conversation générale
        return when {
            isEnglish -> listOf("Understood, thanks!", "Sounds great!", "I'll get back to you soon", "OK, noted!")
            isSpanish -> listOf("¡Entendido, gracias!", "¡Me parece genial!", "Te aviso pronto", "¡De acuerdo!")
            isArabic -> listOf("مفهوم، شكراً لك!", "ممتاز جداً!", "سأتواصل معك قريباً", "حسناً، تم التسجيل")
            else -> listOf("C'est bien noté, merci !", "Parfait, ça marche !", "Je reviens vers toi rapidement", "D'accord, compris !")
        }
    }
}
